// swift-tools-version: 5.9
import PackageDescription
import AppleProductTypes

let package = Package(
    name: "HangeulReader",
    platforms: [.iOS(.v17)],
    products: [
        .iOSApplication(name: "한글뷰어", targets: ["AppModule"],
                        bundleIdentifier: "app.hanpyeon.localreader",
                        displayVersion: "2.0", bundleVersion: "3",
                        appIcon: .asset("AppIcon"), accentColor: .presetColor(.green),
                        supportedDeviceFamilies: [.phone, .pad],
                        supportedInterfaceOrientations: [
                            .portrait, .landscapeLeft, .landscapeRight,
                            .portraitUpsideDown(.when(deviceFamilies: [.pad]))
                        ], additionalInfoPlistContentFilePath: "DocumentTypes.plist")
    ],
    dependencies: [.package(path: "Engine")],
    targets: [
        .executableTarget(name: "AppModule", dependencies: [
            .product(name:"HwpKit", package:"Engine"),
            .product(name:"HwpKitCore", package:"Engine"),
            .product(name:"CoreHwp", package:"Engine")
        ], path:"App", resources:[.process("Assets.xcassets"),.copy("Samples")])
    ]
)
