// swift-tools-version: 5.9
import PackageDescription

var targets: [Target] = [
    .target(name: "OLEKit"),
    .systemLibrary(name: "CHwpZlib"),
    .target(name: "CoreHwp", dependencies: [
        "OLEKit", .target(name: "CHwpZlib", condition: .when(platforms: [.linux]))
    ])
]
var products: [Product] = [.library(name: "CoreHwp", targets: ["CoreHwp"])]
#if canImport(Darwin)
targets += [
    .target(name: "HwpKitCore", dependencies: ["CoreHwp"]),
    .target(name: "HwpKitNative", dependencies: ["CoreHwp", "HwpKitCore"]),
    .target(name: "HwpKit", dependencies: ["CoreHwp", "HwpKitNative", "HwpKitCore"])
]
products += [
    .library(name: "HwpKit", targets: ["HwpKit"]),
    .library(name: "HwpKitCore", targets: ["HwpKitCore"])
]
#endif
let package = Package(name: "Engine", platforms: [.iOS(.v17), .macOS(.v14)],
                      products: products, targets: targets)
