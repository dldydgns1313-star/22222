import CoreGraphics
import CoreText
import Foundation
import HwpKitCore

#if os(macOS)
    import AppKit
#elseif os(iOS)
    import UIKit
#endif

/// 선택 복사의 RTF 직렬화 (#118) — HwpKitCore가 조립한 속성 문자열
/// (`HwpSelectionGeometry.attributedText(for:)`: CT 키 + `hwp.*` 키)을 표준
/// NSAttributedString 키로 정규화한 뒤 RTF `Data`로 만든다.
///
/// HwpKitCore에 둘 수 없는 이유: RTF 직렬화(`data(from:documentAttributes:)`)
/// 와 색·문단 스타일 값 타입(NSColor/UIColor·NSParagraphStyle)이 Foundation이
/// 아니라 AppKit/UIKit 소속이다 (Sources/HwpKitCore/AGENTS.md 첫머리 규약).
enum HwpSelectionRTF {
    static func rtfData(from attributed: NSAttributedString) -> Data? {
        let normalized = normalizedForExport(attributed)
        return try? normalized.data(
            from: NSRange(location: 0, length: normalized.length),
            documentAttributes: [.documentType: NSAttributedString.DocumentType.rtf]
        )
    }

    /// CT·`hwp.*` 키 → 표준 키 정규화. 변환 표 (키 이름 동치는 실증 확인):
    /// - 그대로 두는 CT 키 — 이름이 표준 키와 같다: `kCTFont`("NSFont",
    ///   CTFont는 NSFont/UIFont와 toll-free 브리지)·`kCTKern`("NSKern")·
    ///   `kCTStrokeWidth`("NSStrokeWidth").
    /// - 자간: "CTTracking"(#260 — 커닝 관여 글리프·양수 자간)은 `.kern`에 더해 옮긴다.
    /// - 키 개명: "CTForegroundColor"(CGColor) → `.foregroundColor`(플랫폼 색).
    /// - 기준선: 공급원은 `hwp.glyphBaselineOffset`(양수 = 위, NS 규약 일치 —
    ///   글자위치·첨자 이동 합산) 하나다 → `.baselineOffset`. 같은 정보를
    ///   HWP 원시 부호(양수 = 아래)로 이중 보유한 "CTBaselineOffset"은
    ///   버린다.
    /// - 값 변환: `kCTParagraphStyle`은 키 이름이 "NSParagraphStyle"로 같지만
    ///   값이 `CTParagraphStyle`(toll-free 아님)이라 `NSParagraphStyle`로
    ///   다시 만든다 — 안 바꾸면 RTF 작성기가 CF 타입에 ObjC 메시지를 보낸다.
    ///   줄 간격은 조판 문자열이 나르는 규칙 `hwp.lineSpacing`
    ///   (`HwpLineSpacingRule`, #180)을 표준 문단 속성으로 옮긴다 — 비율 →
    ///   `lineHeightMultiple`, 고정 → `minimumLineHeight` = `maximumLineHeight`,
    ///   최소 → `minimumLineHeight`, 여백만 → `lineSpacing`. CT 스타일의 줄 높이
    ///   지정은 규칙 표식이 없는 문자열의 폴백일 뿐이다 (CT 스타일은 비율을
    ///   `lineHeightMultiple` 힌트로, 고정·최소를 `minimumLineHeight`로만 실어 고정과
    ///   최소를 가르지 못한다).
    /// - `hwp.*` 명시 변환: `underlineStyle`/`underlineColor`·
    ///   `strikethroughStyle`/`strikethroughColor`(둘 다 값 1 = 단선)는 표준
    ///   밑줄·취소선으로, `hyperlink`(String)는 `.link`(URL)로 승격하되 URL
    ///   변환 실패 시 링크 속성만 버린다.
    /// - 나머지 `hwp.*`(그림자·양각·음영·강조점 등 렌더러 전용)와
    ///   from-context 플래그는 제거한다 — 전경색은 모든 run에 이미
    ///   "CTForegroundColor"로 실려 있어 잃는 정보가 없다. 제거는 개별 열거가
    ///   아니라 "hwp." 접두사 일괄이라 미래 키도 새지 않는다.
    static func normalizedForExport(_ attributed: NSAttributedString) -> NSAttributedString {
        let result = NSMutableAttributedString()
        let text = attributed.string as NSString
        attributed.enumerateAttributes(
            in: NSRange(location: 0, length: attributed.length)
        ) { attributes, range, _ in
            result.append(NSAttributedString(
                string: text.substring(with: range),
                attributes: normalizedAttributes(attributes)
            ))
        }
        return result
    }

    private static let ctForegroundColorKey =
        NSAttributedString.Key(kCTForegroundColorAttributeName as String)
    private static let ctBaselineOffsetKey =
        NSAttributedString.Key(kCTBaselineOffsetAttributeName as String)
    private static let ctForegroundFromContextKey =
        NSAttributedString.Key(kCTForegroundColorFromContextAttributeName as String)
    private static let ctTrackingKey =
        NSAttributedString.Key(kCTTrackingAttributeName as String)

    static func normalizedAttributes(
        _ attributes: [NSAttributedString.Key: Any]
    ) -> [NSAttributedString.Key: Any] {
        var normalized = attributes
        // hwp.* 명시 변환 — 접두사 일괄 제거 전에 값을 표준 키로 옮긴다.
        //
        // 밑줄 '글자 위'(`underlineAboveStyle`, #136)는 **일부러 옮기지 않는다**:
        // RTF에도 NSAttributedString에도 윗줄 속성이 없어 표준 밑줄로 옮기면 선이
        // 글자 아래로 뒤집혀 붙는다 — 잃는 것보다 나쁜 오표현이다. 한글.app도 같은
        // 선택을 한다 (2026-09-09 실측): `underline-above` 문서를 복사한 클립보드
        // RTF에 `\ul` 계열·`\chbrdr`가 0건인데, 같은 앱이 `CharShape`의 아래쪽
        // 밑줄은 `\ul\ulc3`(색 포함), 취소선은 `\strike`로 실어 보낸다. 곧 RTF가
        // 표현 못 하는 장식이라 버리는 것이지 빠뜨린 것이 아니다
        // (`HwpSelectionRTFTests.testAboveUnderlineIsDroppedLikeHancom`이 고정).
        if attributes[HwpAttributedStringKey.underlineStyle] != nil {
            normalized[.underlineStyle] = NSNumber(value: NSUnderlineStyle.single.rawValue)
            if let color = cgColor(attributes[HwpAttributedStringKey.underlineColor]) {
                normalized[.underlineColor] = platformColor(from: color)
            }
        }
        if attributes[HwpAttributedStringKey.strikethroughStyle] != nil {
            normalized[.strikethroughStyle] =
                NSNumber(value: NSUnderlineStyle.single.rawValue)
            if let color = cgColor(attributes[HwpAttributedStringKey.strikethroughColor]) {
                normalized[.strikethroughColor] = platformColor(from: color)
            }
        }
        if let link = attributes[HwpAttributedStringKey.hyperlink] as? String,
           let url = URL(string: link)
        {
            normalized[.link] = url
        }
        // 키 개명 2종
        if let color = cgColor(normalized.removeValue(forKey: ctForegroundColorKey)) {
            normalized[.foregroundColor] = platformColor(from: color)
        }
        // 기준선 공급원은 hwp.glyphBaselineOffset 하나다 — 렌더러 규약
        // (양수 = 위)가 NS와 일치하고 글자위치·첨자 이동이 합산돼 있다.
        // "CTBaselineOffset"은 같은 글자위치 정보를 HWP 원시 부호(양수 =
        // 아래)로 이중 보유하므로 제거만 한다 — 부호 그대로 옮기면 복사한
        // 글자가 앱 렌더와 반대 방향으로 붙는다. 글자위치 0이면 glyph 키가
        // 없고 오프셋 없음이 올바른 결과다.
        normalized.removeValue(forKey: ctBaselineOffsetKey)
        // 자간(#260)은 글자마다 kern 또는 tracking에 실린다 (`HwpLetterSpacing.Carrier`). RTF에는
        // tracking이 없어 작성기가 그 키를 버리므로 kern으로 옮긴다 — 두 속성 모두 글자 묶음 뒤에 더해지는
        // 간격이라 뜻이 같고, tracking 글자는 kern이 0이다.
        if let tracking = normalized.removeValue(forKey: ctTrackingKey) as? NSNumber {
            let kern = (normalized[.kern] as? NSNumber)?.doubleValue ?? 0
            normalized[.kern] = NSNumber(value: kern + tracking.doubleValue)
        }
        if let offset =
            attributes[HwpAttributedStringKey.glyphBaselineOffset] as? NSNumber
        {
            normalized[.baselineOffset] = offset
        }
        // 값 변환: CTParagraphStyle → NSParagraphStyle (키 이름은 같다). 줄 간격은
        // 접두사 일괄 제거 전에 규칙 표식(`hwp.lineSpacing`)에서 읽는다.
        if let style = normalized[.paragraphStyle],
           CFGetTypeID(style as CFTypeRef) == CTParagraphStyleGetTypeID()
        {
            normalized[.paragraphStyle] = nsParagraphStyle(
                from: style as! CTParagraphStyle, // swiftlint:disable:this force_cast
                lineSpacing: HwpLineSpacingRule(
                    attributeValue: attributes[HwpAttributedStringKey.lineSpacing]
                )
            )
        }
        // 렌더러 전용 잔여 제거
        normalized[ctForegroundFromContextKey] = nil
        for key in normalized.keys where key.rawValue.hasPrefix("hwp.") {
            normalized[key] = nil
        }
        return normalized
    }

    private static func cgColor(_ value: Any?) -> CGColor? {
        guard let value, CFGetTypeID(value as CFTypeRef) == CGColor.typeID
        else { return nil }
        return (value as! CGColor) // swiftlint:disable:this force_cast
    }

    private static func platformColor(from cgColor: CGColor) -> PlatformColor {
        #if os(macOS)
            PlatformColor.hwpColor(from: cgColor)
        #else
            PlatformColor(hwpCgColor: cgColor)
        #endif
    }

    // MARK: - 문단 스타일 값 변환

    /// `HwpParagraphLayout.ctParagraphStyle`이 싣는 지정자만 옮긴다 —
    /// 정렬·들여쓰기 3종·문단 간격 2종·행간 3종·탭 정지.
    /// (CT `maximumLineSpacing`은 NSParagraphStyle에 대응이 없어 버린다.)
    ///
    /// 줄 간격은 `lineSpacing` 규칙(조판 문자열의 `hwp.lineSpacing`, #180)이 있으면 그것을
    /// 표준 속성으로 옮기고, 없으면(CT 스타일만 단 문자열) CT 지정자를 그대로 옮긴다.
    private static func nsParagraphStyle(
        from ctStyle: CTParagraphStyle, lineSpacing rule: HwpLineSpacingRule?
    ) -> NSParagraphStyle {
        let style = NSMutableParagraphStyle()
        var alignment = CTTextAlignment.natural
        if CTParagraphStyleGetValueForSpecifier(
            ctStyle, .alignment, MemoryLayout<CTTextAlignment>.size, &alignment
        ) {
            style.alignment = nsTextAlignment(from: alignment)
        }
        copyFloat(ctStyle, .firstLineHeadIndent) { style.firstLineHeadIndent = $0 }
        copyFloat(ctStyle, .headIndent) { style.headIndent = $0 }
        copyFloat(ctStyle, .tailIndent) { style.tailIndent = $0 }
        copyFloat(ctStyle, .paragraphSpacingBefore) { style.paragraphSpacingBefore = $0 }
        copyFloat(ctStyle, .paragraphSpacing) { style.paragraphSpacing = $0 }
        if let rule {
            applyLineSpacing(rule, to: style)
        } else {
            copyFloat(ctStyle, .lineSpacingAdjustment) { style.lineSpacing = $0 }
            copyFloat(ctStyle, .lineHeightMultiple) { style.lineHeightMultiple = $0 }
            copyFloat(ctStyle, .minimumLineHeight) { style.minimumLineHeight = $0 }
            copyFloat(ctStyle, .maximumLineHeight) { style.maximumLineHeight = $0 }
        }
        // 탭 정지: CFArray를 +0 참조로 받는다 (버퍼에 담기는 것은 포인터)
        var tabsPointer: UnsafeMutableRawPointer?
        if CTParagraphStyleGetValueForSpecifier(
            ctStyle, .tabStops, MemoryLayout<UnsafeMutableRawPointer?>.size, &tabsPointer
        ), let tabsPointer {
            let tabs = Unmanaged<CFArray>.fromOpaque(tabsPointer)
                .takeUnretainedValue() as [AnyObject]
            // CF 타입 조건 캐스트는 원소를 검사하지 않아 안전망이 못 된다 —
            // cgColor와 같은 CFGetTypeID 검사로 이물 원소를 건너뛴다.
            style.tabStops = tabs.compactMap { element in
                guard CFGetTypeID(element) == CTTextTabGetTypeID() else { return nil }
                let tab = element as! CTTextTab // swiftlint:disable:this force_cast
                return NSTextTab(
                    textAlignment: nsTextAlignment(from: CTTextTabGetAlignment(tab)),
                    location: CTTextTabGetLocation(tab)
                )
            }
        }
        return style
    }

    /// 표 46 줄 간격 규칙 → 표준 문단 속성. 한글의 상자 모델(비율은 글자 크기 × p, 고정은 값
    /// 그대로)을 NSParagraphStyle이 그대로 표현하지는 못하므로 **뜻이 같은 속성**을 고른다 —
    /// 비율 p → `lineHeightMultiple` p/100, 고정 v → `minimumLineHeight` = `maximumLineHeight`
    /// = v, 최소 v → `minimumLineHeight` v, 여백만 v → `lineSpacing` v. 한 속성만 세우고
    /// 나머지는 0(미설정)으로 둔다.
    private static func applyLineSpacing(
        _ rule: HwpLineSpacingRule, to style: NSMutableParagraphStyle
    ) {
        style.lineSpacing = 0
        style.lineHeightMultiple = 0
        style.minimumLineHeight = 0
        style.maximumLineHeight = 0
        switch rule.kind {
        case .percent:
            style.lineHeightMultiple = max(0, rule.value / 100)
        case .fixed:
            style.minimumLineHeight = max(0, rule.value)
            style.maximumLineHeight = max(0, rule.value)
        case .atLeast:
            style.minimumLineHeight = max(0, rule.value)
        case .marginOnly:
            style.lineSpacing = max(0, rule.value)
        }
    }

    private static func copyFloat(
        _ ctStyle: CTParagraphStyle,
        _ specifier: CTParagraphStyleSpecifier,
        into assign: (CGFloat) -> Void
    ) {
        var value: CGFloat = 0
        if CTParagraphStyleGetValueForSpecifier(
            ctStyle, specifier, MemoryLayout<CGFloat>.size, &value
        ) {
            assign(value)
        }
    }

    private static func nsTextAlignment(from alignment: CTTextAlignment) -> NSTextAlignment {
        switch alignment {
        case .left: .left
        case .center: .center
        case .right: .right
        case .justified: .justified
        case .natural: .natural
        @unknown default: .natural
        }
    }
}
