import CoreGraphics
import Foundation
import HwpKitCore

public enum HwpPDFRenderError: Error, Sendable {
    case emptyDocument
    case incompleteDocument
    case contextCreationFailed
    case fileWriteFailed(path: String, reason: String)
    case pageImagesExceedMemoryBudget(pageIndex: Int)
    case incompleteOutput(expectedPages: Int, writtenPages: Int?)
}

extension HwpPDFRenderError: CustomStringConvertible {
    public var description: String {
        switch self {
        case .emptyDocument:
            "Document has no pages to export"
        case .incompleteDocument:
            "Document is still being paginated — export the final snapshot instead"
        case .contextCreationFailed:
            "Could not create a PDF context"
        case let .fileWriteFailed(path, reason):
            "Could not write '\(path)': \(reason)"
        case let .pageImagesExceedMemoryBudget(pageIndex):
            "Page \(pageIndex + 1) references more image data than the decode budget allows"
        case let .incompleteOutput(expectedPages, writtenPages):
            if let writtenPages {
                "PDF output is incomplete: wrote \(writtenPages) of \(expectedPages) pages"
            } else {
                "PDF output could not be reopened after writing "
                    + "(\(expectedPages) pages expected) — the volume may be full"
            }
        }
    }
}

extension HwpPDFRenderError: LocalizedError {
    public var errorDescription: String? {
        description
    }
}

/// 페이지네이션된 `HwpDocument`를 CGPDFContext에 기록한다.
///
/// 뷰 계층과 무관하게 임의 `CGContext`에 그리는 `HwpPageLayer.draw(in:)`를
/// 그대로 쓴다 — 즉 화면과 같은 paint list, 같은 조판이다. flip 보정도 무분기다:
/// macOS의 독립 레이어는 `contentsAreFlipped() == false`라 스스로 뒤집고,
/// iOS는 CGPDFContext가 y-up(`ctm.d > 0`)이라 같은 가지로 들어온다.
///
/// 메모 패널(`HwpPage.memoPanel`)은 종이 밖 편집 화면 장식이라 `page.paintList`만
/// 그리는 이 경로에서 자연히 빠진다 (한글의 인쇄 뷰·PrvImage와 같다).
public enum HwpPDFRenderer {
    /// 문서를 `url`에 PDF로 기록한다. 페이지 하나씩 스트리밍하므로 상주 메모리는
    /// 1페이지 몫이다. 취소되면 부분 파일을 지우고 `CancellationError`를 던진다.
    public static func render(
        document: HwpDocument,
        to url: URL,
        onProgress: (@Sendable (HwpPDFExportProgress) -> Void)? = nil
    ) async throws {
        try await render(
            document: document,
            to: url,
            imageByteLimit: HwpPageImageProvider.defaultResolvedByteLimit,
            onProgress: onProgress
        )
    }

    /// 두 진입점이 공유하는 입력 계약 — 한 곳에만 두면 다른 경로가 조용히
    /// 뚫린다 (`emptyDocument` 가드가 실제로 복제돼 있었다).
    ///
    /// 프로그레시브 중간 스냅샷(`isComplete == false`)은 확정된 페이지 접두만
    /// 들고 있어, 그대로 내보내면 페이지가 빠진 PDF가 성공으로 나간다 — 열리고
    /// 페이지 수도 맞아 산출물 검증마저 통과한다. 접두를 의도적으로 내보내려면
    /// 호출자가 그 페이지로 문서를 직접 구성한다 (`isComplete` 기본값 true).
    static func validateInput(_ document: HwpDocument) throws {
        guard !document.pages.isEmpty else { throw HwpPDFRenderError.emptyDocument }
        guard document.metadata.isComplete else { throw HwpPDFRenderError.incompleteDocument }
    }

    /// `imageByteLimit`는 테스트가 예산 초과 경로를 작은 이미지로 재현하기 위한
    /// internal 이음매다 — 낮추면 정상 문서도 실패하므로 공개하지 않는다.
    static func render(
        document: HwpDocument,
        to url: URL,
        imageByteLimit: Int,
        onProgress: (@Sendable (HwpPDFExportProgress) -> Void)? = nil
    ) async throws {
        try validateInput(document)
        // 목적지에 직접 쓰지 않는다: `CGDataConsumer(url:)`는 **생성 순간** 그
        // 파일을 0바이트로 자르므로(실측), 취소·실패가 사용자의 이전 PDF를
        // 파괴한다. 임시 파일에 완성한 뒤에만 목적지를 건드린다.
        let staging = stagingDirectory(for: url)
        let stagingFile = staging.url
            .appendingPathComponent("hwp-pdf-export-\(UUID().uuidString).pdf")
        defer {
            try? FileManager.default.removeItem(at: stagingFile)
            if staging.isOwned {
                try? FileManager.default.removeItem(at: staging.url)
            }
        }
        guard let consumer = CGDataConsumer(url: stagingFile as CFURL) else {
            throw HwpPDFRenderError.fileWriteFailed(
                path: url.path, reason: "could not open a staging file for writing"
            )
        }
        try await write(
            document: document,
            consumer: consumer,
            imageByteLimit: imageByteLimit,
            onProgress: onProgress
        )
        try install(stagingFile, at: url, expectedPages: document.pages.count)
    }

    /// 다 쓴 PDF를 **실제로 열어 본다**. CG는 쓰기 실패를 로그로만 알린다 —
    /// `endPDFPage`/`closePDF`가 `Void`라 디스크가 차도 `write`가 정상 종료하고
    /// 절단 파일이 남는다 (실측: 6MB 볼륨에 11MB PDF → 열리지 않는 5.2MB 파일,
    /// 예외 없음). 그대로 설치하면 멀쩡하던 기존 PDF가 못 여는 파일로 바뀐다.
    static func validate(_ staging: URL, expectedPages: Int) throws {
        guard let pdf = CGPDFDocument(staging as CFURL) else {
            throw HwpPDFRenderError.incompleteOutput(
                expectedPages: expectedPages, writtenPages: nil
            )
        }
        guard pdf.numberOfPages == expectedPages else {
            throw HwpPDFRenderError.incompleteOutput(
                expectedPages: expectedPages, writtenPages: pdf.numberOfPages
            )
        }
    }

    /// 스테이징 자리는 목적지와 **같은 볼륨**이어야 한다 — `replaceItemAt`은 두
    /// 항목이 같은 볼륨일 것을 요구해서, 앱 임시 디렉터리에 두면 외장 드라이브의
    /// 기존 파일을 덮어쓸 때 EXDEV로 실패한다 (실측). `appropriateFor:`가 그
    /// 볼륨의 교체용 디렉터리를 준다.
    ///
    /// 그 자리를 못 얻으면 앱 임시 디렉터리로 돌아간다: 크로스 디바이스를 복사로
    /// 처리하는 `moveItem` 덕에 **새 파일 생성은 살고**, 그 볼륨의 덮어쓰기만
    /// 실패한다 (전부 실패시키는 것보다 낫다).
    private static func stagingDirectory(for url: URL) -> (url: URL, isOwned: Bool) {
        let replacement = try? FileManager.default.url(
            for: .itemReplacementDirectory,
            in: .userDomainMask,
            appropriateFor: url,
            create: true
        )
        guard let replacement else {
            return (FileManager.default.temporaryDirectory, false)
        }
        return (replacement, true)
    }

    /// 완성된 임시 파일을 목적지로 옮긴다. 검증을 **여기 안에** 두는 이유는
    /// 그것이 설치의 전제이기 때문이다 — 밖에 두면 호출을 빠뜨려도 테스트가
    /// 통과한다 (실제로 그랬다).
    static func install(_ staging: URL, at url: URL, expectedPages: Int) throws {
        try validate(staging, expectedPages: expectedPages)
        // 검증은 1,030쪽이면 짧지 않다 — 그 사이 도착한 취소를 여기서 안 보면
        // 목적지가 교체되고 호출자는 성공을 받는다 (종단 취소와 같은 불변식).
        try Task.checkCancellation()
        let manager = FileManager.default
        guard manager.fileExists(atPath: url.path) else {
            do {
                try manager.moveItem(at: staging, to: url)
            } catch {
                throw HwpPDFRenderError.fileWriteFailed(
                    path: url.path, reason: error.localizedDescription
                )
            }
            return
        }
        // 원본을 **우리가 정한 이름**으로 남긴다. 교체가 원본을 옮긴 뒤 실패하면
        // 목적지가 비는데 Foundation은 그 자리를 error userInfo로만 알려 주므로,
        // 이름을 알고 있어야 되돌릴 수 있다. 성공 시 백업은 Foundation이 지운다.
        // 목적지 이름에서 파생하지 않는다 — 긴 파일명에 접미사를 붙이면 이름
        // 한도(255바이트)를 넘겨 정상 경로가 깨진다.
        let backupName = ".hwp-export-backup-\(UUID().uuidString)"
        do {
            _ = try manager.replaceItemAt(url, withItemAt: staging, backupItemName: backupName)
        } catch {
            restoreBackup(named: backupName, at: url)
            throw HwpPDFRenderError.fileWriteFailed(
                path: url.path, reason: error.localizedDescription
            )
        }
    }

    /// 교체 실패로 남은 백업을 제자리로 되돌린다 — "실패는 목적지를 보존한다"가
    /// 실제로 성립하는 자리다.
    ///
    /// 백업이 남아 있다는 것은 교체가 원본을 옮긴 **뒤** 실패했다는 뜻이므로,
    /// 목적지에 무엇이 있든 원본이 이긴다. 스테이징까지 설치된 뒤(메타데이터
    /// 복사·백업 정리 단계) 실패하면 목적지에는 **새 PDF**가 있는데, 그것을 두고
    /// 백업만 지우면 실패를 보고하면서 사용자의 이전 파일을 잃는다.
    static func restoreBackup(named name: String, at url: URL) {
        let manager = FileManager.default
        let backup = url.deletingLastPathComponent().appendingPathComponent(name)
        guard manager.fileExists(atPath: backup.path) else { return }
        do {
            try manager.moveItem(at: backup, to: url)
        } catch {
            // 목적지가 비어 있지 않아 막힌 것 — 비우고 다시 넣는다. 이 순서라야
            // 되돌리기가 실패해도 백업이 디스크에 남아 복구 가능하다.
            try? manager.removeItem(at: url)
            try? manager.moveItem(at: backup, to: url)
        }
    }

    /// 문서를 PDF 바이트로 만든다 (전량이 메모리에 남는다 — 대형 문서는
    /// `render(document:to:)`의 파일 스트리밍 쪽을 쓸 것).
    public static func renderData(
        document: HwpDocument,
        onProgress: (@Sendable (HwpPDFExportProgress) -> Void)? = nil
    ) async throws -> Data {
        try validateInput(document)
        let buffer = NSMutableData()
        guard let consumer = CGDataConsumer(data: buffer as CFMutableData) else {
            throw HwpPDFRenderError.contextCreationFailed
        }
        try await write(
            document: document,
            consumer: consumer,
            imageByteLimit: HwpPageImageProvider.defaultResolvedByteLimit,
            onProgress: onProgress
        )
        return buffer as Data
    }

    private static func write(
        document: HwpDocument,
        consumer: CGDataConsumer,
        imageByteLimit: Int,
        onProgress: (@Sendable (HwpPDFExportProgress) -> Void)?
    ) async throws {
        // 페이지마다 mediaBox를 따로 주므로 컨텍스트 기본값은 첫 페이지 크기로
        // 둔다 (용지 방향·구역별 용지 크기가 다르면 페이지별 값이 이긴다).
        var defaultBox = CGRect(origin: .zero, size: document.pages[0].size)
        guard let context = CGContext(
            consumer: consumer, mediaBox: &defaultBox, documentInfo(of: document)
        ) else {
            throw HwpPDFRenderError.contextCreationFailed
        }
        // 이미지는 문서 전용 provider와 **전용 캐시**로 해석한다 — 캐시가
        // binItemId 하나로 키를 잡으므로, 캐시를 문서 간에 공유하면 provider를
        // 새로 만들어도 다른 문서의 비트맵이 그대로 히트한다.
        //
        // 캐시도 같은 예산으로 만든다 — 기본값(256MB)을 그대로 두면 provider의
        // 변형 예산과 **독립으로** 쌓여 상한이 두 배가 된다. 그 두 예산을 함께
        // 거는 자리는 비트맵 렌더러와 공유한다 (한쪽만 낮추는 실수를 구조로 막는다).
        let provider = HwpPageBitmapRenderer.makeProvider(
            for: document.imageStore, imageByteLimit: imageByteLimit
        )
        defer { provider?.cancelOutstanding() }

        for (index, page) in document.pages.enumerated() {
            try Task.checkCancellation()
            if let provider {
                // 이 페이지 변형만 남기고(고정 교체 + 이전 페이지 해제) 확정까지
                // 기다린 뒤, 남은 미확정을 오류로 끝내는 순서 — 비트맵 렌더러와
                // 같은 구현이다. 뷰는 다음 재드로우가 되살리지만 여기는 draw가
                // 한 번뿐이라, 회색 로딩 사각형을 PDF에 박아 넣는 대신 실패한다
                // (디코드 실패는 제외 — 그건 뷰와 같이 플레이스홀더가 정답이다).
                do {
                    try await HwpPageBitmapRenderer.resolveImages(
                        in: page, provider: provider, policy: .fail
                    )
                } catch let error as HwpPageBitmapRenderError {
                    guard case .unresolvedImages = error else { throw error }
                    // 미확정이 남았다 = 이 페이지 작업셋이 바이트 예산을 넘겨
                    // 축출된 것이다. PDF는 쪽 번호를 실어 알린다.
                    throw HwpPDFRenderError.pageImagesExceedMemoryBudget(pageIndex: index)
                }
            }
            context.beginPDFPage(pageInfo(for: page))
            // 종이 배경 + 레이어 구성 + draw는 비트맵 렌더러와 한 자리를 쓴다 —
            // 갈라 두면 flip·배경·레이어 필드 중 하나가 한쪽에서만 바뀐다.
            HwpPageBitmapRenderer.draw(page: page, in: context, provider: provider)
            context.endPDFPage()
            onProgress?(
                HwpPDFExportProgress(pageIndex: index, pageCount: document.pages.count)
            )
        }
        context.closePDF()
        // 마지막 페이지의 draw·진행 콜백에서 들어온 취소는 다음 반복이 없어
        // 루프 안의 어떤 확인도 보지 못한다 — 호출부가 부분 파일을 지우도록
        // 여기서 한 번 더 본다.
        try Task.checkCancellation()
    }

    /// 페이지 크기를 mediaBox로 넘긴다. 값은 **CGRect를 값째 담은 CFData**여야
    /// 한다 (참조 전달이 아니다) — 형식이 틀리면 CG가 조용히 기본 상자를 쓴다.
    private static func pageInfo(for page: HwpPage) -> CFDictionary {
        var box = CGRect(origin: .zero, size: page.size)
        let boxData = withUnsafeBytes(of: &box) { Data($0) }
        return [kCGPDFContextMediaBox: boxData as CFData] as CFDictionary
    }

    private static func documentInfo(of document: HwpDocument) -> CFDictionary {
        var info: [CFString: Any] = [kCGPDFContextCreator: "hwp-swift"]
        if let title = document.metadata.title, !title.isEmpty {
            info[kCGPDFContextTitle] = title
        }
        return info as CFDictionary
    }
}
