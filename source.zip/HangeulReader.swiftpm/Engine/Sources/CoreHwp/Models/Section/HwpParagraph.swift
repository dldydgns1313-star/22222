import Foundation

/**
 본문 문단 하나로, 텍스트(`paraText`), 글자 모양 적용 구간
 (`paraCharShape`), 줄 배치 정보(`paraLineSeg`), 표·그림 같은 컨트롤을 함께
 담는다. 글자 모양·문단 모양·스타일·글꼴 정의는
 `HwpDocInfo.idMappings`에 있다. 글자 모양은
 `paraCharShape.shapeId`로, 문단 모양과 스타일은 `paraHeader.paraShapeId`·
 `paraHeader.paraStyleId`로 참조하며, 글자 모양은 다시 글꼴 정의를 참조한다.
 */
public struct HwpParagraph: HwpTagValidatedRecordWithVersion {
    static let expectedTag: HwpSectionTag = .paraHeader

    public var paraHeader: HwpParaHeader

    public var paraText: HwpParaText?
    public var paraCharShape: HwpParaCharShape
    public var paraLineSeg: HwpParaLineSeg
    public var ctrlHeaderArray: [HwpCtrlId]?
    public var paraRangeTagArray: [HwpParaRangeTag]?
    public var listHeaderArray: [HwpListHeader]?
    /// 메모 (댓글) 본문 문단 — MEMO_LIST(93) 뒤에 오는 문단(66) 자식.
    /// 한글.app 편집 뷰의 오른쪽 풍선에 표시되는 내용이다.
    public var memoParagraphArray: [HwpParagraph]?
    /// 메모별 문단 그룹 — 각 MEMO_LIST(93)가 여는 메모 단위로 뒤따르는 문단(66)을
    /// 묶는다. memoParagraphArray는 이를 평탄화한 것으로, 메모 하나가 여러 문단
    /// (Enter)이면 그룹을 join해 풍선 본문을 만든다 (평탄 배열은 경계를 잃어 다중
    /// 문단 메모/다중 메모가 필드와 어긋난다).
    public var memoParagraphGroups: [[HwpParagraph]]?
    @ExcludeEquatable
    public var unknownChildren: [HwpUnknownRecord]
    /// `HwpLoadOptions.recoverPartialContent` 복구 모드에서 이 문단이 파싱
    /// 실패를 placeholder로 대체한 것이면 그 원인 설명. 정상 파싱은 nil.
    /// 진단 표면이므로 Equatable/Hashable에 참여한다 — placeholder와 진짜
    /// 빈 문단이 같다고 판정되면 복구 흔적이 비교에서 지워진다.
    public var parseFailure: String?

    public init() {
        paraHeader = HwpParaHeader()
        paraText = HwpParaText()
        paraCharShape = HwpParaCharShape()
        paraLineSeg = HwpParaLineSeg()
        paraRangeTagArray = [HwpParaRangeTag]()
        listHeaderArray = [HwpListHeader]()
        unknownChildren = []
        ctrlHeaderArray = nil
        memoParagraphArray = nil
        memoParagraphGroups = nil
        parseFailure = nil
    }

    /// 새 문서의 첫 문단. 구역/단 정의 컨트롤은 구역의 첫 문단에만 붙는다는
    /// 파싱 경로 불변식이 있으므로 일반 `init()`에는 포함하지 않는다.
    public static func blankDocumentParagraph() -> HwpParagraph {
        var paragraph = HwpParagraph()
        paragraph.ctrlHeaderArray = [
            .section(HwpSectionDef()),
            .column(HwpColumn()),
        ]
        return paragraph
    }

    /// 복구 모드에서 파싱에 실패한 문단을 대신하는 placeholder.
    /// `paraText = nil`인 이유: 기본 문단은 extended char 2개를 갖는데
    /// ctrlHeaderArray가 없으면 컨트롤 매칭이 어긋난다 — paraText 부재
    /// 문단은 하류 run builder가 이미 빈 문단으로 처리한다. 원본 레코드는
    /// `unknownChildren`에 통째로 보존해 진단·재파싱 근거를 남긴다 (#65).
    static func parseFailurePlaceholder(record: HwpRecord, error: HwpError) -> HwpParagraph {
        var paragraph = HwpParagraph()
        paragraph.paraText = nil
        paragraph.unknownChildren = [HwpUnknownRecord(record)]
        paragraph.parseFailure = String(describing: error)
        return paragraph
    }

    // MARK: loader contract exemption - paragraph header payload is forwarded to versioned loader

    // swiftlint:disable:next cyclomatic_complexity function_body_length
    init(_ reader: inout DataReader, _ children: [HwpRecord], _ version: HwpVersion) throws {
        let options = reader.options
        paraHeader = try HwpParaHeader.load(try reader.readToEnd(), version, options: options)

        if let paraText = children
            .first(where: { $0.tagId == HwpSectionTag.paraText.rawValue })
        {
            let loadedParaText = try HwpParaText.load(paraText.payload, options: options)
            self.paraText = loadedParaText
            try Self.validateParaTextCount(paraHeader, loadedParaText)
        }

        guard let paraCharShape = children
            .first(where: { $0.tagId == HwpSectionTag.paraCharShape.rawValue })
        else {
            throw HwpError.recordDoesNotExist(tag: HwpSectionTag.paraCharShape.rawValue)
        }
        self.paraCharShape = try HwpParaCharShape.load(paraCharShape.payload, options: options)
        try Self.validateParaCharShapeCount(paraHeader, self.paraCharShape)

        if let paraLineSeg = children
            .first(where: { $0.tagId == HwpSectionTag.paraLineSeg.rawValue })
        {
            self.paraLineSeg = try HwpParaLineSeg.load(paraLineSeg.payload, options: options)
            if !paraLineSeg.payload.isEmpty {
                try Self.validateParaLineSegCount(paraHeader, self.paraLineSeg)
            }
        } else {
            // Some Hancom-saved compatibility documents omit this layout cache.
            paraLineSeg = try HwpParaLineSeg.load(Data(), options: options)
        }

        paraRangeTagArray = try children
            .filter { $0.tagId == HwpSectionTag.paraRangeTag.rawValue }
            .flatMap { try HwpParaRangeTag.loadArray($0.payload, options: options) }
        try Self.validateParaRangeTagCount(paraHeader, paraRangeTagArray ?? [])

        ctrlHeaderArray = try children
            .filter { $0.tagId == HwpSectionTag.ctrlHeader.rawValue }
            .map {
                let header = try HwpCtrlHeader.load($0)
                let ctrlId = header.ctrlId
                if let common = HwpCommonCtrlId(rawValue: ctrlId) {
                    if common == .table {
                        return try Self.tableOrNotImplemented($0, version)
                    } else if common == .genShapeObject {
                        return try Self.genShapeObjectOrNotImplemented($0, version)
                    }
                    return try Self.commonShapeControl($0, common, version)
                } else if let other = HwpOtherCtrlId(rawValue: ctrlId) {
                    if other == .column {
                        return try Self.columnOrOther($0)
                    } else if other == .section {
                        return try Self.sectionDefOrOther($0, version)
                    } else if other == .pageNumberPosition {
                        return try Self.pageNumberPositionOrOther($0)
                    } else if other == .header {
                        return try Self.listControlOrOther($0, .header, version)
                    } else if other == .footer {
                        return try Self.listControlOrOther($0, .footer, version)
                    } else if other == .footnote {
                        return try Self.listControlOrOther($0, .footnote, version)
                    } else if other == .endnote {
                        return try Self.listControlOrOther($0, .endnote, version)
                    }
                    return try Self.otherControl($0, other)
                } else if let field = HwpFieldCtrlId(rawValue: ctrlId) {
                    if field == .hyperLink {
                        return try Self.hyperLinkOrField($0)
                    }
                    let control = try HwpFieldControl.load($0)
                    if control.isMemoField {
                        return .memo(control)
                    }
                    if control.isRevisionField {
                        return .revision(control)
                    }
                    return .field(control)
                } else {
                    return .unknown(header)
                }
            }

        listHeaderArray = try children
            .filter { $0.tagId == HwpSectionTag.listHeader.rawValue }
            .map { try HwpListHeader.load($0.payload, options: options) }

        // MEMO_LIST(93)가 메모 하나를 열고, 그 뒤 문단(66)들이 그 메모의 본문이다.
        // 메모별 그룹을 보존해야 여러 문단짜리 메모/다중 메모가 필드와 어긋나지 않는다.
        var consumedMemoChildIndexes = Set<Int>()
        if children.contains(where: { $0.tagId == HwpSectionTag.memoList.rawValue }) {
            var groups: [[HwpParagraph]] = []
            var current: [HwpParagraph]?
            for (index, child) in children.enumerated() {
                if child.tagId == HwpSectionTag.memoList.rawValue {
                    if let current {
                        groups.append(current)
                    }
                    current = []
                    consumedMemoChildIndexes.insert(index)
                } else if child.tagId == HwpSectionTag.paraHeader.rawValue, current != nil {
                    // 복구 모드에서는 손상 메모 문단도 placeholder로 대체한다 —
                    // 그대로 전파시키면 호스트 문단 전체가 placeholder가 되어
                    // 본문 텍스트까지 잃고, 메모별 그룹 경계도 함께 사라진다 (#65).
                    do {
                        current?.append(try HwpParagraph.load(child, version))
                    } catch let error as HwpError
                        where options.recoverPartialContent && !error.isRecoveryExempt
                    {
                        current?.append(.parseFailurePlaceholder(record: child, error: error))
                    }
                    consumedMemoChildIndexes.insert(index)
                }
            }
            if let current {
                groups.append(current)
            }
            memoParagraphGroups = groups.isEmpty ? nil : groups
            let flat = groups.flatMap { $0 }
            memoParagraphArray = flat.isEmpty ? nil : flat
        }

        unknownChildren = Self.unconsumedRecords(
            from: children,
            consumedMemoChildIndexes: consumedMemoChildIndexes
        ).map(HwpUnknownRecord.init)
    }
}

private extension HwpParagraph {
    /// 메모 계열(MEMO_LIST·메모 문단)은 태그가 아니라 **실제 소비한 child
    /// 인덱스**로 제외한다. 태그 blanket 제외는 첫 MEMO_LIST 앞의 stray
    /// 문단(66) record처럼 그룹 빌더가 소비하지 않은 record까지 삼켜, typed
    /// 소비도 raw 보존도 없이 모델에서 사라지게 했다 — 미해석 요소 집계
    /// (`parseDiagnostics`)가 구조적으로 볼 수 없는 유실이라 #66에서 고쳤다.
    static func unconsumedRecords(
        from children: [HwpRecord],
        consumedMemoChildIndexes: Set<Int>
    ) -> [HwpRecord] {
        var consumedSingletons = Set<UInt32>()

        return children.enumerated().filter { index, child in
            if multiRecordTags.contains(child.tagId) {
                return false
            }

            if consumedMemoChildIndexes.contains(index) {
                return false
            }

            if singletonRecordTags.contains(child.tagId) {
                if consumedSingletons.contains(child.tagId) {
                    return true
                }
                consumedSingletons.insert(child.tagId)
                return false
            }

            return true
        }.map(\.element)
    }

    static var singletonRecordTags: Set<UInt32> {
        [
            HwpSectionTag.paraText.rawValue,
            HwpSectionTag.paraCharShape.rawValue,
            HwpSectionTag.paraLineSeg.rawValue,
        ]
    }

    static var multiRecordTags: Set<UInt32> {
        [
            HwpSectionTag.paraRangeTag.rawValue,
            HwpSectionTag.ctrlHeader.rawValue,
            HwpSectionTag.listHeader.rawValue,
        ]
    }

    static func validateParaTextCount(
        _ header: HwpParaHeader,
        _ text: HwpParaText
    ) throws {
        let expectedCount = Int(header.charCount)
        // rawPayload는 보존 off 모드에서 비므로 파싱된 charArray 기반
        // 계산값을 양 모드 공통으로 쓴다 (wchar 수 == payload byte / 2).
        let actualCount = text.wcharCount
        guard expectedCount == actualCount else {
            throw HwpError.invalidRecordTree(
                reason:
                """
                paragraph text count mismatch: header declares \(expectedCount), \
                PARA_TEXT contains \(actualCount)
                """
            )
        }
    }

    static func validateParaCharShapeCount(
        _ header: HwpParaHeader,
        _ charShape: HwpParaCharShape
    ) throws {
        let expectedCount = Int(header.charShapeInfoCount)
        let actualCount = charShape.startingIndex.count
        guard expectedCount == actualCount else {
            throw HwpError.invalidRecordTree(
                reason:
                """
                paragraph char shape count mismatch: header declares \(expectedCount), \
                PARA_CHAR_SHAPE contains \(actualCount)
                """
            )
        }
    }

    static func validateParaLineSegCount(
        _ header: HwpParaHeader,
        _ lineSeg: HwpParaLineSeg
    ) throws {
        let expectedCount = Int(header.alignInfoCount)
        let actualCount = lineSeg.paraLineSegInternalArray.count
        guard expectedCount == actualCount else {
            throw HwpError.invalidRecordTree(
                reason:
                """
                paragraph line segment count mismatch: header declares \(expectedCount), \
                PARA_LINE_SEG contains \(actualCount)
                """
            )
        }
    }

    static func validateParaRangeTagCount(
        _ header: HwpParaHeader,
        _ rangeTags: [HwpParaRangeTag]
    ) throws {
        let expectedCount = Int(header.rangeTagInfoCount)
        let actualCount = rangeTags.count
        guard expectedCount == actualCount else {
            throw HwpError.invalidRecordTree(
                reason:
                """
                paragraph range tag count mismatch: header declares \(expectedCount), \
                PARA_RANGE_TAG contains \(actualCount)
                """
            )
        }
    }

    static func genShapeObjectOrNotImplemented(
        _ record: HwpRecord,
        _ version: HwpVersion
    ) throws -> HwpCtrlId {
        do {
            return try .genShapeObject(HwpGenShapeObject.load(record, version))
        } catch let error as HwpError {
            guard error.canFallbackToRawGenShapeObject else {
                throw error
            }
            return try .notImplemented(HwpCtrlHeader.load(record))
        }
    }

    // swiftlint:disable:next cyclomatic_complexity
    static func commonShapeControl(
        _ record: HwpRecord,
        _ ctrlId: HwpCommonCtrlId,
        _ version: HwpVersion
    ) throws -> HwpCtrlId {
        let control: HwpShapeControl
        do {
            control = try HwpShapeControl.load(record, version)
        } catch let error as HwpError {
            guard error.canFallbackToRawGenShapeObject else {
                throw error
            }
            return try .notImplemented(HwpCtrlHeader.load(record))
        }

        switch ctrlId {
        case .line:
            return .line(control)
        case .rectangle:
            return .rectangle(control)
        case .ellipse:
            return .ellipse(control)
        case .arc:
            return .arc(control)
        case .polygon:
            return .polygon(control)
        case .curve:
            return .curve(control)
        case .equation:
            return .equation(control)
        case .equationLegacy:
            return .equationLegacy(control)
        case .picture:
            return .picture(control)
        case .ole:
            return .ole(control)
        case .container:
            return .container(control)
        case .table, .genShapeObject:
            throw HwpError.invalidRecordTree(
                reason: "common shape control \(ctrlId) was dispatched through common shape parser"
            )
        }
    }

    static func tableOrNotImplemented(
        _ record: HwpRecord,
        _ version: HwpVersion
    ) throws -> HwpCtrlId {
        do {
            return try .table(HwpTable.load(record, version))
        } catch let error as HwpError {
            guard error.canFallbackToRawControl else {
                throw error
            }
            return try .notImplemented(HwpCtrlHeader.load(record))
        }
    }

    static func hyperLinkOrField(_ record: HwpRecord) throws -> HwpCtrlId {
        do {
            return try .hyperLink(HwpHyperlink.load(record))
        } catch let error as HwpError {
            guard error.canFallbackToRawControl else {
                throw error
            }
            return try .field(HwpFieldControl.load(record))
        }
    }

    static func pageNumberPositionOrOther(_ record: HwpRecord) throws -> HwpCtrlId {
        do {
            return try .pageNumberPosition(HwpPageNumberPosition.load(record))
        } catch let error as HwpError {
            guard error.canFallbackToRawControl else {
                throw error
            }
            return try .other(HwpOtherControl.load(record))
        }
    }

    static func columnOrOther(_ record: HwpRecord) throws -> HwpCtrlId {
        do {
            return try .column(HwpColumn.load(record))
        } catch let error as HwpError {
            guard error.canFallbackToRawControl else {
                throw error
            }
            return try .other(HwpOtherControl.load(record))
        }
    }

    static func sectionDefOrOther(_ record: HwpRecord, _ version: HwpVersion) throws -> HwpCtrlId {
        do {
            return try .section(HwpSectionDef.load(record, version))
        } catch let error as HwpError {
            guard error.canFallbackToRawControl else {
                throw error
            }
            return try .other(HwpOtherControl.load(record))
        }
    }

    static func listControlOrOther(
        _ record: HwpRecord,
        _ ctrlId: HwpOtherCtrlId,
        _ version: HwpVersion
    ) throws -> HwpCtrlId {
        do {
            let control = try HwpListControl.load(record, version)
            switch ctrlId {
            case .header:
                return .header(control)
            case .footer:
                return .footer(control)
            case .footnote:
                return .footnote(control)
            case .endnote:
                return .endnote(control)
            default:
                return .other(try HwpOtherControl.load(record))
            }
        } catch let error as HwpError {
            guard error.canFallbackToRawListControl else {
                throw error
            }
            return try .other(HwpOtherControl.load(record))
        }
    }

    // swiftlint:disable:next cyclomatic_complexity
    static func otherControl(_ record: HwpRecord, _ ctrlId: HwpOtherCtrlId) throws -> HwpCtrlId {
        let control = try HwpOtherControl.load(record)
        switch ctrlId {
        case .form:
            return .form(control)
        case .autoNumber:
            return .autoNumber(control)
        case .newNumber:
            return .newNumber(control)
        case .pageHide:
            return .pageHide(control)
        case .pageCT:
            return .pageCT(control)
        case .indexmark:
            return .indexmark(control)
        case .bookmark:
            return .bookmark(control)
        case .overlapping:
            return .overlapping(control)
        case .comment:
            return .comment(control)
        case .hiddenComment:
            return .hiddenComment(control)
        default:
            return .other(control)
        }
    }
}

private extension HwpError {
    var canFallbackToRawControl: Bool {
        switch self {
        case .truncatedData, .invalidUnicodeScalar, .invalidRawValueForEnum:
            true
        default:
            false
        }
    }

    var canFallbackToRawListControl: Bool {
        switch self {
        case .recordDoesNotExist, .invalidRecordTree:
            true
        default:
            canFallbackToRawControl
        }
    }

    var canFallbackToRawGenShapeObject: Bool {
        switch self {
        case .invalidRecordTree:
            true
        default:
            canFallbackToRawControl
        }
    }
}
