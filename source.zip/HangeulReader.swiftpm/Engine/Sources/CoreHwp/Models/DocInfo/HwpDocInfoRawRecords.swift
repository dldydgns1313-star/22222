import Foundation

/**
 문서 데이터

 Tag ID : HWPTAG_DOC_DATA
 */
public struct HwpDocData: HwpTagValidatedRecord {
    static let expectedTag: HwpDocInfoTag = .docData

    public let rawPayload: Data
    public let docDataInfo: HwpDocDataInfo?
    public let forbiddenCharArray: [HwpForbiddenChar]
    public let unknownChildren: [HwpUnknownRecord]

    // MARK: loader contract exemption - DOC_DATA payload is retained for best-effort views

    init(_ reader: inout DataReader, _ children: [HwpRecord]) throws {
        let payload = try reader.readToEnd()
        rawPayload = reader.options.preservedPayload(payload)
        docDataInfo = Self.docDataInfo(from: payload, options: reader.options)
        forbiddenCharArray = try children
            .filter { $0.tagId == HwpDocInfoTag.forbiddenChar.rawValue }
            .map(HwpForbiddenChar.load)
        unknownChildren = children
            .filter { $0.tagId != HwpDocInfoTag.forbiddenChar.rawValue }
            .map(HwpUnknownRecord.init)
    }
}

/** 문서 데이터의 알려진 32-bit word payload */
public struct HwpDocDataInfo: HwpPrimitive {
    /** 해석 전 단계로 노출하는 little-endian 32-bit word 값 */
    public let values: [UInt32]
    /** 32-bit word 값들의 원문 payload */
    public let valuesRawPayload: Data
    /** 32-bit word로 나누어 떨어지지 않는 아직 해석하지 않은 payload */
    public let rawTrailing: Data
}

/**
 배포용 문서 데이터

 Tag ID : HWPTAG_DISTRIBUTE_DOC_DATA
 */
public struct HwpDistributeDocData: HwpTagValidatedRecord {
    static let expectedTag: HwpDocInfoTag = .distributeDocData

    public let rawPayload: Data
    public let distributeDocDataInfo: HwpDistributeDocDataInfo?
    public let unknownChildren: [HwpUnknownRecord]

    // MARK: loader contract exemption - DISTRIBUTE_DOC_DATA payload is retained as raw data

    init(_ reader: inout DataReader, _ children: [HwpRecord]) throws {
        let payload = try reader.readToEnd()
        rawPayload = reader.options.preservedPayload(payload)
        distributeDocDataInfo = Self.distributeDocDataInfo(from: payload, options: reader.options)
        unknownChildren = children.map(HwpUnknownRecord.init)
    }
}

/** 배포용 문서 데이터의 알려진 32-bit word payload */
public struct HwpDistributeDocDataInfo: HwpPrimitive {
    /** 해석 전 단계로 노출하는 little-endian 32-bit word 값 */
    public let values: [UInt32]
    /** 32-bit word 값들의 원문 payload */
    public let valuesRawPayload: Data
    /** 32-bit word로 나누어 떨어지지 않는 아직 해석하지 않은 payload */
    public let rawTrailing: Data
}

/**
 변경 추적 정보

 Tag ID : HWPTAG_TRACK_CHANGE
 */
public struct HwpTrackChange: HwpTagValidatedRecord {
    static let expectedTag: HwpDocInfoTag = .trackChange

    public let rawPayload: Data
    public let trackChangeInfo: HwpTrackChangeInfo?
    public let unknownChildren: [HwpUnknownRecord]

    // MARK: loader contract exemption - TRACK_CHANGE payload is retained for best-effort views

    init(_ reader: inout DataReader, _ children: [HwpRecord]) throws {
        let payload = try reader.readToEnd()
        rawPayload = reader.options.preservedPayload(payload)
        trackChangeInfo = Self.trackChangeInfo(from: payload, options: reader.options)
        unknownChildren = children.map(HwpUnknownRecord.init)
    }
}

/** 변경 추적 정보의 알려진 선행 payload */
public struct HwpTrackChangeInfo: HwpPrimitive {
    /** 선행 32-bit 값 */
    public let headerValue: UInt32
    /** 선행 32-bit 값의 원문 payload */
    public let headerRawPayload: Data
    /** 선행 값 이후의 아직 해석하지 않은 payload */
    public let rawTrailing: Data
}

/**
 메모 모양

 Tag ID : HWPTAG_MEMO_SHAPE
 */
public struct HwpMemoShape: HwpTagValidatedRecord {
    static let expectedTag: HwpDocInfoTag = .memoShape

    public let rawPayload: Data
    public let shapeInfo: HwpMemoShapeInfo?
    public let unknownChildren: [HwpUnknownRecord]

    // MARK: loader contract exemption - MEMO_SHAPE payload is retained for best-effort views

    init(_ reader: inout DataReader, _ children: [HwpRecord]) throws {
        let payload = try reader.readToEnd()
        rawPayload = reader.options.preservedPayload(payload)
        shapeInfo = Self.shapeInfo(from: payload, options: reader.options)
        unknownChildren = children.map(HwpUnknownRecord.init)
    }
}

/** 메모 모양의 알려진 고정 폭 payload */
public struct HwpMemoShapeInfo: HwpPrimitive {
    /** 폭 */
    public let width: UInt32
    /** 선 종류 */
    public let lineType: UInt8
    /** 선 굵기 */
    public let lineWidth: UInt8
    /** 선 색상 */
    public let lineColor: HwpColor
    /** 채우기 색상 */
    public let fillColor: HwpColor
    /** 활성 상태 색상 */
    public let activeColor: HwpColor
    /** 알려진 고정 폭 필드의 원문 payload */
    public let fixedFieldsRawPayload: Data
    /** 알려진 고정 폭 필드 이후의 아직 해석하지 않은 payload */
    public let rawTrailing: Data
}

/**
 변경 추적 내용

 Tag ID : HWPTAG_TRACK_CHANGE_CONTENT
 */
public struct HwpTrackChangeContent: HwpTagValidatedRecord {
    static let expectedTag: HwpDocInfoTag = .trackChangeContent

    public let rawPayload: Data
    public let contentInfo: HwpTrackChangeContentInfo?
    public let unknownChildren: [HwpUnknownRecord]

    // MARK: loader contract exemption - TRACK_CHANGE_CONTENT payload is retained for views

    init(_ reader: inout DataReader, _ children: [HwpRecord]) throws {
        let payload = try reader.readToEnd()
        rawPayload = reader.options.preservedPayload(payload)
        contentInfo = Self.contentInfo(from: payload, options: reader.options)
        unknownChildren = children.map(HwpUnknownRecord.init)
    }
}

/** 변경 추적 내용의 알려진 payload */
public struct HwpTrackChangeContentInfo: HwpPrimitive {
    /** 변경 내용 종류 */
    public let kind: UInt32
    /** 변경 내용 종류 원문 payload */
    public let kindRawPayload: Data
    /** 변경 시각 */
    public let timestamp: HwpTrackChangeTimestamp
    /** 변경 시각 원문 payload */
    public let timestampRawPayload: Data
    /** 변경 시각 이후의 아직 해석하지 않은 payload */
    public let rawTrailing: Data
}

/** 변경 추적 시각 */
public struct HwpTrackChangeTimestamp: HwpPrimitive {
    public let year: UInt16
    public let month: UInt16
    public let day: UInt16
    public let hour: UInt16
    public let minute: UInt16
}

/**
 변경 추적 작성자

 Tag ID : HWPTAG_TRACK_CHANGE_AUTHOR
 */
public struct HwpTrackChangeAuthor: HwpTagValidatedRecord {
    static let expectedTag: HwpDocInfoTag = .trackChangeAuthor

    public let rawPayload: Data
    public let authorInfo: HwpTrackChangeAuthorInfo?
    public let unknownChildren: [HwpUnknownRecord]

    // MARK: loader contract exemption - TRACK_CHANGE_AUTHOR payload is retained for views

    init(_ reader: inout DataReader, _ children: [HwpRecord]) throws {
        let payload = try reader.readToEnd()
        rawPayload = reader.options.preservedPayload(payload)
        authorInfo = Self.authorInfo(from: payload, options: reader.options)
        unknownChildren = children.map(HwpUnknownRecord.init)
    }
}

/** 변경 추적 작성자의 알려진 payload */
public struct HwpTrackChangeAuthorInfo: HwpPrimitive {
    /** 작성자 이름 */
    public let name: String
    /** 작성자 이름 길이 원문 payload */
    public let nameLengthRawPayload: Data
    /** 작성자 이름 원문 WCHAR payload */
    public let nameRawPayload: Data
    /** 작성자 이름 이후의 아직 해석하지 않은 payload */
    public let rawTrailing: Data
}

/// `HwpTagValidatedRecord` 도입(#83)으로 프로덕션 호출부는 모두 프로토콜
/// default `load`로 옮겨졌다 — 임의 `HwpFromRecord` 타입에 DocInfo tag 검증을
/// 조합하는 이 진입점은 tag-검증 typed-error 계약 테스트가 사용한다.
/// 검증 후에는 `T`의 `load` 의미론을 그대로 따르므로 tag-검증 채택 타입을
/// 넘기면 타입 고유 `expectedTag`로 한 번 더 검증된다.
func loadDocInfoRecord<T: HwpFromRecord>(
    _ record: HwpRecord,
    expectedTag: HwpDocInfoTag,
    as type: T.Type
) throws -> T {
    try validateDocInfoRecordTag(record, expectedTag: expectedTag)
    return try type.load(record)
}

func validateDocInfoRecordTag(
    _ record: HwpRecord,
    expectedTag: HwpDocInfoTag
) throws {
    guard record.tagId == expectedTag.rawValue else {
        throw HwpError.invalidRecordTree(
            reason: "expected DocInfo tag \(expectedTag.rawValue), got \(record.tagId)"
        )
    }
}

private extension HwpDocData {
    static func docDataInfo(from payload: Data, options: HwpLoadOptions) -> HwpDocDataInfo? {
        guard let parsed = payload.littleEndianUInt32ArrayWithTrailing(
            minimumValueCount: 1
        ) else {
            return nil
        }

        return HwpDocDataInfo(
            values: parsed.values,
            valuesRawPayload: options.preservedPayload(
                payload.uint32ValuesRawPayload(valueCount: parsed.values.count)
            ),
            rawTrailing: options.preservedPayload(parsed.rawTrailing)
        )
    }
}

private extension HwpDistributeDocData {
    static func distributeDocDataInfo(
        from payload: Data,
        options: HwpLoadOptions
    ) -> HwpDistributeDocDataInfo? {
        guard let parsed = payload.littleEndianUInt32ArrayWithTrailing(
            minimumValueCount: 1
        ) else {
            return nil
        }

        return HwpDistributeDocDataInfo(
            values: parsed.values,
            valuesRawPayload: options.preservedPayload(
                payload.uint32ValuesRawPayload(valueCount: parsed.values.count)
            ),
            rawTrailing: options.preservedPayload(parsed.rawTrailing)
        )
    }
}

private extension Data {
    /// 분리 복사 — 스트림 버퍼 슬라이스를 typed view에 남기지 않는다.
    func uint32ValuesRawPayload(valueCount: Int) -> Data {
        Data(prefix(valueCount * MemoryLayout<UInt32>.size))
    }
}

private extension HwpTrackChangeAuthor {
    /// Best-effort typed view: malformed author metadata leaves rawPayload intact.
    static func authorInfo(from payload: Data, options: HwpLoadOptions) -> HwpTrackChangeAuthorInfo? {
        let lengthByteCount = MemoryLayout<UInt32>.size
        let characterByteCount = MemoryLayout<UInt16>.size
        guard payload.count >= lengthByteCount else {
            return nil
        }

        do {
            let rawCharacterCount = try payload.readLittleEndianUInt32(at: 0)
            // 32비트 Int(watchOS arm64_32)에선 Int.max 초과 count의 변환·길이 곱이
            // payload 크기 가드 전에 트랩한다 — failable 변환 + 오버플로 검사로
            // malformed 메타데이터를 nil로 돌려준다 (P1, HwpEmbeddedChart와 동일).
            guard let characterCount = Int(exactly: rawCharacterCount) else {
                return nil
            }
            let byteCountResult = characterCount
                .multipliedReportingOverflow(by: characterByteCount)
            let nameOffset = lengthByteCount
            guard !byteCountResult.overflow else {
                return nil
            }
            let byteCount = byteCountResult.partialValue
            let endResult = nameOffset.addingReportingOverflow(byteCount)
            guard !endResult.overflow, payload.count >= endResult.partialValue else {
                return nil
            }

            let nameRawPayload = Data(payload.dropFirst(nameOffset).prefix(byteCount))
            let name = try (0 ..< characterCount).map { index in
                try nameRawPayload.readLittleEndianUInt16(at: index * characterByteCount)
            }.string

            let trailingOffset = lengthByteCount + byteCount
            return HwpTrackChangeAuthorInfo(
                name: name,
                nameLengthRawPayload: options.preservedPayload(Data(payload.prefix(lengthByteCount))),
                nameRawPayload: options.preservedPayload(nameRawPayload),
                rawTrailing: options.preservedPayload(Data(payload.dropFirst(trailingOffset)))
            )
        } catch {
            return nil
        }
    }
}

private extension HwpTrackChange {
    static func trackChangeInfo(from payload: Data, options: HwpLoadOptions) -> HwpTrackChangeInfo? {
        let knownByteCount = MemoryLayout<UInt32>.size
        guard payload.count >= knownByteCount else {
            return nil
        }

        do {
            return HwpTrackChangeInfo(
                headerValue: try payload.readLittleEndianUInt32(at: 0),
                headerRawPayload: options.preservedPayload(Data(payload.prefix(knownByteCount))),
                rawTrailing: options.preservedPayload(Data(payload.dropFirst(knownByteCount)))
            )
        } catch {
            return nil
        }
    }
}

private extension HwpTrackChangeContent {
    static func contentInfo(
        from payload: Data,
        options: HwpLoadOptions
    ) -> HwpTrackChangeContentInfo? {
        let kindByteCount = MemoryLayout<UInt32>.size
        let timestampByteCount = MemoryLayout<UInt16>.size * 5
        let knownByteCount = kindByteCount + timestampByteCount
        guard payload.count >= knownByteCount else {
            return nil
        }

        do {
            return HwpTrackChangeContentInfo(
                kind: try payload.readLittleEndianUInt32(at: 0),
                kindRawPayload: options.preservedPayload(Data(payload.prefix(kindByteCount))),
                timestamp: HwpTrackChangeTimestamp(
                    year: try payload.readLittleEndianUInt16(at: 4),
                    month: try payload.readLittleEndianUInt16(at: 6),
                    day: try payload.readLittleEndianUInt16(at: 8),
                    hour: try payload.readLittleEndianUInt16(at: 10),
                    minute: try payload.readLittleEndianUInt16(at: 12)
                ),
                timestampRawPayload: options.preservedPayload(Data(
                    payload.dropFirst(kindByteCount).prefix(timestampByteCount)
                )),
                rawTrailing: options.preservedPayload(Data(payload.dropFirst(knownByteCount)))
            )
        } catch {
            return nil
        }
    }
}

private extension HwpMemoShape {
    static func shapeInfo(from payload: Data, options: HwpLoadOptions) -> HwpMemoShapeInfo? {
        let knownByteCount = MemoryLayout<UInt32>.size
            + MemoryLayout<UInt8>.size * 2
            + MemoryLayout<COLORREF>.size * 3
        guard payload.count >= knownByteCount else {
            return nil
        }

        do {
            return HwpMemoShapeInfo(
                width: try payload.readLittleEndianUInt32(at: 0),
                lineType: try payload.readUInt8(at: 4),
                lineWidth: try payload.readUInt8(at: 5),
                lineColor: HwpColor(try payload.readLittleEndianUInt32(at: 6)),
                fillColor: HwpColor(try payload.readLittleEndianUInt32(at: 10)),
                activeColor: HwpColor(try payload.readLittleEndianUInt32(at: 14)),
                fixedFieldsRawPayload: options.preservedPayload(Data(payload.prefix(knownByteCount))),
                rawTrailing: options.preservedPayload(Data(payload.dropFirst(knownByteCount)))
            )
        } catch {
            return nil
        }
    }
}
