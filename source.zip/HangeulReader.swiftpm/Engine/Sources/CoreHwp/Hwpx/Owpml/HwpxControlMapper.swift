import Foundation

/// run 자식 요소 하나를 WCHAR 스트림 항목으로 분류한 결과.
///
/// **불변식**: `.anchor`만 extended 문자와 ctrl 슬롯을 동시에 만든다 —
/// `HwpTextRunBuilder`의 `extendedOrdinal`이 모든 extended 문자를 세며
/// `ctrlHeaderArray`를 서수로 직접 인덱싱하므로, extended 문자 없는 ctrl도
/// ctrl 없는 extended 문자도 정렬을 무너뜨린다.
enum HwpxRunChildAction {
    /// extended 제어 문자(코드) + 컨트롤 — 둘이 동시에 추가된다.
    case anchor(code: UInt16, fourCC: UInt32, ctrl: HwpCtrlId)
    /// inline 제어 문자 — ctrl 슬롯을 만들지 않는다 (필드 끝 코드 4).
    case inlineOnly(code: UInt16, fourCC: UInt32)
    /// 위치를 차지하지 않는 메타 요소 — 진단만 남기고 건너뛴다.
    case zeroWidth
    /// 미지 요소 — 앵커를 추측하지 않는다 (위치 불확실 → lineseg 폐기).
    case unknown
}

/// `hp:run`/`hp:ctrl` 자식 요소 → HWP5 제어 문자·컨트롤 대응표.
enum HwpxControlMapper {
    static func classify(
        _ node: HwpxXMLNode,
        context: HwpxMappingContext
    ) throws -> HwpxRunChildAction {
        // paragraph vocabulary가 아닌 동명 요소(`<ext:tbl>` 등)를 OWPML 컨트롤로
        // 합성하면 WCHAR/컨트롤 스트림이 어긋난다 — local-name switch 전에
        // namespace로 거른다 (P2). 낯선 요소는 앵커를 추측하지 않는다.
        guard node.namespaceURI.isEmpty || node.namespaceURI == HwpxNamespace.paragraph else {
            return .unknown
        }
        switch node.localName {
        case "secPr":
            return .anchor(
                code: 2,
                fourCC: HwpOtherCtrlId.section.rawValue,
                ctrl: .section(try HwpxSecPrMapper.mapSectionDef(
                    node, tables: context.idTables, options: context.options,
                    maxDepth: context.unknownDepthLimit
                ))
            )
        case "colPr":
            return .anchor(
                code: 2,
                fourCC: HwpOtherCtrlId.column.rawValue,
                ctrl: .column(HwpxSecPrMapper.mapColumn(
                    node, maxDepth: context.unknownDepthLimit
                ))
            )
        case "fieldBegin":
            let fourCC = fieldFourCC(of: node.attribute("type"))
            return .anchor(
                code: 3,
                fourCC: fourCC,
                ctrl: degradedControl(
                    fourCC: fourCC, element: node, maxDepth: context.unknownDepthLimit
                )
            )
        case "fieldEnd":
            return .inlineOnly(code: 4, fourCC: HwpFieldCtrlId.unknown.rawValue)
        case "pageNum":
            // 쪽 번호 위치(표 147/148) — 구역 부속 컨트롤(코드 21) 중 유일한
            // typed 승격. 조판이 `.pageNumberPosition`만 등록하므로 강등 상태로는
            // 쪽 번호가 그려지지 않는다 (#135).
            return HwpxPageNumberMapper.anchor(node, context: context)
        case "header", "footer":
            // 머리말·꼬리말(표 140·141) — 구역 부속 컨트롤(코드 16)의 typed 승격.
            // 조판(`HwpPageChromeBuilder`)이 `.header`/`.footer`만 활성 밴드로
            // 받으므로 강등 상태로는 매 쪽에서 통째로 빠진다 (#167).
            return try HwpxHeaderFooterMapper.anchor(
                node, isFooter: node.localName == "footer", context: context
            )
        case "footNote", "endNote":
            // 각주·미주(표 138) — 구역 부속 컨트롤(코드 17)의 typed 승격.
            // `HwpFootnoteCoordinator`가 `.footnote`/`.endnote`에서만 주석을
            // 모으므로 강등 상태로는 본문이 통째로 사라진다 (#168).
            return try HwpxFootnoteMapper.anchor(
                node, isEndnote: node.localName == "endNote", context: context
            )
        case "autoNum":
            // 자동 번호(표 142) — 각주·미주 본문 첫머리의 번호 라벨이 이
            // 컨트롤의 `autoNumberInfo`에서 나온다. 각주만 승격하면 번호 없는
            // 각주가 되므로 같은 범위다 (#168). 코드 18은 자동 번호 전용이다 —
            // 새 번호(`newNum`)는 표 144의 다른 payload이자 **코드 21**이고
            // #169에서 따로 승격했다.
            return try HwpxFootnoteMapper.autoNumberAnchor(node, context: context)
        case "newNum", "pageHiding", "bookmark", "indexmark":
            // 새 번호 지정(표 144)·쪽 감추기(표 145)는 코드 21, 책갈피·찾아보기
            // 표식은 코드 22 — 구역 부속 컨트롤의 마지막 typed 승격이다 (#169).
            // 강등 상태에서는 조판이 쪽 번호를 되돌리지도(`applyNewNumbers`),
            // 크롬을 감추지도(`pageHideMask`) 못해 HWP 쌍과 다른 쪽이 나온다.
            return try HwpxSectionMarkMapper.anchor(node, context: context)
        case "tbl":
            return .anchor(
                code: 11,
                fourCC: HwpCommonCtrlId.table.rawValue,
                ctrl: .table(try HwpxTableMapper.map(node, context: context))
            )
        case "pic":
            return .anchor(
                code: 11,
                fourCC: HwpCommonCtrlId.picture.rawValue,
                ctrl: .picture(HwpxPictureMapper.map(node, context: context))
            )
        case "ole":
            // OLE 개체(표 117, 속성은 표 118) — 내장 차트가 여기로 온다. 조판이 `.ole`을
            // `.genShapeObject`와 같은 개체 분기로 보내 `chartFrame`을 그리므로
            // 강등 상태로는 차트가 통째로 빠진다 (#134).
            return HwpxOleMapper.anchor(node, context: context)
        default:
            return classifyAnchorObject(node, maxDepth: context.unknownDepthLimit)
        }
    }

    /// 미구현 개체·구역 부속 요소 — 전부 미구현 강등이되 4CC는 실제 값을
    /// 실어 `parseDiagnostics()`가 `notImplementedControl`로 종류까지
    /// 보고한다.
    private static func classifyAnchorObject(
        _ node: HwpxXMLNode, maxDepth: Int
    ) -> HwpxRunChildAction {
        if let fourCC = objectFourCCs[node.localName] {
            return .anchor(
                code: 11,
                fourCC: fourCC,
                ctrl: degradedControl(fourCC: fourCC, element: node, maxDepth: maxDepth)
            )
        }
        if let (code, fourCC) = sectionAttachments[node.localName] {
            return .anchor(
                code: code,
                fourCC: fourCC,
                ctrl: degradedControl(fourCC: fourCC, element: node, maxDepth: maxDepth)
            )
        }
        return .unknown
    }

    /// 미구현 컨트롤 강등 — 요소 이름을 header payload와 unknownChildren에
    /// 함께 실어 진단이 OWPML 이름까지 보존한다 (`.notImplemented`의
    /// unknownChildren은 diagnostics walker가 걷는다).
    static func degradedControl(
        fourCC: UInt32, element: HwpxXMLNode, maxDepth: Int
    ) -> HwpCtrlId {
        .notImplemented(HwpCtrlHeader(
            ctrlId: fourCC,
            rawPayload: Data(element.localName.utf8),
            unknownChildren: [element.syntheticUnknownRecord(maxDepth: maxDepth)]
        ))
    }

    /// 코드 11(개체 앵커)로 자리하는 미구현 요소들의 4CC (tbl·pic·ole은 위에서
    /// typed 매핑으로 승격됐다).
    static let objectFourCCs: [String: UInt32] = [
        // 2016 ooxmlchart 확장 — 한글.app은 <hp:switch>로 <hp:chart>와
        // <hp:ole> 두 표현을 함께 적고 우리는 default(ole)를 골라 typed
        // 승격하지만(#134), fallback 없이 <hp:chart>만 오면 여기 없을 때
        // .unknown으로 떨어져 앵커도 ctrl 슬롯도 없이 사라진다. 쌍둥이와 같은
        // 4CC를 실어 강등 앵커라도 자리를 지키게 한다 (요소 이름은 payload에
        // 남아 진단에서 갈린다). chartIDRef로 Chart/*.xml을 직접 읽는 경로는
        // 실물 픽스처가 없어 미승격이다.
        "chart": HwpCommonCtrlId.ole.rawValue,
        "equation": HwpCommonCtrlId.equation.rawValue,
        "line": HwpCommonCtrlId.line.rawValue,
        "rect": HwpCommonCtrlId.rectangle.rawValue,
        "ellipse": HwpCommonCtrlId.ellipse.rawValue,
        "arc": HwpCommonCtrlId.arc.rawValue,
        "polygon": HwpCommonCtrlId.polygon.rawValue,
        "curve": HwpCommonCtrlId.curve.rawValue,
        "connectLine": HwpCommonCtrlId.line.rawValue,
        "textart": HwpCommonCtrlId.genShapeObject.rawValue,
        "container": HwpCommonCtrlId.container.rawValue,
        "video": HwpCommonCtrlId.genShapeObject.rawValue,
    ]

    /// 개체가 아닌 구역 부속 컨트롤 중 미구현 강등 대상 — (제어 문자 코드, 4CC).
    /// 코드 16의 `header`·`footer`(#167), 코드 17의 `footNote`·`endNote`와 코드
    /// 18의 `autoNum`(#168), 코드 21의 `pageNum`(#135), 코드 21의 `newNum`·
    /// `pageHiding`과 코드 22의 `bookmark`·`indexmark`(#169)는 위에서 typed
    /// 매핑으로 승격됐다.
    ///
    /// **`pageNumCtrl`(홀/짝수 조정, `pgct`)만 남는다** — 바이너리 쪽에 표 146의
    /// typed 모델이 없고 저장소 실물 36종에 사례가 0건이라 payload를 지어내야
    /// 하며, 승격해도 `HwpUnsupportedDetector`가 여전히 "알 수 없음: pageCT"를
    /// 낸다. 실물 표본이 생기면 그때 함께 다룬다.
    static let sectionAttachments: [String: (code: UInt16, fourCC: UInt32)] = [
        "pageNumCtrl": (21, HwpOtherCtrlId.pageCT.rawValue),
    ]

    /// `hp:fieldBegin type` → HWP5 필드 4CC. 미지 유형은 `%unk`.
    static func fieldFourCC(of type: String?) -> UInt32 {
        switch type {
        case "HYPERLINK":
            HwpFieldCtrlId.hyperLink.rawValue
        default:
            HwpFieldCtrlId.unknown.rawValue
        }
    }
}
