import CoreHwp
import CoreText
import Foundation

/// Eager O(1) lookup index over `CoreHwp.HwpFile.docInfo.idMappings`.
public struct HwpIndex: Sendable {
    public let charShapes: [UInt32: CoreHwp.HwpCharShape]
    public let paraShapes: [UInt32: CoreHwp.HwpParaShape]
    public let borderFills: [UInt32: CoreHwp.HwpBorderFill]
    public let tabDefs: [UInt32: CoreHwp.HwpTabDef]
    public let styles: [UInt32: CoreHwp.HwpStyle]
    public let bullets: [UInt32: CoreHwp.HwpBullet]
    public let numberings: [UInt32: CoreHwp.HwpNumbering]
    public let binData: [UInt32: CoreHwp.HwpBinData]

    // HWP has one face-name list per script slot (Korean/English/Chinese/Japanese/Etc/Symbol/User).
    public let faceNamesKorean: [UInt32: CoreHwp.HwpFaceName]
    public let faceNamesEnglish: [UInt32: CoreHwp.HwpFaceName]
    public let faceNamesChinese: [UInt32: CoreHwp.HwpFaceName]
    public let faceNamesJapanese: [UInt32: CoreHwp.HwpFaceName]
    public let faceNamesEtc: [UInt32: CoreHwp.HwpFaceName]
    public let faceNamesSymbol: [UInt32: CoreHwp.HwpFaceName]
    public let faceNamesUser: [UInt32: CoreHwp.HwpFaceName]

    init(
        charShapes: [UInt32: CoreHwp.HwpCharShape],
        paraShapes: [UInt32: CoreHwp.HwpParaShape],
        borderFills: [UInt32: CoreHwp.HwpBorderFill],
        tabDefs: [UInt32: CoreHwp.HwpTabDef],
        styles: [UInt32: CoreHwp.HwpStyle],
        bullets: [UInt32: CoreHwp.HwpBullet],
        numberings: [UInt32: CoreHwp.HwpNumbering],
        binData: [UInt32: CoreHwp.HwpBinData],
        faceNamesKorean: [UInt32: CoreHwp.HwpFaceName],
        faceNamesEnglish: [UInt32: CoreHwp.HwpFaceName],
        faceNamesChinese: [UInt32: CoreHwp.HwpFaceName],
        faceNamesJapanese: [UInt32: CoreHwp.HwpFaceName],
        faceNamesEtc: [UInt32: CoreHwp.HwpFaceName],
        faceNamesSymbol: [UInt32: CoreHwp.HwpFaceName],
        faceNamesUser: [UInt32: CoreHwp.HwpFaceName],
        isCompatibilityDocument: Bool = false,
        compatibleDocumentTarget: CoreHwp.HwpCompatibleDocumentTarget? = nil
    ) {
        self.isCompatibilityDocument = isCompatibilityDocument
        self.compatibleDocumentTarget = compatibleDocumentTarget
        self.charShapes = charShapes
        self.paraShapes = paraShapes
        self.borderFills = borderFills
        self.tabDefs = tabDefs
        self.styles = styles
        self.bullets = bullets
        self.numberings = numberings
        self.binData = binData
        self.faceNamesKorean = faceNamesKorean
        self.faceNamesEnglish = faceNamesEnglish
        self.faceNamesChinese = faceNamesChinese
        self.faceNamesJapanese = faceNamesJapanese
        self.faceNamesEtc = faceNamesEtc
        self.faceNamesSymbol = faceNamesSymbol
        self.faceNamesUser = faceNamesUser
    }

    /// MS 워드·한글 2007 등 호환 문서 (표 20 대상 프로그램 ≠ 한글) 여부.
    ///
    /// #249 전에는 빈칸 폭의 게이트였다 (호환 문서 전체의 보통 빈칸을 글꼴 고유 폭으로
    /// 조판했다). 한글 12.30 실측으로 그 규칙은 틀렸다 — 한글 2007 호환 문서는 한글 문서와
    /// 같은 고정 폭이고, MS 워드 호환 문서도 앞뒤가 모두 라틴 부류 글자인 빈칸만 글꼴 폭이다.
    /// 조판은 이제 갈래를 특정하는 `compatibleDocumentTarget`으로 가르고 이 값을 읽지 않는다.
    public let isCompatibilityDocument: Bool

    /// 호환 문서의 대상 프로그램 (표 55) — record가 없거나 raw 값이 표에 없으면 nil이고
    /// 소비자는 한글 문서로 다룬다. 조판은 이 값을 모든 run에
    /// `HwpAttributedStringKey.compatibleDocumentTarget`으로 실어 렌더러가 MS 워드
    /// 호환 문서(`msWord`)와 한글 2007 호환 문서(`hwp200X`)의 장식선 기하를 가른다
    /// (#187·#210, `HwpDecorationLineGeometry`). 빈칸 폭도 이 값으로 MS 워드 호환 문서를
    /// 가른다 (#249, `HwpSpaceWidthMetrics`). `isCompatibilityDocument`와 달리 갈래를
    /// 특정한다 — 훈민정음(`hunmin`)은 장식선·빈칸에서 한글 문서와 같이 다룬다.
    public let compatibleDocumentTarget: CoreHwp.HwpCompatibleDocumentTarget?

    public init(from file: CoreHwp.HwpFile) {
        let idMappings = file.docInfo.idMappings
        isCompatibilityDocument =
            (file.docInfo.compatibleDocument?.targetDocument ?? 0) != 0
        compatibleDocumentTarget = file.docInfo.compatibleDocument?.target
        charShapes = Self.makeIndex(idMappings.charShapeArray)
        paraShapes = Self.makeIndex(idMappings.paraShapeArray)
        borderFills = Self.makeIndex(idMappings.borderFillArray)
        tabDefs = Self.makeIndex(idMappings.tabDefArray)
        styles = Self.makeIndex(idMappings.styleArray)
        bullets = Self.makeIndex(idMappings.bulletArray)
        numberings = Self.makeIndex(idMappings.numberingArray)
        binData = Self.makeIndex(idMappings.binDataArray)
        faceNamesKorean = Self.makeIndex(idMappings.faceNameKoreanArray)
        faceNamesEnglish = Self.makeIndex(idMappings.faceNameEnglishArray)
        faceNamesChinese = Self.makeIndex(idMappings.faceNameChineseArray)
        faceNamesJapanese = Self.makeIndex(idMappings.faceNameJapaneseArray)
        faceNamesEtc = Self.makeIndex(idMappings.faceNameEtcArray)
        faceNamesSymbol = Self.makeIndex(idMappings.faceNameSymbolArray)
        faceNamesUser = Self.makeIndex(idMappings.faceNameUserArray)
    }

    public func charShape(id: UInt32) -> CoreHwp.HwpCharShape? {
        charShapes[id]
    }

    public func paraShape(id: UInt32) -> CoreHwp.HwpParaShape? {
        paraShapes[id]
    }

    public func borderFill(id: UInt32) -> CoreHwp.HwpBorderFill? {
        borderFills[id]
    }

    /// 표 36 탭 정의 → CT 탭 스톱. 위치는 표 43 여백 계열과 같은 1/2 단위
    /// (legacy 목차 실측: 85040 → 425.2pt = 콘텐츠 오른쪽 끝).
    public func textTabs(for paraShape: CoreHwp.HwpParaShape) -> [CTTextTab] {
        guard let tabDef = tabDef(id: UInt32(paraShape.tabDefId)),
              !tabDef.tabInfoArray.isEmpty
        else { return [] }
        return tabDef.tabInfoArray.map { info in
            let alignment: CTTextAlignment = switch info.type {
            case 1: .right
            case 2: .center
            default: .left
            }
            return CTTextTabCreate(
                alignment,
                Double(HwpUnits.points(fromHwpUnitU: info.location) / 2),
                nil
            )
        }
    }

    public func tabDef(id: UInt32) -> CoreHwp.HwpTabDef? {
        tabDefs[id]
    }

    public func style(id: UInt32) -> CoreHwp.HwpStyle? {
        styles[id]
    }

    public func bullet(id: UInt32) -> CoreHwp.HwpBullet? {
        bullets[id]
    }

    public func numbering(id: UInt32) -> CoreHwp.HwpNumbering? {
        numberings[id]
    }

    public func binDataEntry(id: UInt32) -> CoreHwp.HwpBinData? {
        binData[id]
    }

    public func faceNameKorean(id: UInt32) -> CoreHwp.HwpFaceName? {
        faceNamesKorean[id]
    }

    public func faceNameEnglish(id: UInt32) -> CoreHwp.HwpFaceName? {
        faceNamesEnglish[id]
    }

    public func faceNameChinese(id: UInt32) -> CoreHwp.HwpFaceName? {
        faceNamesChinese[id]
    }

    public func faceNameJapanese(id: UInt32) -> CoreHwp.HwpFaceName? {
        faceNamesJapanese[id]
    }

    public func faceNameEtc(id: UInt32) -> CoreHwp.HwpFaceName? {
        faceNamesEtc[id]
    }

    public func faceNameSymbol(id: UInt32) -> CoreHwp.HwpFaceName? {
        faceNamesSymbol[id]
    }

    public func faceNameUser(id: UInt32) -> CoreHwp.HwpFaceName? {
        faceNamesUser[id]
    }

    public func faceName(for faceId: UInt32, script: HwpScript) -> CoreHwp.HwpFaceName? {
        switch script {
        case .korean:
            faceNamesKorean[faceId]
        case .english:
            faceNamesEnglish[faceId]
        case .chinese:
            faceNamesChinese[faceId]
        case .japanese:
            faceNamesJapanese[faceId]
        case .etc:
            faceNamesEtc[faceId]
        case .symbol:
            faceNamesSymbol[faceId]
        case .user:
            faceNamesUser[faceId]
        }
    }
}

private extension HwpIndex {
    static func makeIndex<T>(_ array: [T]) -> [UInt32: T] {
        Dictionary(uniqueKeysWithValues: array.enumerated().map { (UInt32($0.offset), $0.element) })
    }
}
