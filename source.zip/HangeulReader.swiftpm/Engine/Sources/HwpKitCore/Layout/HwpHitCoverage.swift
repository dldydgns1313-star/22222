import CoreGraphics
import CoreText
import Foundation

// MARK: - 자격 영역과 칠 커버리지

/// 히트가 "어디까지 이 블록의 것인가"를 정하는 두 축이다. **정밀도가 다르다**
/// (R54): 자격 영역 (`hitEligibleFrame`/`paintedRects`) 은 실제 칠 영역의
/// **상위집합**이어야 하고 — 좁으면 그 위의 탭이 `containerHit`에 닿기도 전에
/// 기각돼 뒤 로직이 통째로 무용지물이 된다 — claim (컨테이너는 `paintsContent`,
/// 텍스트 블록은 `textPaints`) 은 **정밀 커버리지**여야 한다 (거친 rect로 claim하면
/// 투명한 자리까지 가져가 아래 블록의 보이는 링크를 막는다).
extension HwpHitTester {
    /// frame 밖 가시 영역까지 포함한 히트 자격 프레임 — 이 안이면 링크와 칠(claim)을
    /// 확인하고 밖이면 종전처럼 기각한다. 페인트가 클립 없이 그리는 영역과 같아야
    /// "방출 ≡ 히트"가 성립한다 (AGENTS.md "하이퍼링크 방출" 짝 규약).
    ///
    /// - payload 없이 텍스트로 그려지는 블록 (`HwpBlockContentWalker.plainText` —
    ///   `.text`와 분할된 표/글상자/각주 조각): slight-overflow 한 줄 문단이 frame 폭의
    ///   허용 초과분(`slightOverflowWidthRatio`)만큼 좌우로 넘어 그려지고, 글자 위치
    ///   (`hwp.glyphBaselineOffset`)가 큰 글리프는 **세로로도** 넘어 그려진다.
    ///   그래서 자격 영역은 `paintedRects`의 텍스트 항목과 같은 `textBounds`를 쓴다
    ///   (R56: 자격과 claim 게이트가 같은 상위집합을 공유해야 한다) — 가로만 넓히면
    ///   그 글리프 위의 탭이 rect 판정에 닿기도 전에 블록 단계에서 기각된다.
    ///   **문단 높이 자체는 넓히지 않는다** — 줄 상자는 한글과 같아야 한다.
    ///   종류가 아니라 **방출 술어**로 가른다 (#200 리뷰): `.text`에만 주면 같은 문자열을
    ///   같은 `plainCommands`로 그리는 조각 블록이 프레임에서 멈춰 옮겨진 링크 글리프가
    ///   스팬 기하 확인 전에 기각된다.
    /// - `.text`인데 그릴 문자열이 없으면 가로 여유만 (종전 동작).
    /// - `.footnote`: 각주 안 개체가 블록 폭을 넘어 그려질 수 있다 — 한글도
    ///   자르지 않는다 (헌법주석 883쪽 각주 29의 표는 오른쪽 본문 경계를
    ///   ~12.6pt 넘는다). R39 #3.
    /// - 그 외: frame 그대로 (확장 없음 = 종전 동작).
    func hitEligibleFrame(for block: AnyHwpBlock) -> CGRect {
        if let attributed = HwpBlockContentWalker.plainText(of: block) {
            return Self.textBounds(block.frame, of: attributed)
        }
        switch block.kind {
        case .text:
            let extra = block.frame.width * (HwpRenderTuning.Text.slightOverflowWidthRatio - 1)
            return block.frame.insetBy(dx: -extra, dy: 0)
        default:
            // 컨테이너(각주·표·글상자)는 자손이 프레임을 넘어 그려진다 (R62)
            return paintedRects(for: block).reduce(block.frame) { $0.union($1) }
        }
    }

    /// 블록 frame ∪ **페인트가 실제로 닿는 모든 rect** — 자격 영역 전용.
    ///
    /// 최상위 개체 rect만 모으면 자손 (표 셀·문단, 글상자 안 문단) 이 자기
    /// 컨테이너를 넘어 그려질 때 그 띠가 빠져 보이는 링크가 안 눌린다 (R41 #2).
    /// walker가 페인트와 같은 재귀로 방문하므로 방문 rect를 그대로 합집합한다.
    ///
    /// 자격은 실제 칠 영역의 **상위집합**이어야 한다 — 좁으면 그 위의 탭이
    /// `containerHit`에 닿기도 전에 기각된다 (R53). 반대로 claim을 이 rect로 하면
    /// 투명한 자리까지 가져가 아래 블록의 보이는 링크를 막는다 (R54); claim은
    /// `paintsContent`가 정밀 커버리지로 판정한다.
    ///
    /// **컨테이너 종류를 가리지 않는다** (R62): 표·글상자 블록도 넘친 개체 위에
    /// 링크를 방출하므로 각주와 같은 자격을 받아야 방출된 링크가 눌린다.
    func paintedRects(for block: AnyHwpBlock) -> [CGRect] {
        Self.paintedRects(for: block, includingText: true)
    }

    /// 블록 frame ∪ 자손 **개체**가 칠하는 rect — 문단 텍스트는 세지 않는다.
    ///
    /// 레이아웃의 "이 블록이 그리는 하한"이다 (#165 리뷰): 표·글상자의 오버레이·쪽
    /// 기준 자식은 컨테이너를 키우지 않고 그 아래로 그려지므로 (`HwpFootnoteObjectLayoutTests
    /// .testOverlayWrapModesDoNotGrowFootnoteBlockButStayRendered`) 프레임만 보면 각주
    /// 스택이 그 개체 위에 놓인다. 최상위 도형·그림 블록의 **자기** 칠(회전 경로·miter
    /// 팁·테두리 절반)도 같은 이유로 든다 (#165 리뷰). 텍스트를 빼는 이유는 자격 영역의
    /// `textBounds`가 폰트 메트릭 여유를 더한 **상위집합**이라 모든 블록을 몇 pt씩 부풀리기
    /// 때문 — 텍스트는 블록 프레임이 담는다. 겹침 가드(`FixtureFootnoteOverlapTests`)도
    /// 같은 자를 쓴다.
    static func paintedObjectBounds(of block: AnyHwpBlock) -> CGRect {
        paintedRects(for: block, includingText: false).reduce(block.frame) { $0.union($1) }
    }

    /// 페인트가 닿는 rect 모음 — `includingText`가 false면 문단 텍스트 (표 셀·각주·
    /// 글상자 안 문단)를 빼고 셀·그림·도형·글상자·중첩 표만 모은다.
    private static func paintedRects(for block: AnyHwpBlock, includingText: Bool) -> [CGRect] {
        var rects: [CGRect] = []
        let origin = block.frame.origin
        func addText(_ attributed: NSAttributedString, _ rect: CGRect, _: UInt32?) {
            guard includingText else { return }
            rects.append(textBounds(rect, of: attributed))
        }
        // 셀 테두리는 모서리에 중심을 둬 셀·표 프레임 밖으로 폭의 절반이 나간다 (#191) —
        // 히트 자격은 그만큼 넓어야 바깥 절반 위의 탭이 `paints`까지 닿는다 (R54 `자격 ⊇
        // 칠`). 배치 하한(`paintedObjectBounds`, 텍스트 제외 갈래)은 종전대로 셀 rect다 —
        // 한글이 표 아래 각주 자리를 테두리 바깥 절반까지 재는지는 실측하지 않았다.

        func addCell(_ cell: HwpTableCellFrame, _ rect: CGRect) {
            rects.append(
                includingText
                    ? cell.borders.paintedBounds(around: rect, context: cell.borderContext) : rect
            )
        }
        // 중첩 표는 **자기 frame**도 자격이다 (R64) — 셀만 모으면 표 rect와 첫 셀
        // 사이의 여백 띠가 빠지는데, 방출은 감싼 링크를 표 rect 전체로 낸다.

        func addNestedTable(_: HwpNestedTableFrame, _ rect: CGRect) {
            rects.append(rect)
        }
        // 테두리 stroke는 rect 밖으로 폭의 절반이 나간다 (R61/R62) — 자격이 그만큼
        // 넓어야 보이는 선 위의 탭이 `containerHit`에 닿는다

        func addImage(_ image: HwpCellImage, _ rect: CGRect) {
            rects.append(strokeBounds(rect, borderWidth: image.borderWidth))
        }
        // 도형은 경로가 rect를 넘을 수 있어 `paintedRect` 하나가 칠 영역을 소유한다
        // (R63) — walker는 페이지 좌표 rect를 주므로 그 차이만큼 옮겨 받는다.

        func addShape(_ shape: HwpCellShape, _ rect: CGRect) {
            rects.append(shape.paintedRect.offsetBy(
                dx: rect.minX - shape.rect.minX, dy: rect.minY - shape.rect.minY
            ))
        }
        func addTextboxChildren(_ textbox: HwpTextboxFrame, offset: CGPoint) {
            HwpBlockContentWalker.walkParagraphs(
                textbox.paragraphs, offset: offset, visit: addText
            )
            // 글상자 안 그림·도형도 `textboxCommands`가 클립 없이 그린다 — 글상자
            // rect에서 멈추면 넘친 자식 위의 탭이 기각된다 (R46 #1).
            for child in textbox.images.map(\.paintedRect)
                + textbox.shapes.map(\.paintedRect)
            {
                rects.append(child.offsetBy(dx: offset.x, dy: offset.y))
            }
        }
        func addTextbox(_ textbox: HwpCellTextbox, _ rect: CGRect) {
            rects.append(strokeBounds(
                rect, borderWidth: textbox.textbox.effectiveBorderWidth
            ))
            addTextboxChildren(textbox.textbox, offset: rect.origin)
        }
        switch block.payload {
        case let .footnote(footnote):
            HwpBlockContentWalker.walkFootnote(
                footnote,
                origin: origin,
                onParagraphText: addText,
                onCellStart: addCell,
                onCellImage: addImage,
                onCellShape: addShape,
                onCellTextbox: addTextbox,
                onNestedTable: addNestedTable
            )
        case let .table(table):
            HwpBlockContentWalker.walkTable(
                table,
                origin: origin,
                onCellStart: addCell,
                onParagraphText: addText,
                onCellImage: addImage,
                onCellShape: addShape,
                onCellTextbox: addTextbox,
                onNestedTable: addNestedTable
            )
        case let .textbox(textbox):
            // 최상위 글상자의 **자기** 테두리도 든다 (#165 리뷰): `textboxCommands`가 프레임 경로
            // 중앙에 긋으므로 (`effectiveBorderWidth`) 절반이 밖이다 — 셀 글상자와 같은 규칙.
            rects.append(strokeBounds(block.frame, borderWidth: textbox.effectiveBorderWidth))
            addTextboxChildren(textbox, offset: origin)
        case let .shape(geometry):
            // 최상위 도형 블록도 셀 도형과 같다 (#165 리뷰): `shapeCommands`가 경로를 프레임
            // 원점으로 옮겨 클립 없이 긋으므로 회전 경로·miter 팁이 프레임을 넘는다.
            rects.append(geometry.paintedRect(in: block.frame))
        case let .image(image):
            // 최상위 그림 블록의 테두리도 프레임 경로 중앙에 그어져 (`imageCommands`) 폭의
            // 절반이 밖이다 (R61과 같은 규칙).
            rects.append(strokeBounds(block.frame, borderWidth: image.borderWidth))
        default:
            break
        }
        return rects
    }

    /// 각주가 이 지점에 **실제로 칠했는가** — 자격 영역(bounding box)의 투명한
    /// 틈과 구분한다 (R54). 커버리지의 소유자는 둘뿐이다: 층은
    /// `ContentLayer.paints`, 텍스트는 그려진 줄 상자 + 옮겨진 밴드
    /// (`HwpDrawnTextLayout.textLineRegions` — 줄 상자는 선택 하이라이트와 같은 정의).
    func paintsContent(
        _ footnote: HwpFootnoteBlock, origin: CGPoint, at point: CGPoint
    ) -> Bool {
        var painted = false
        func note(_ hit: @autoclosure () -> Bool) {
            guard !painted else { return }
            painted = hit()
        }
        func paintsText(_ attributed: NSAttributedString, in rect: CGRect) -> Bool {
            textPaints(attributed, in: rect, at: point)
        }
        HwpBlockContentWalker.walkFootnote(
            footnote,
            origin: origin,
            onParagraphText: { attributed, rect, _ in note(paintsText(attributed, in: rect)) },
            onCellStart: { cell, rect in
                // 채움 ∪ 칸막이 — 안 채운 셀의 **칸 안**만 아래 블록 몫이다 (R55)
                note(cell.paints(Self.payloadPoint(point, page: rect, payload: cell.cellFrame)))
            },
            onCellImage: { image, rect in
                note(HwpBlockContentWalker.ContentLayer.image(image)
                    .paints(Self.payloadPoint(point, page: rect, payload: image.rect)))
            },
            onCellShape: { shape, rect in
                note(HwpBlockContentWalker.ContentLayer.shape(shape)
                    .paints(Self.payloadPoint(point, page: rect, payload: shape.rect)))
            },
            onCellTextbox: { textbox, rect in
                // 글상자는 `textboxCommands`가 늘 칠한다 (fillColor 없어도 .hwpWhite)
                note(rect.contains(point))
                HwpBlockContentWalker.walkParagraphs(
                    textbox.textbox.paragraphs, offset: rect.origin
                ) { attributed, inner, _ in note(paintsText(attributed, in: inner)) }
                // 글상자를 넘어 그려지는 자식 (R46 #1) 도 같은 규칙으로 본다
                let local = CGPoint(x: point.x - rect.minX, y: point.y - rect.minY)
                for image in textbox.textbox.images {
                    note(HwpBlockContentWalker.ContentLayer.image(image).paints(local))
                }
                for shape in textbox.textbox.shapes {
                    note(HwpBlockContentWalker.ContentLayer.shape(shape).paints(local))
                }
            }
        )
        return painted
    }

    /// 문단들이 이 지점에 글자를 칠했는지 — 그려진 줄 상자 기준.
    func paragraphsPaint(
        _ paragraphs: [HwpLaidOutParagraph], at point: CGPoint
    ) -> Bool {
        paragraphs.contains { textPaints($0.attributedString, in: $0.rect, at: point) }
    }

    /// 링크 없는 텍스트 블록이 이 지점에 글자를 그렸을 **가능성**이 있는가 — framesetting 없이
    /// 판정하는 값싼 게이트다 (R55). 텍스트 블록의 자격 영역은 곧 `textBounds`라 `textPaints`의
    /// rect 게이트가 이 경로에서는 공허하고, 그대로 두면 탭마다 자격 안 프레임 밖의 **링크 없는
    /// 모든 이웃 문단**을 framesetting한다 (#200 리뷰 2차 검증 실측: 헌법주석 5쪽 격자 탭
    /// 17,750건 p90 0.21 → 1.41ms, 총 7.4 → 13.9s; 800자 문단 framesetting 13~15ms).
    /// 잉크가 프레임 밖에 놓이는 길을 축마다 속성만으로 상한한다:
    /// - **위·아래**: 첫 줄 baseline은 프레임 상단 + 0.85 × 줄 상자 높이(`baselineAnchor`,
    ///   줄 상자 높이 = 그 줄의 기본 글자 크기)이고 잉크는 그 위로 글꼴 ascent까지 오르므로,
    ///   상대 크기가 큰 run(글꼴 = 기본 × 상대)이나 ascent가 0.85em을 넘는 글꼴은 프레임
    ///   위로 `ascent − 0.85 × 기본 크기`만큼 새고(Helvetica 17/10: 4.0pt), 마지막 줄은 아래로
    ///   `descent − 0.15 × 기본 크기`만큼 샌다(줄 간격 100%). 여기에 글자 위치가 위·아래로 옮긴
    ///   몫(`glyphOffsetReach`)을 더한다. Helvetica 10/10은 위 0·아래 0.8pt라 각주 참조 번호
    ///   (+2.1pt)만 있는 본문은 위 2.1pt 띠에서만 조판한다 — 자격 띠(줄 높이 + 오프셋)를 그대로
    ///   쓰면 헌법주석처럼 거의 모든 문단이 첨자를 품는 문서에서 문단 사이 탭마다 이웃 둘을
    ///   framesetting한다. 캐시 높이가 대체 폰트 CT 줄보다 짧아 **줄 상자**가 새는 몫은 잉크가
    ///   아니라 종전처럼 claim하지 않는다.
    /// - **옆**: slight-overflow **한 줄**만 가로로 넘치므로 `slightOverflowLineMetrics`(CTLine
    ///   하나 ~2ms, 줄 나눔 없음)가 여러 줄 문단을 거른다. 옮겨진 run이 있으면 그 잉크의 기울임
    ///   오버행이 진행 폭 밖으로 나가므로(`textBounds`가 자격을 넓힌 그 몫) 그 여유 안은 통과시킨다.
    static func mayPaintOutsideFrame(
        _ attributed: NSAttributedString, frame: CGRect, at point: CGPoint
    ) -> Bool {
        let reach = HwpDrawnTextLayout.glyphOffsetReach(in: attributed)
        if point.y < frame.minY || point.y >= frame.maxY {
            let ink = verticalInkReach(of: attributed)
            return point.y < frame.minY
                ? point.y >= frame.minY - (ink.above + reach.above)
                : point.y < frame.maxY + (ink.below + reach.below)
        }
        if reach.magnitude > 0 {
            let overhang = maxLineHeight(of: attributed)
            if point.x >= frame.minX - overhang, point.x < frame.maxX + overhang {
                return true
            }
        }
        return HwpDrawnTextLayout.slightOverflowLineMetrics(
            attributedString: attributed, lineWidth: frame.width
        ) != nil
    }

    /// 글자 위치 없이도 잉크가 프레임 위·아래로 샐 수 있는 상한 (pt, 0 이상) — 조판 없이
    /// 글꼴 지표와 기본 글자 크기(`hwp.baseFontSize`, 없으면 글꼴 크기)만 본다. 줄 상자 높이는
    /// 문단에서 가장 작은 기본 크기 이상이므로 그 값을 앵커 몫에 써야 상한이 유지된다.
    static func verticalInkReach(
        of attributed: NSAttributedString
    ) -> (above: CGFloat, below: CGFloat) {
        if let reach = msWordVerticalInkReach(of: attributed) {
            return reach
        }
        var maxAscent: CGFloat = 0
        var maxDescent: CGFloat = 0
        var minFontSize = CGFloat.infinity
        attributed.enumerateAttribute(
            .font, in: NSRange(location: 0, length: attributed.length),
            options: .longestEffectiveRangeNotRequired
        ) { value, _, _ in
            guard let value else { return }
            let ref = value as CFTypeRef
            guard CFGetTypeID(ref) == CTFontGetTypeID() else { return }
            let font = unsafeBitCast(ref, to: CTFont.self)
            maxAscent = max(maxAscent, CTFontGetAscent(font))
            maxDescent = max(maxDescent, CTFontGetDescent(font))
            minFontSize = min(minFontSize, CTFontGetSize(font))
        }
        var minDeclared = CGFloat.infinity
        attributed.enumerateAttribute(
            HwpAttributedStringKey.baseFontSize,
            in: NSRange(location: 0, length: attributed.length),
            options: .longestEffectiveRangeNotRequired
        ) { value, _, _ in
            guard let size = (value as? NSNumber)?.doubleValue, size > 0 else { return }
            minDeclared = min(minDeclared, CGFloat(size))
        }
        let box = minDeclared.isFinite ? minDeclared : (minFontSize.isFinite ? minFontSize : 0)
        let anchor = HwpRenderTuning.Text.baselineAnchorRatio
        return (
            above: max(0, maxAscent - box * anchor),
            below: max(0, maxDescent - box * (1 - anchor))
        )
    }

    /// MS 워드 호환 문서(#194)의 `verticalInkReach` — 줄 상자가 글꼴 줄 상자
    /// (`HwpMsWordLineBox`)라 앵커 몫도 글꼴마다 다르다. 줄 상자는 높이와 베이스라인을
    /// **서로 다른 run**에서 고르므로(축별 최댓값) run 자신의 상자로 재면 안 된다:
    /// - 위: 줄의 베이스라인은 어느 run 상자의 베이스라인보다도 크거나 같으므로 run마다
    ///   (ascent − 자기 상자 베이스라인)의 최댓값이 상한이다.
    /// - 아래: 줄 상자의 베이스라인 아래 몫은 (가장 큰 높이 − 가장 큰 베이스라인)이고, 이는
    ///   베이스라인이 가장 큰 run의 아래 몫 이상이라 **후보 상자 아래 몫의 최솟값** 이상이다
    ///   — 그래서 (가장 큰 descent − 최솟값)이 상한이다. run 자신의 아래 몫을 쓰면 Papyrus
    ///   10pt(상자 15.43/9.40, descent 6.03) + Menlo 10pt(15.13/11.03) 줄에서 줄 상자가
    ///   15.43/11.03이 되어 `j`가 상자 아래로 1.63pt 새는데 0으로 잰다 (PR 리뷰 재현: 그
    ///   글자를 누르면 게이트가 거부해 뒤 블록의 링크가 열렸다). 문단 끝 글자 상자
    ///   (`hwp.msWordParagraphEndBox`)도 후보다 — 문단마다 다르므로(결합 문자열·공개
    ///   `drawText`의 여러 문단) **모든** 속성 범위를 훑는다. 첫 문단 것만 보면 Papyrus 두
    ///   문단 가운데 마지막 문단의 끝 글꼴만 Menlo일 때 그 줄이 같은 1.63pt를 새는데 0으로
    ///   잰다 (두 번째 PR 리뷰 재현).
    /// 한글 문서(첫 run에 호환 문서 키 없음)면 nil.
    static func msWordVerticalInkReach(
        of attributed: NSAttributedString
    ) -> (above: CGFloat, below: CGFloat)? {
        let whole = NSRange(location: 0, length: attributed.length)
        guard attributed.length > 0,
              HwpDrawnTextLayout.isMsWordCompatible(attributed.attributes(at: 0, effectiveRange: nil))
        else { return nil }
        var above: CGFloat = 0
        var maxDescent: CGFloat = 0
        var minBelow = CGFloat.infinity
        attributed.enumerateAttribute(
            HwpAttributedStringKey.msWordParagraphEndBox, in: whole,
            options: .longestEffectiveRangeNotRequired
        ) { value, _, _ in
            guard let end = value as? [NSNumber], end.count == 2 else { return }
            minBelow = min(minBelow, CGFloat(end[0].doubleValue - end[1].doubleValue))
        }
        // 글자 상자보다 낮지만 그 베이스라인보다 높은 글자처럼 취급 개체는 베이스라인만
        // 내리고 상자는 그대로 둔다 (#223 한글 실측: Apple SD 20pt 줄 + 25pt 표 → 3119/2500)
        // — 그 줄의 베이스라인 아래 몫은 어느 후보 상자의 몫보다도 작아져 0까지 줄 수 있다.
        // 개체를 예약한 문단은 descent 전체를 상한으로 둔다 (조판 없이는 개체 높이와 줄의
        // 짝을 모른다).
        attributed.enumerateAttribute(
            HwpAttributedStringKey.inlineObjectHeight, in: whole,
            options: .longestEffectiveRangeNotRequired
        ) { value, _, stop in
            if ((value as? NSNumber)?.doubleValue ?? 0) > 0 {
                minBelow = 0
                stop.pointee = true
            }
        }
        attributed.enumerateAttribute(
            .font, in: whole, options: .longestEffectiveRangeNotRequired
        ) { value, range, _ in
            guard let value else { return }
            let ref = value as CFTypeRef
            guard CFGetTypeID(ref) == CTFontGetTypeID() else { return }
            let font = unsafeBitCast(ref, to: CTFont.self)
            let size = (attributed.attribute(
                HwpAttributedStringKey.baseFontSize, at: range.location, effectiveRange: nil
            ) as? NSNumber).map { CGFloat($0.doubleValue) } ?? CTFontGetSize(font)
            let box = HwpMsWordLineBox.metrics(of: font).scaled(by: max(0, size))
            above = max(above, CTFontGetAscent(font) - box.baseline)
            maxDescent = max(maxDescent, CTFontGetDescent(font))
            minBelow = min(minBelow, box.lineHeight - box.baseline)
        }
        let below = minBelow.isFinite ? maxDescent - minBelow : 0
        return (max(0, above), max(0, below))
    }

    /// 문단이 이 지점에 글자를 칠했는지 — **`textBounds` 밖이면 CT 조판을 하지 않는다**.
    ///
    /// 칠 영역(줄 상자·옮겨진 밴드)이 문단 rect를 넘는 몫은 `textBounds`가 상위집합으로
    /// 준다 — 자격(`hitEligibleFrame`)과 같은 여유라 자격 안이면 게이트도 통과한다 (R56).
    /// 이 게이트가 없으면 탭 한 번이 셀·문단 수만큼 framesetting을 돌린다 — `tableHit`은
    /// 셀 프레임으로 미리 거르지 않으므로 (R44 #2) 큰 표에서 동기 탭 핸들러가 멈춘다
    /// (R55 실측: 600셀 표 탭당 29.16ms).
    func textPaints(
        _ attributed: NSAttributedString, in rect: CGRect, at point: CGPoint
    ) -> Bool {
        guard Self.textBounds(rect, of: attributed).contains(point) else { return false }
        return HwpDrawnTextLayout.textLineRegions(
            attributedString: attributed, origin: rect.origin, lineWidth: rect.width
        ).contains { $0.contains(point) }
    }

    /// 테두리 stroke를 포함한 자격 상위집합 — CG가 경로 중앙에 긋는 폭의 절반이
    /// rect 밖이다 (`HwpCellImage.paintedRect`와 같은 규칙, R61).
    static func strokeBounds(_ rect: CGRect, borderWidth: CGFloat) -> CGRect {
        guard borderWidth > 0 else { return rect }
        return rect.insetBy(dx: -borderWidth / 2, dy: -borderWidth / 2)
    }

    /// 문단 텍스트가 닿을 수 있는 **상위집합** — 자격 영역(`hitEligibleFrame`·
    /// `paintedRects`)과 claim 게이트(`textPaints`)가 이 하나를 공유해야 "자격 ⊇ 칠"이
    /// 구조적으로 성립한다 (R56). 따로 두면 자격이 좁아 게이트의 여유가 도달 불가능해진다.
    ///
    /// 넘치는 축 셋: slight-overflow 한 줄은 rect 폭을 넘고, 캐시 높이가 대체 폰트 CT
    /// 줄보다 짧으면 아래로도 넘으며, 글자 위치가 옮긴 글리프는 그 오프셋만큼 위나 아래로
    /// 넘는다. 둘째는 값싸게 정확히 잴 수 없어 (walker 콜백에 `HwpParagraphFrame`이 없다)
    /// 줄 높이를 여유로 준다 — 상위집합을 넓히는 것은 과잉 claim이 아니다. 실제 claim은
    /// 줄 상자·밴드로 정밀 판정한다 (`HwpDrawnTextLayout.textLineRegions`).
    ///
    /// "줄 상자 ⊂ rect ± 줄 높이"인 한에서 상위집합이다 — 남은 예외는 둘이다: 여러 줄이
    /// 각각 캐시보다 짧아 합이 줄 높이를 넘는 문단과, 글자처럼 취급 개체가 정한 줄 상자가
    /// 앵커 위로 0.15 × 개체 높이만큼 나가는 줄 (그 자리엔 잉크가 없다). 둘 다 이 PR 이전의
    /// 격차다 (#200 리뷰 검증). 옮겨진 run의 잉크 오버행은 가로 여유가 글꼴 줄 높이로 덮는다.
    static func textBounds(_ rect: CGRect, of attributed: NSAttributedString) -> CGRect {
        let horizontal = rect.width * (HwpRenderTuning.Text.slightOverflowWidthRatio - 1)
        // 세로 여유는 **폰트 메트릭**에서 온다 (R65). 폭에 비례시키면 넘침의 크기와
        // 아무 관계가 없어, 좁은 셀(폭 40pt → 2.4pt)에서 보이는 글자가 자격 밖으로
        // 나간다 — 그러면 전경 글자가 claim에 실패해 뒤 층의 감싼 링크가 이기고,
        // 블록 밖으로 그려진 링크는 아예 안 눌린다. 조판 없이 **속성만** 훑어 가장
        // 큰 줄 높이를 쓴다 (R55의 탭 지연 재발 방지 — CT 조판은 이 게이트 뒤다).
        //
        // 여기에 **글자 위치의 최대 |오프셋|을 더한다** (#200 리뷰): `paintedRects`의 밴드는
        // 줄 상자를 오프셋만큼 옮긴 것이라, 줄 상자가 샐 수 있는 몫(줄 높이)에 그 이동분을
        // 더해야 상위집합이다. 줄 높이만 보면 오프셋이 그보다 큰 글리프 — 첨자(0.64배
        // 글꼴·+0.44em, #204)와 글자 위치(±1.0×크기)가 **누적**되는 글자 모양이나, 공개
        // 키로 실린 큰 값 — 위의 탭이 rect 판정에 닿기도 전에 블록 단계에서 기각된다
        // (#200 리뷰 실측, 당시 첨자 상수 0.67배·0.33em 기준: Helvetica 10pt·줄 높이 10에서
        // 오프셋 12부터 `hit`이 nil, 6.7pt 글꼴에 13.3이면 밴드 y 87.2…93.9가 자격
        // 93.3…116.7 밖 — 지금 상수로는 6.4pt 글꼴에 14.4, `HwpLargeGlyphOffsetEligibilityTests`).
        let lineHeight = maxLineHeight(of: attributed)
        let glyphOffset = HwpDrawnTextLayout.maxGlyphOffsetMagnitude(in: attributed)
        // 옮겨진 run이 있으면 **가로도** 글꼴 지표만큼 준다: 밴드는 잉크 경계라 기울임 근사
        // (`matrix.c += 0.22`)·이탤릭 `f`의 오버행이 진행 폭(≤ rect 폭 × 1.06) 밖으로 나가는데,
        // 그 몫은 글꼴 줄 높이 안이다 (#200 리뷰 검증: Times 10pt `fff` 자연 폭 프레임에서
        // 잉크 110.645 vs 자격 110.207 — 방출된 링크 rect가 블록 단계에서 기각됐다). 옮겨진
        // run이 없으면 줄 상자(진행 폭)가 claim이라 종전 여유 그대로다.
        let overhang = glyphOffset > 0 ? lineHeight : 0
        return rect.insetBy(
            dx: -max(horizontal, overhang), dy: -max(horizontal, lineHeight + glyphOffset)
        )
    }

    /// 이 문단이 쓸 수 있는 가장 큰 CT 줄 높이 — 조판 없이 폰트 메트릭만 본다.
    /// 캐시 높이가 대체 폰트보다 짧을 때 아래로 새는 양의 상한이다 (한 줄 기준 —
    /// 여러 줄이 각각 조금씩 짧으면 합이 이보다 클 수 있다).
    ///
    /// 글자 위치 몫과 **따로** 훑는다 (`enumerateAttribute` 두 번): `enumerateAttributes`
    /// 한 번으로 합치면 run마다 사전을 브리징해 2~4배 느리다 (600셀 × 3run 0.95 → 2.07ms,
    /// 본문 50문단 × 200run 3.25 → 11.4ms, #200 리뷰 검증 실측).
    private static func maxLineHeight(of attributed: NSAttributedString) -> CGFloat {
        var maxHeight: CGFloat = 0
        attributed.enumerateAttribute(
            .font, in: NSRange(location: 0, length: attributed.length),
            options: .longestEffectiveRangeNotRequired
        ) { value, _, _ in
            guard let value else { return }
            let ref = value as CFTypeRef
            guard CFGetTypeID(ref) == CTFontGetTypeID() else { return }
            let font = unsafeBitCast(ref, to: CTFont.self)
            maxHeight = max(
                maxHeight,
                CTFontGetAscent(font) + CTFontGetDescent(font) + CTFontGetLeading(font)
            )
        }
        return maxHeight
    }
}
