import CoreGraphics
import CoreHwp
import CoreText
import Foundation

// swiftlint:disable file_length

public actor HwpPaginator {
    private let sections: [CoreHwp.HwpSection]
    private let index: HwpIndex
    private let fontResolver: HwpFontResolver
    /// 글자 모양별 텍스트 속성 캐시 — 문서(파이프라인) 단위 소유. 본문·표 셀·
    /// 글상자·각주·머리말/꼬리말이 전부 이 하나를 공유한다. 전역이면 안 되는
    /// 이유는 `HwpTextAttributeCache` 참조.
    private let attributeCache = HwpTextAttributeCache()
    private let imageStore: HwpImageStore
    private let paintListBuilder: HwpPaintListBuilder
    private let unsupportedDetector = HwpUnsupportedDetector()
    private let tableLayout: HwpTableLayout
    private let textboxLayout: HwpTextboxLayout
    /// 각주/미주 수집·측정·예약 상태 — 카운터·pending·예약 높이·측정 캐시를 소유한다.
    private var footnoteCoordinator: HwpFootnoteCoordinator
    private var nextSectionIndex = 0
    private var nextParagraphIndex = 0
    private var currentPageGeometry: HwpPageGeometry
    private var currentSectionDef: CoreHwp.HwpSectionDef?
    private var currentBlocks: [AnyHwpBlock] = []
    /// 변경 추적(PARA_RANGE_TAG kind 16/17) 문단의 paraId — 페이지가 캐시될
    /// 때마다 그 페이지 조각에 변경 막대를 방출한다 (페이지 걸친 문단의 앞
    /// 조각도 막대를 받게, #7).
    private var trackChangeParagraphIds: Set<UInt32> = []
    private var contentHeightUsed: CGFloat = 0
    private var didFinishPagination = false
    /// 문서 순서로 생성한 문단 번호·개요 번호 (#153). 조판과 무관한 순수 함수의
    /// 결과라 init에서 한 번 만들고 이후 바뀌지 않는다 — 불변 `Sendable` 값이라
    /// actor 밖에서도 동기로 읽는다(라벨 렌더 #154의 조판 문자열 조립·복사·
    /// 접근성은 actor 격리 밖 동기 코드다). 최상위 문단의 라벨은 `measuredParagraph`가
    /// `currentParagraphNumber`로 꺼내 조판 문자열 앞에 전치한다 (#154).
    ///
    /// init의 동기 순회라 조판의 쪽 단위 지연·취소 관찰 밖이므로 순회 쪽이 스스로
    /// 유계다 — 걸음 수(`HwpParagraphNumbering.maximumVisitedNodes` — 문단과 컨트롤)·항목
    /// 수·라벨 길이에 상한이 있고, 감싼 Task가 취소되면 걷다 만다(`isTruncated`).
    public nonisolated let paragraphNumbering: HwpParagraphNumbering

    /// 문서 전역 페이지 상한 — 쪽 나누기 문단·별개 표가 다수면 표당 세그먼트
    /// 상한(maximumTableSegments)만으로는 총 페이지가 무제한이라, 작은 레코드
    /// 스트림이 수십만 페이지로 증폭돼 paint-list 메모리를 고갈시킨다 (#1).
    /// 페이지마다 블록·attributed string·paint list를 상주 보존하므로 한도는
    /// 모바일 프로세스가 실제로 감당 가능한 수준이어야 방어가 성립한다 —
    /// legacy 실측 최대 1,030쪽의 약 10배 여유로 정상 대형 문서는 통과시키고
    /// 병적 증폭은 수십 MB 수준에서 절단한다.
    static let maximumDocumentPages = 10000
    /// 컨테이너 안 컨테이너 재귀 방출 상한. 렌더(appendNestedControlBlocks)와
    /// 진단(walkUnsupported), 탐색 목록 수집(`HwpOutlineCollector`)이 같은 값을
    /// 써야 초과분이 조용히 사라지지 않는다.
    static let maximumContainerDepth = 3
    /// 인스턴스 상한 (기본 = 전역 상한) — 테스트가 cap 도달 경로를 작은
    /// 문서로 재현할 수 있게 재정의를 허용한다.
    var maximumPages = HwpPaginator.maximumDocumentPages
    /// 표 하나가 만들 수 있는 세그먼트 상한 (기본 = 전역 상한) — 위와 같은 이유로
    /// 인스턴스 값이다.
    var maximumTableSegments = HwpTableLayout.maximumTableSegments
    private var isComputingPage = false

    func overrideMaximumPages(_ count: Int) {
        maximumPages = count
    }

    /// 탐색 목록 항목 상한 재정의 (테스트가 절단 경로를 작은 문서로 재현한다).
    func overrideMaximumOutlineItems(_ count: Int) {
        outlineCollector.maximumItems = count
    }

    /// 표 세그먼트 상한 재정의 (테스트가 행 절단 경로를 작은 표로 재현한다).
    func overrideMaximumTableSegments(_ count: Int) {
        maximumTableSegments = count
    }

    private var collectedUnsupported: [HwpUnsupportedElement] = []
    /// 이 문단의 **첫 조각이 실제로 놓인** 쪽 (1-기반, 문단마다 리셋).
    /// 배치 **전**에 잡은 값은 다단에서 낡는다 — `placeMultiColumnParagraph`는
    /// 미루기(`false` 반환)가 없어 마지막 단이 모자라면 스스로 쪽을 넘긴 뒤
    /// 첫 줄을 놓는다 (1단 경로는 미뤄서 재계산되므로 안전하다).
    private var currentParagraphFirstPlacedPage: Int?
    /// 개요·책갈피 탐색 목록 수집기 (#77) — 쪽 귀속이 조판의 함수라 여기 산다.
    private var outlineCollector: HwpOutlineCollector
    /// 세그먼트 상한에 걸려 **일부 행만 방출된** 표: 인스턴스 id → (표, 방출 행 수).
    /// 탐색 목록이 그려지지 않은 행의 앵커를 내지 않게 하는 입력이다.
    /// id로 버킷만 좁히고 표 값으로 확정하는 근거는 `truncatedRowLimit(of:)`.
    private var truncatedTableRowLimits: [UInt32: [(table: CoreHwp.HwpTable, rowLimit: Int)]] = [:]
    /// 이 페이지에 배치할 각주 (문단 + 문서 순서 번호) — 저장은 footnoteCoordinator
    private var pendingFootnotes: HwpFootnoteLayout.PendingNotes {
        get { footnoteCoordinator.pendingFootnotes }
        set { footnoteCoordinator.pendingFootnotes = newValue }
    }

    /// 이 페이지에 표시할 메모 (댓글) 풍선 (한글.app 편집 뷰 오른쪽 패널)
    private var pendingMemoBalloons: [HwpMemoPanelPainter.Balloon] = []
    /// 문서/구역 끝에 배치할 미주 (표 134 bits 8-9) — 저장은 footnoteCoordinator
    private var pendingEndnotes: HwpFootnoteLayout.PendingNotes {
        get { footnoteCoordinator.pendingEndnotes }
        set { footnoteCoordinator.pendingEndnotes = newValue }
    }

    /// 각주 영역이 차지할 높이 (본문 overflow 검사에 반영) — 저장은 footnoteCoordinator
    private var footnoteReservedHeight: CGFloat {
        get { footnoteCoordinator.footnoteReservedHeight }
        set { footnoteCoordinator.footnoteReservedHeight = newValue }
    }

    /// 현재 문단의 현재-페이지 상단 y (문단 기준 앵커의 기준점).
    /// 페이지가 넘어가면 새 페이지 콘텐츠 상단으로 재설정된다.
    private var paragraphAnchorTop: CGFloat = 0
    /// 문단 **진입 시점**의 흐름 위치 (절대 y)와 그때의 페이지·단 — 자리 차지 표를
    /// 문단 글줄 앞 띠에 놓을지 판정하는 기준이다 (#161). 절대 캐시 모드의
    /// `paragraphAnchorTop`은 한글이 준 캐시 y라 이미 띠 **뒤** 자리이므로 기준이
    /// 될 수 없다. 배치 중 페이지·단이 넘어갔으면 진입 값이 다른 밴드의 것이므로
    /// 판정을 포기한다.
    private struct ParagraphEntryFlow {
        let top: CGFloat
        let pageIndex: Int
        let columnFrame: CGRect
        /// 직전에 배치한 문단의 저작 아래 간격 (pt) — 띠에서 뺀다. 절대 캐시 배치는 이
        /// 몫을 커서로 소비하지 않고 캐시 줄 위치에 이미 담아 두며, 절대 캐시 블록 높이
        /// (`absoluteRunBlockHeight`)는 줄 위치·높이·줄 간격만으로 만들어져 이 몫을 담지
        /// 않으므로, 그 여백이 `entry.top`과 캐시 줄 사이 간격에 남는다 (한글 12.30 실측:
        /// 앞 문단 아래 간격 20pt는 표 **앞**에 그대로 들어간다). 이 문단 자신의 위 간격은
        /// 빼지 않는다 — 한글은 자리 차지 표를 품은 문단의 위 간격을 표 앞에도 표와 글줄
        /// 사이에도 쓰지 않는다 (#190 실측, 1단·2단 모두).
        let precedingSpacingBottom: CGFloat
        /// 이 문단이 **실제로** 절대 캐시 경로로 배치됐는지 — `absoluteCacheMode`는
        /// 문서 전체 판정이라 캐시가 없는 문단은 같은 문서에서도 흐름 배치된다
        /// (`placeParagraphText`의 `cacheRuns` 분기). 그런 문단의 간격은 한글이 표에
        /// 내준 띠가 아니라 문단 위 간격(`beforeGap`)이므로 띠로 오인하면 안 된다.
        var placedFromCache = false
        /// 이 문단에서 앞선 띠 표가 소비한 자리 (`contentHeightUsed` 값) — 같은 문단에
        /// 표가 여럿이면 다음 표는 그 아래 남은 띠만 본다. nil이면 아직 아무도 안 썼다.
        var bandUsed: CGFloat?
        /// 이 문단의 앞선 표가 **글줄 자리**(흐름 분할·줄 안 앵커)로 갔는지 — 그 뒤 표를
        /// 띠로 되감으면 뒤 표가 앞 표보다 위에 그려져 문서 순서가 뒤집힌다.
        var bandClosed = false
    }

    private var paragraphEntryFlow: ParagraphEntryFlow?
    /// 직전에 배치한 문단의 저작 아래 간격 (pt) — 다음 문단의 띠 계산이 읽는다 (#161).
    /// 밴드가 열리면 (새 페이지·새 단) 앞 문단은 다른 밴드의 것이므로 0으로 되돌린다.
    private var lastPlacedSpacingBottom: CGFloat = 0
    /// 현재 문단의 좌우 여백 (표 43, 1/2 단위 해석 후 pt) — '문단' 기준
    /// 개체의 폭/원점 산출용 (#2). 문단 처리 시작 시 갱신된다.
    private var currentParagraphMargins: (left: CGFloat, right: CGFloat) = (0, 0)
    /// 페이지 경계 재처리 메모 — placeParagraphText 실패 (페이지 확정) 후
    /// 같은 문단을 다음 페이지에서 다시 처리할 때 build + CT 측정을
    /// 재사용한다. 키가 빌드의 모든 입력 (문단 위치·단 폭·컨트롤 치환
    /// 결과)을 포함하므로 키 일치 시 결과는 정의상 동일하다. 쪽 번호
    /// 자동 치환처럼 페이지 확정으로 치환 텍스트가 달라지는 문단은
    /// replacements 불일치로 자연히 재빌드된다.
    private struct ParagraphMeasureMemo {
        let sectionIndex: Int
        let paragraphIndex: Int
        let widthCenti: Int
        let replacements: [Int: HwpControlMarkerReplacement]
        let attributedString: NSAttributedString
        let paragraphFrame: HwpParagraphFrame
    }

    private var measureMemo: ParagraphMeasureMemo?
    /// 최상위 문단의 글자처럼 취급 표 레이아웃 메모 (#214) — 줄 예약(`inlineTableHeights`)이
    /// 조판 전에 잰 표를 배치(`layoutTable`)가 다시 조판하지 않게 한다. 문단이 바뀌면 비운다.
    var inlineTableFrames = InlineTableFrameMemo()
    /// 문단 단위 `Task.yield()` 배칭 카운터 (#73 조각 3).
    ///
    /// 문단마다 최대 두 번(배치 뒤·측정 진입) 양보하던 것을 `yieldBatchSize`
    /// 문단마다 한 번으로 줄인다 — 20,000 문단이면 최대 40,000회가 2,500회가 된다.
    /// 취소 **관찰**은 이 배칭과 독립이다: `processParagraph`가 문단마다
    /// `Task.checkCancellation()`을 그대로 부른다. 배칭이 늦추는 것은 다른
    /// Task에게 실행을 넘기는 시점뿐이다.
    private var yieldCounter = 0
    /// 양보 주기 (문단 수). 16은 취소 응답 지연(문단 16개 처리 시간)과
    /// 스케줄러 왕복 절감의 절충이다.
    static let yieldBatchSize = 16
    /// 이번 배치가 각주를 **조각 단위로 이미 수집했는지** (#95). 페이지에 걸친
    /// 절대 캐시 문단은 run마다 그 조각의 각주를 그 페이지에 담으므로, 문단 루프의
    /// 문단 단위 수집을 건너뛰어야 이중 수집(번호 중복)이 되지 않는다.
    /// placeParagraphText가 매 호출 초기화하고 절대 캐시 경로만 켠다.
    private var collectedFootnotesDuringPlacement = false
    /// 본문 텍스트 블록의 마지막 줄 **상자 아래** 몫 (`currentBlocks` 인덱스별) — 각주
    /// 이어짐 판정의 본문 하한은 마지막 줄 상자 아래다 (#165 한글 실측). 블록 프레임은
    /// 전진량(줄 간격, 문단 끝이면 아래 간격까지)이라 그 차를 따로 둔다. 절대 캐시 run 블록
    /// (#165)과 흐름 배치 블록(#222 — 쪽 끝 적합이 줄 상자까지라 여분이 본문 하단을 넘을 수
    /// 있다)이 기록한다. 쪽이 확정되면 비운다.
    private var trailingSpacesBelowLineBox: [Int: CGFloat] = [:]
    /// 이번 배치가 **조각의 쪽에 이미 놓은** 글자처럼 취급 컨트롤의 서수 (#164).
    /// 쪽·단에 걸친 문단은 앞 조각의 줄 앵커가 있는 개체를 그 조각이 확정되기 전에
    /// 놓으므로, 배치 뒤 문단 단위 방출(`appendControlBlocks`)이 이 서수를 건너뛰어야
    /// 같은 개체가 두 번 그려지지 않는다. placeParagraphText가 매 호출 비운다.
    ///
    /// 값은 **그 조각의 1-기반 쪽**이다 (PR 리뷰) — 진단(`walkUnsupported`)은 문단이
    /// 끝난 뒤 `cachedPages.count + 1`(= 마지막 조각의 쪽)로 보고하는데, 앞 조각에 놓은
    /// 개체는 그 값이 실제로 그려진 쪽이 아니다. 서수만 남기면 그 사실이 사라진다.
    private var inlineControlsPlacedPerFragment: [Int: Int] = [:]
    /// 이번 문단에서 글줄 **앞**에 흐름으로 놓은 자리 차지 표의 서수 → 첫 조각의 1-기반 쪽
    /// (#190). 문단 단위 방출(`appendControlBlocks`)이 이 서수를 건너뛰어야 같은 표가 글줄
    /// 뒤에 한 번 더 놓이지 않는다. 열쇠는 `tablesPlacedBeforeTextParagraph`가 가리키는
    /// 문단의 것이다 — 글줄이 쪽에 안 들어가 문단을 다음 쪽에서 다시 처리해도 표는 이미
    /// 놓였으므로 그 문단이 끝날 때까지 남긴다.
    private var tablesPlacedBeforeText: [Int: Int] = [:]
    /// `tablesPlacedBeforeText`가 속한 문단 (구역·문단 서수). 다른 문단에 들어서면 비운다.
    private var tablesPlacedBeforeTextParagraph: HwpParagraphPath?
    /// 글줄 앞 표(#190)보다 **앞선** 쪽 장식 컨트롤(머리말·꼬리말·쪽 번호 위치·감추기)의
    /// 서수 — 표를 놓기 전에 등록해 표가 넘긴 쪽부터 장식이 실린다 (종전 순서: 글줄 뒤 방출이
    /// 서수 순으로 등록하므로 표보다 앞선 장식은 표가 흐르기 전에 등록됐다, PR 리뷰). 문단
    /// 단위 방출(`appendControlBlocks`)이 이 서수의 등록을 되풀이하지 않는다.
    private var chromeRegisteredBeforeText: Set<Int> = []
    /// `registerPageChromePreceding`이 이미 훑은 서수의 끝 — 표마다 0부터 다시 훑으면 표 N개
    /// 문단이 O(N²)다 (PR 리뷰). `chromeRegisteredBeforeText`와 함께 문단마다 비운다.
    private var chromeScannedBefore = 0
    /// 글줄 앞 표의 **첫 조각이 놓이는 순간** 등록할 앞선 쪽 장식 — 표를 놓기 전에 등록하면
    /// 첫 행이 이 쪽에 안 들어가 `advanceColumn`으로 넘길 때 문단이 없는 앞 쪽이 그 장식으로
    /// 확정된다 (PR 리뷰: 쪽 끝 문단의 쪽 번호 컨트롤 + 표가 다음 쪽으로 가는데 앞 쪽에 번호).
    /// `appendTableSegmentBlock`이 소비한다 (`applyPendingPageNumberReset`과 같은 지점).
    private var pendingChromeRegistration: PendingChromeRegistration?

    /// `pendingChromeRegistration`의 내용 — 표 서수와 그 문단의 컨트롤·번호 열쇠.
    private struct PendingChromeRegistration {
        let tableOrdinal: Int
        let controls: [CoreHwp.HwpCtrlId]
        let numbering: HwpNumberingScope
    }

    /// 문단 단위 방출과 진단(`walkUnsupported`)이 건너뛸 **이미 놓인** 컨트롤 서수 → 쪽 —
    /// 조각과 함께 놓은 글자처럼 취급 개체(#164)와 글줄 앞에 놓은 자리 차지 표(#190)의 합.
    private var controlsPlacedBeforeParagraphEnd: [Int: Int] {
        inlineControlsPlacedPerFragment.merging(tablesPlacedBeforeText) { fragment, _ in fragment }
    }

    /// 각주 번호 — 저장은 footnoteCoordinator
    private var footnoteCounter: Int {
        get { footnoteCoordinator.footnoteCounter }
        set { footnoteCoordinator.footnoteCounter = newValue }
    }

    /// 미주 번호 (각주와 별도 카운터, endNoteShape.startingNumber부터)
    /// — 저장은 footnoteCoordinator
    private var endnoteCounter: Int {
        get { footnoteCoordinator.endnoteCounter }
        set { footnoteCoordinator.endnoteCounter = newValue }
    }

    /// 다음에 확정될 페이지의 논리 쪽 번호 (표 141 짝/홀 판정용).
    /// 구역 진입 때 `HwpSectionDef.firstPageNumber(continuing:)`로 재설정된다 — 사용자
    /// 지정 시작 번호가 있으면 그 값, 없으면 구역 시작 종류(홀수·짝수)에 따라 홀짝이
    /// 어긋난 번호만 1 건너뛴다 (#185, 이어서면 그대로). 새 번호 지정(nwno)의 보류 리셋
    /// (`pendingPageNumber`)이 문단 배치 때 다시 덮는다.
    private var nextLogicalPageNumber = 1
    /// 새 번호 지정(nwno, 표 144)의 쪽 번호 리셋은 문단이 실제 배치될 때까지
    /// 보류한다 — 배치 전에 적용하면 넘침으로 확정되는 앞 페이지까지 리셋 번호를
    /// 써 엉뚱한 쪽 번호·패리티 머리말을 갖는다.
    private var pendingPageNumber: Int?
    /// 머리말/꼬리말/쪽 번호 (페이지 크롬) 빌더 — 활성 컨트롤 상태를 소유한다.
    private var pageChrome: HwpPageChromeBuilder
    /// 다단 밴드 상태·로직 — 단 정의/프레임/index/사용량/균형 재배치 입력을
    /// 소유한다. 리셋은 band.open 한 곳 (openColumnBand·cacheCurrentPage 공용).
    /// 아래 계산 프로퍼티들은 기존 호출부를 유지하기 위한 위임이다.
    private var band = HwpColumnBandController()
    /// 현재 단 정의 (`cold` 컨트롤). nil이면 1단. — 저장은 band
    private var currentColumnDef: CoreHwp.HwpColumn? {
        get { band.currentColumnDef }
        set { band.currentColumnDef = newValue }
    }

    /// 현재 단 밴드의 단 프레임 (페이지 좌표). 비어 있으면 contentFrame 1단.
    /// — 저장은 band (쓰기는 band.open만)
    private var columnFrames: [CGRect] {
        band.columnFrames
    }

    /// 현재 채우는 단 index — 저장은 band
    private var columnIndex: Int {
        get { band.columnIndex }
        set { band.columnIndex = newValue }
    }

    /// 현재 밴드에서 실제 사용된 최대 하단 y — 밴드 종료 시 다음 밴드 시작점.
    /// 저장은 band
    private var bandUsedBottom: CGFloat {
        get { band.bandUsedBottom }
        set { band.bandUsedBottom = newValue }
    }

    /// 밴드에 들어간 본문 텍스트 블록 (밴드 종료 시 단 균형 재배치용)
    /// — 저장은 band
    private var bandTextBlocks: [HwpColumnBandController.BandTextBlock] {
        get { band.bandTextBlocks }
        set { band.bandTextBlocks = newValue }
    }

    /// 밴드에 텍스트 외 블록(표/개체/placeholder)이 있으면 균형 재배치를 하지
    /// 않는다 — 저장은 band
    private var bandHasNonTextContent: Bool {
        get { band.bandHasNonTextContent }
        set { band.bandHasNonTextContent = newValue }
    }

    /// 밴드 마지막 줄의 줄 간격 (pt) — 저장·산식은 band
    /// (updateBandTrailingSpacing 참조)
    private var bandTrailingLineSpacing: CGFloat {
        band.bandTrailingLineSpacing
    }

    /// 방금 배치한 본문 문단 텍스트 블록 (줄 중간 treatAsChar 앵커의 기준)
    private var currentParagraphContext: (blockFrame: CGRect, lines: [HwpLineFrame])? {
        didSet { inlineAnchorCache = nil }
    }

    /// controlIndex → 인라인 앵커 페이지 좌표 캐시 — 컨트롤마다 전 라인·앵커를
    /// 처음부터 스캔하지 않도록 컨텍스트당 한 번만 만든다 (#12).
    private var inlineAnchorCache: [Int: InlineAnchorPlacement]?
    /// 절대 라인 캐시 배치 — run 분해·높이·슬라이스·stale 판정 계산과
    /// 절대 캐시 전용 상태 (모드·마지막 loc·stale 보정)를 소유한다.
    /// 페이지 확정·블록 방출은 여기 (paginator)에 남는다.
    private var absoluteCachePlacer: HwpAbsoluteCachePlacer
    /// 절대 캐시 모드: lineLocation이 페이지 내 절대 y인 저장본 (한/글 2007
    /// 계열) — 저장은 absoluteCachePlacer
    private var absoluteCacheMode: Bool {
        absoluteCachePlacer.absoluteCacheMode
    }

    /// 현재 페이지에 배치한 마지막 세그먼트의 lineLocation (절대 캐시 모드 전용)
    /// — 저장은 absoluteCachePlacer
    private var lastAbsoluteCacheLoc: Int32 {
        get { absoluteCachePlacer.lastAbsoluteCacheLoc }
        set { absoluteCachePlacer.lastAbsoluteCacheLoc = newValue }
    }

    /// 그 세그먼트의 전진량 (#214) — 저장은 absoluteCachePlacer
    private var lastAbsoluteCacheAdvance: Int {
        get { absoluteCachePlacer.lastAbsoluteCacheAdvance }
        set { absoluteCachePlacer.lastAbsoluteCacheAdvance = newValue }
    }

    /// 쪽 중간에 열린 단 밴드의 첫 캐시 문단을 기다리는가 (#214 리뷰) — 저장은 absoluteCachePlacer
    private var absoluteCacheBandRestarted: Bool {
        get { absoluteCachePlacer.bandRestartedMidPage }
        set { absoluteCachePlacer.bandRestartedMidPage = newValue }
    }

    /// 절대 캐시 모드에서 stale 캐시 문단이 만든 아래 방향 보정 오프셋
    /// (페이지 로컬) — 저장은 absoluteCachePlacer
    private var absoluteCacheStaleOffset: CGFloat {
        get { absoluteCachePlacer.absoluteCacheStaleOffset }
        set { absoluteCachePlacer.absoluteCacheStaleOffset = newValue }
    }

    var cachedPages: [Int: HwpPage] = [:]

    public init(
        sections: [CoreHwp.HwpSection],
        index: HwpIndex,
        fontResolver: HwpFontResolver = HwpFontResolver(),
        imageStore: HwpImageStore = HwpImageStore()
    ) {
        self.sections = sections
        self.index = index
        self.fontResolver = fontResolver
        self.imageStore = imageStore
        paintListBuilder = HwpPaintListBuilder(fontResolver: fontResolver, imageStore: imageStore)
        tableLayout = HwpTableLayout(
            fontResolver: fontResolver, attributeCache: attributeCache
        )
        textboxLayout = HwpTextboxLayout(
            fontResolver: fontResolver, attributeCache: attributeCache
        )
        footnoteCoordinator = HwpFootnoteCoordinator(
            index: index, fontResolver: fontResolver, attributeCache: attributeCache
        )
        pageChrome = HwpPageChromeBuilder(
            index: index, fontResolver: fontResolver, attributeCache: attributeCache
        )
        absoluteCachePlacer = HwpAbsoluteCachePlacer(sections: sections)
        outlineCollector = HwpOutlineCollector(index: index)
        paragraphNumbering = HwpParagraphNumbering.generate(sections: sections, index: index)
        currentPageGeometry = Self.initialGeometry(for: sections)
        currentSectionDef = Self.firstSectionDef(for: sections)
        // init에서는 계산 프로퍼티 (actor-isolated) 대신 저장소에 직접 쓴다.
        footnoteCoordinator.footnoteCounter = Self.initialNoteNumber(
            startingNumber: currentSectionDef?.footNoteShape.startingNumber
        )
        footnoteCoordinator.endnoteCounter = Self.initialNoteNumber(
            startingNumber: currentSectionDef?.endNoteShape.startingNumber
        )
    }

    public func page(at index: Int) async throws -> HwpPage? {
        guard index >= 0 else { return nil }
        if let page = cachedPages[index] {
            return page
        }

        while cachedPages[index] == nil, !didFinishPagination {
            await Task.yield()
            try await computeNextPageSerialized()
        }
        return cachedPages[index]
    }

    public func totalPages() async -> Int {
        while !didFinishPagination {
            await Task.yield()
            do {
                try await computeNextPageSerialized()
            } catch {
                break
            }
        }
        return max(1, cachedPages.count)
    }

    /// computeNextPage는 내부 suspension(Task.yield 등)에서 actor 재진입이
    /// 열리는데 병렬 실행에 안전하지 않다 (문단 커서·페이지 캐시 교차 오염) —
    /// 진행 중이면 완료를 기다린 뒤 반환해 호출자 루프가 조건을 재평가하게
    /// 한다. Task 체이닝 대신 플래그 대기인 이유: 문단 루프의
    /// checkCancellation이 호출자 자신의 취소를 관찰해야 한다 (R38 #1).
    private func computeNextPageSerialized() async throws {
        guard !isComputingPage else {
            while isComputingPage {
                try Task.checkCancellation()
                await Task.yield()
            }
            return
        }
        isComputingPage = true
        defer { isComputingPage = false }
        try await computeNextPage()
    }

    public func unsupportedElements() async -> [HwpUnsupportedElement] {
        collectedUnsupported
    }

    /// 지금까지 조판이 확정한 개요·책갈피 탐색 목록 (문서 순서, #77).
    ///
    /// `unsupportedElements()`와 달리 **조판 도중에 물어도 의미가 있다** —
    /// 확정된 쪽까지의 접두를 돌려주므로 프로그레시브 로딩의 중간 스냅샷이
    /// 그대로 실어 보낸다 (`HwpDocumentMetadata.outline`).
    /// 탐색 목록이 **항목 상한에 걸려 잘렸는가** (#77).
    ///
    /// 목록만으로는 완전한 것과 구별되지 않아 호스트가 온전한 탐색 수단으로
    /// 오인한다 — 책갈피는 미지원 목록에도 뜨지 않으므로 이 신호가 유일한 흔적이다.
    /// 확정 쪽 접두로 잘린 것(`outline()`)은 여기 해당하지 않는다: 그쪽은 조판이
    /// 끝나면 나온다.
    public func outlineIsTruncated() async -> Bool {
        outlineCollector.didReachItemLimit
    }

    public func outline() async -> [HwpOutlineItem] {
        // **확정된 쪽까지만** 낸다. 배치 도중 수집된 항목은 `cachedPages.count + 1`
        // 을 가리키는데 그 쪽은 아직 캐시되지 않았고, 취소되면 끝내 만들어지지
        // 않는다 — 그대로 내보내면 공개 API가 없는 쪽으로 안내한다.
        // `filter`가 아니라 `prefix`인 것은 발행분이 최종 목록의 접두여야
        // `ordinal`이 흔들리지 않기 때문이다 (`HwpDocumentActor`와 같은 술어).
        Array(outlineCollector.items.prefix { $0.pageNumber <= cachedPages.count })
    }
}

/// paragraph-bearing 컨테이너의 **단일 traversal 지점**.
///
/// 진단 walk (`walkUnsupported`)·탐색 목록 수집·중첩 블록 방출이 전부 이 하나를
/// 쓰고, 새 컨테이너는 여기 추가하면 렌더 경로 (`appendControlBlocks`)와 함께
/// 관리된다 (`Sources/HwpKitCore/AGENTS.md` "새 블록 종류 추가").
///
/// actor 상태를 하나도 읽지 않는 순수 함수라 `nonisolated static`이다 — 그래야
/// 조판 없이 문단 트리만 훑는 쪽 (등가 스윕 가드 `HwpLayoutRenderParitySweepTests`)이
/// 분기를 복제하지 않고 같은 정의를 쓴다. 복제하면 새 컨테이너가 추가될 때
/// 가드만 조용히 그 컨테이너를 못 보게 된다.
extension HwpPaginator {
    nonisolated static func childParagraphs(
        of ctrl: CoreHwp.HwpCtrlId
    ) -> [(CoreHwp.HwpParagraph, HwpBlockKind)] {
        Array(childParagraphSequence(of: ctrl))
    }

    /// `childParagraphs(of:)`의 **게으른** 원본 — 같은 순서·같은 분기이고 배열
    /// 버전은 이것을 펼친 것이다. 컨테이너 하나가 문단 수십만 개를 품어도 순회가
    /// 상한이나 취소에서 멈추면 그 뒤 문단은 꺼내지 않는다 — 배열로 펼치면 상한을
    /// 보기도 전에 전체를 복사한다(번호 생성 `HwpParagraphNumbering`, #153).
    /// 새 컨테이너는 **여기에** 분기를 더한다.
    nonisolated static func childParagraphSequence(
        of ctrl: CoreHwp.HwpCtrlId
    ) -> AnySequence<(CoreHwp.HwpParagraph, HwpBlockKind)> {
        switch ctrl {
        case let .header(list), let .footer(list):
            AnySequence(list.listArray.lazy.flatMap(\.paragraphArray).map { ($0, HwpBlockKind.text) })
        case let .footnote(list), let .endnote(list):
            AnySequence(
                list.listArray.lazy.flatMap(\.paragraphArray).map { ($0, HwpBlockKind.footnote) }
            )
        case let .table(table):
            AnySequence(table.cellArray.lazy.flatMap(\.paragraphArray).map { ($0, HwpBlockKind.table) })
        case let .shape(shape),
             let .line(shape),
             let .rectangle(shape),
             let .ellipse(shape),
             let .arc(shape),
             let .polygon(shape),
             let .curve(shape),
             let .equation(shape),
             let .equationLegacy(shape),
             let .picture(shape),
             let .ole(shape),
             let .container(shape):
            AnySequence(
                shape.shapeComponentArray.lazy
                    .flatMap(\.textBoxListArray)
                    .flatMap(\.paragraphArray)
                    .map { ($0, HwpBlockKind.textbox) }
            )
        case let .genShapeObject(genShape):
            AnySequence(
                genShape.shapeComponentArray.lazy
                    .flatMap(\.textBoxListArray)
                    .flatMap(\.paragraphArray)
                    .map { ($0, HwpBlockKind.textbox) }
            )
        default:
            AnySequence([])
        }
    }
}

/// 구역 정의 술어 — 조판·번호 생성(`HwpParagraphNumbering`)·픽스처 테스트가 같은
/// 정의를 쓴다. actor 상태를 읽지 않는 순수 함수라 `nonisolated static`이다.
extension HwpPaginator {
    /// 문서의 첫 구역 정의 — 첫 문단에 없어도 문단을 차례로 훑어 찾는다.
    nonisolated static func firstSectionDef(
        for sections: [CoreHwp.HwpSection]
    ) -> CoreHwp.HwpSectionDef? {
        sections.lazy
            .flatMap(\.paragraph)
            .compactMap { sectionDef(in: $0) }
            .first
    }

    /// 문단에 붙은 첫 구역 정의. 헌법주석은 구역 1부터 단 정의가 앞서 첫 컨트롤이
    /// 구역 정의가 아니므로 컨트롤 배열 전체를 본다.
    nonisolated static func sectionDef(
        in paragraph: CoreHwp.HwpParagraph
    ) -> CoreHwp.HwpSectionDef? {
        // 첫 구역 정의에서 멈춘다 — `compactMap(...).first`는 배열 전체를 훑고
        // 중간 배열까지 만든다.
        for ctrl in paragraph.ctrlHeaderArray ?? [] {
            if case let .section(sectionDef) = ctrl {
                return sectionDef
            }
        }
        return nil
    }
}

private extension HwpPaginator {
    static func initialGeometry(for sections: [CoreHwp.HwpSection]) -> HwpPageGeometry {
        let sectionDef = firstSectionDef(for: sections) ?? CoreHwp.HwpSectionDef()
        return HwpPageGeometry.compute(pageDef: sectionDef.pageDef, sectionDef: sectionDef)
    }

    static func initialNoteNumber(startingNumber: UInt16?) -> Int {
        let starting = Int(startingNumber ?? 1)
        return starting > 0 ? starting : 1
    }

    static func columnDef(in paragraph: CoreHwp.HwpParagraph) -> CoreHwp.HwpColumn? {
        paragraph.ctrlHeaderArray?.compactMap { ctrl in
            if case let .column(column) = ctrl {
                return column
            }
            return nil
        }.first
    }

    // MARK: - 단 (column band)

    /// 현재 채우는 단의 프레임. 밴드가 아직 없으면 콘텐츠 전체. (산식은 band)
    var currentColumnFrame: CGRect {
        band.currentColumnFrame(contentFrame: currentPageGeometry.contentFrame)
    }

    /// 현재 단에서 본문이 쓸 수 있는 높이 (각주 예약 제외)
    var effectiveContentHeight: CGFloat {
        max(1, currentColumnFrame.height - footnoteReservedHeight)
    }

    var sectionDefaultColumnSpacing: CGFloat {
        currentSectionDef.map { HwpUnits.points(fromHwpUnit16: $0.columnSpacing) } ?? 0
    }

    /// 현재 단의 사용량을 밴드 하단 추적에 반영한다. (산식은 band)
    func markBandUsage() {
        band.markUsage(
            contentHeightUsed: contentHeightUsed,
            contentFrame: currentPageGeometry.contentFrame
        )
    }

    /// top에서 시작하는 새 단 밴드를 연다 (밴드 추적 초기화 포함).
    /// 밴드 상태 리셋은 band.open에 단일화; 문단 배치 공유 상태
    /// (contentHeightUsed·paragraphAnchorTop)는 여기서 이어서 리셋한다
    /// (기존 리셋 순서·값 불변 — band.open 주석 참조).
    func openColumnBand(top: CGFloat) {
        band.open(
            top: top,
            contentFrame: currentPageGeometry.contentFrame,
            defaultSpacing: sectionDefaultColumnSpacing
        )
        contentHeightUsed = 0
        paragraphAnchorTop = top
        // 새 밴드의 첫 문단 앞에는 앞 문단의 아래 간격이 없다 (#161).
        lastPlacedSpacingBottom = 0
        // 줄 캐시 위치는 밴드 상단 기준이다 — 앞 밴드의 줄 위치와 견줘 쪽 절단점을 찾지 않고, 쪽
        // 중간에 열린 밴드의 캐시 문단은 자리로도 판정한다 (#214 리뷰, `bandStartOverflows`). 낡은
        // 캐시 보정도 밴드마다 다시 센다 — 새 밴드 상단(`bandUsedBottom`)이 그 몫을 이미 담았다.
        lastAbsoluteCacheLoc = Int32.min
        lastAbsoluteCacheAdvance = 0
        absoluteCacheStaleOffset = 0
        absoluteCacheBandRestarted = !currentBlocks.isEmpty
    }

    /// 밴드를 닫는다. 본문 텍스트가 첫 단에만 남은 다단 밴드는
    /// 라인 단위로 균형 재배치한다 (한글의 단 배분 동작).
    func closeColumnBand() {
        markBandUsage()
        if columnFrames.count > 1, columnIndex == 0,
           !bandHasNonTextContent, !bandTextBlocks.isEmpty
        {
            rebalanceColumnBand()
            // 재배치 후 흐름 상태를 밴드 하단과 일치시킨다
            // (뒤따르는 markBandUsage가 stale 값으로 되돌리지 않게).
            columnIndex = 0
            contentHeightUsed = max(0, bandUsedBottom - currentColumnFrame.minY)
        }
        emitColumnDividers()
        bandTextBlocks = []
        bandHasNonTextContent = false
    }

    /// 밴드의 단 구분선을 한 번 방출한다 (#191) — 밴드 닫기(`closeColumnBand`)와 쪽 확정
    /// (`cacheCurrentPage`) 어느 쪽이 먼저 오든 같은 밴드는 한 번이다. 산식은 band.
    func emitColumnDividers() {
        guard !band.dividersEmitted else { return }
        band.dividersEmitted = true
        currentBlocks += band.columnDividerBlocks(currentBlocks: currentBlocks) { offset, block in
            // 흐름 배치가 기록한 마지막 줄 상자 아래 몫이 먼저다 (#222) — 줄 간격 여분에 문단 아래
            // 간격까지 든다. 한글 12.30 실측(`probes/222` DA): 단 끝 문단의 아래 간격 20pt는
            // 구분선에 들지 않고 구분선은 그 줄 상자 바닥(733.2)에서 끝난다 — 쪽 끝 적합이 줄
            // 상자까지라 그 간격이 본문 아래로 넘친 쪽에서도 같고, 균형 배분된 밴드도 같다(so222r —
            // 재배치 조각은 원래 블록의 기록을 물려받는다). 기록이 없는 블록(문단 끝을 담지 않은
            // 재배치 조각 등)은 아래 규칙이다.
            if let recorded = trailingSpacesBelowLineBox[offset] {
                return recorded
            }
            // 높이를 줄 캐시로 놓은 블록은 그 마지막 줄의 캐시 줄 간격을 싣고 있다
            // (`markedWithCachedTrailingSpacing`·`placeCachedColumnRuns`) — 없으면 높이가 CT
            // 측정이라 조판 문자열 마지막 글자의 규칙값이다 (#191).
            if let attributed = block.attributedString, attributed.length > 0,
               let spacing = attributed.attribute(
                   HwpAttributedStringKey.cachedTrailingLineSpacing,
                   at: attributed.length - 1, effectiveRange: nil
               ) as? NSNumber
            {
                return CGFloat(spacing.doubleValue)
            }
            return block.attributedString.map {
                HwpColumnBandController.measuredTrailingSpacing(
                    of: $0, lineWidth: block.frame.width
                )
            } ?? 0
        }
    }

    /// 높이를 줄 캐시로 놓은 문단 **끝** 블록에 그 캐시 마지막 줄의 줄 간격을 단다
    /// (`HwpAttributedStringKey.cachedTrailingLineSpacing`) — 단 구분선 바닥(#191)이 빼는 값이다.
    /// `cachedTrailingSpacing`은 호출자가 **실제로 캐시 높이를 골랐을 때만** 준다 (PR 리뷰:
    /// 캐시가 유효해도 페이지를 넘는 1줄 문단은 CT 측정 높이로 폴백하고, 캐시 총높이와 CT
    /// 총높이가 같아도 마지막 줄 간격은 다르므로 수치 일치로는 가를 수 없다). 이어지는 조각은
    /// 문단 마지막 줄을 담지 않아 달지 않고, 단별 run 조각은 `placeCachedColumnRuns`가 run 값을
    /// 먼저 달아 둔다.
    static func markedWithCachedTrailingSpacing(
        _ attributed: NSAttributedString, cachedTrailingSpacing: CGFloat?
    ) -> NSAttributedString {
        guard let spacing = cachedTrailingSpacing, attributed.length > 0,
              attributed.attribute(
                  HwpAttributedStringKey.cachedTrailingLineSpacing,
                  at: attributed.length - 1, effectiveRange: nil
              ) == nil,
              HwpDrawnTextLayout.endsParagraph(
                  CFRange(location: 0, length: attributed.length), in: attributed
              )
        else { return attributed }
        return HwpTableSplitter.marked(attributed, cachedTrailingLineSpacing: spacing)
    }

    /// 문단에 붙은 단 정의를 반영한다: 현재 밴드를 닫고 그 아래에서 새 밴드를 연다.
    /// 밴드를 열 자리가 (각주 예약을 빼고) 한 줄도 안 남으면 새 페이지에서 연다 —
    /// 퇴화 밴드는 openColumnBand의 contentHeightUsed 리셋으로 overflow 가드를
    /// 무력화해 본문이 각주 영역/페이지 밖에 강제 배치된다.
    func applyColumnDef(in paragraph: CoreHwp.HwpParagraph) {
        guard let column = Self.columnDef(in: paragraph) else { return }
        let hadBandContent = !bandTextBlocks.isEmpty || bandHasNonTextContent
        closeColumnBand()
        currentColumnDef = column
        let minimumBandHeight: CGFloat = 12 // 대략 한 줄
        let usableBottom = currentPageGeometry.contentFrame.maxY - footnoteReservedHeight
        // 한글은 단 정의로 밴드를 닫을 때 마지막 줄의 줄 간격만큼 띄우고
        // 다음 밴드를 연다 (Column PrvImage 실측: 밴드 간 시작 간격
        // = 줄 전진량 + 줄 간격). 새-페이지 판정도 gap을 더한 실제 시작점으로
        // 한다 — gap 몫을 빼면 한 줄 최소에 못 미치는 퇴화 밴드가 열린다 (R56 #2).
        let gap = hadBandContent ? bandTrailingLineSpacing : 0
        if bandUsedBottom + gap >= usableBottom - minimumBandHeight, !currentBlocks.isEmpty {
            cacheCurrentPage()
        } else {
            openColumnBand(top: bandUsedBottom + gap)
        }
    }

    /// 단이 가득 차면 다음 단으로, 마지막 단이면 새 페이지로 넘어간다.
    /// (단 전진 판정·index 증가는 band, 페이지 확정과 공유 상태 리셋은 여기.)
    func advanceColumn() {
        markBandUsage()
        if band.advanceToNextColumn() {
            contentHeightUsed = 0
            paragraphAnchorTop = currentColumnFrame.minY
        } else {
            cacheCurrentPage()
        }
    }

    /// 첫 단에만 쌓인 밴드 텍스트를 라인 단위로 모든 단에 균등 재배치한다.
    /// 재배치 플랜 (교체 index·새 블록) 산출은 band.rebalancePlan,
    /// currentBlocks 재작성 적용은 여기서 한다.
    func rebalanceColumnBand() {
        guard let plan = band.rebalancePlan(
            currentBlocks: currentBlocks, lineBoxGaps: trailingSpacesBelowLineBox
        ) else { return }
        // 블록 배열을 다시 쓰면 블록 인덱스를 열쇠로 둔 부속 정보도 함께 옮긴다 (#165 리뷰,
        // `trailingSpacesBelowLineBox`). 재배치는 다단 밴드의 꼬리 블록만 갈아 끼우므로 앞
        // 블록의 인덱스는 밀리지 않지만, 위치 열쇠가 배열 재작성과 따로 놀면 그 전제가 바뀔 때
        // 다른 블록의 몫을 빼게 된다. 갈아 끼운 흐름 블록의 상자 아래 몫(#222)은 새 조각이
        // 물려받는다(`RebalancePlan.newBlockLineBoxGaps`, PR 리뷰) — 버리면 단 구분선이 측정
        // 규칙(`measuredTrailingSpacing` — 문단 아래 간격은 빼지 않는다)으로 재어 마지막 문단의
        // 아래 간격만큼 길어진다. 한글 12.30 실측(so222r)은 균형 배분 밴드도 줄 상자 바닥이다.
        var kept: [AnyHwpBlock] = []
        var remapped: [Int: CGFloat] = [:]
        for (offset, block) in currentBlocks.enumerated()
            where !plan.replacedBlockIndices.contains(offset)
        {
            if let spacing = trailingSpacesBelowLineBox[offset] {
                remapped[kept.count] = spacing
            }
            kept.append(block)
        }
        for (offset, gap) in plan.newBlockLineBoxGaps.enumerated() {
            if let gap {
                remapped[kept.count + offset] = gap
            }
        }
        currentBlocks = kept + plan.newBlocks
        trailingSpacesBelowLineBox = remapped
        bandUsedBottom = plan.maxBottom
    }

    /// `processParagraph` 한 번의 결과 — 문단 루프를 계속할지, `computeNextPage`가
    /// 호출자에게 돌아갈지를 가른다.
    enum ParagraphOutcome {
        /// 다음 문단으로 진행한다.
        case advance
        /// 이 호출을 여기서 끝낸다 — 페이지 상한 도달, 쪽 나누기로 페이지 확정,
        /// 배치 실패(문단을 다음 페이지에서 재처리), 또는 새 페이지 생성.
        case yieldToCaller
    }

    func computeNextPage() async throws {
        await Task.yield()

        if sections.isEmpty {
            cacheCurrentPage()
            didFinishPagination = true
            return
        }

        let pageCountBefore = cachedPages.count

        while let paragraph = nextParagraph() {
            let outcome = try await processParagraph(paragraph, pageCountBefore: pageCountBefore)
            if outcome == .yieldToCaller {
                return
            }
        }

        try finishPagination()
    }

    /// 문단 하나를 처리한다 — 페이지 확정 판정, 구역·단 정의 적용, 측정, 배치,
    /// 부수 수집(각주·메모·컨트롤·미지원·개요)까지.
    ///
    /// `pageCountBefore`는 이 `computeNextPage` 호출 진입 시점의 캐시 페이지 수다 —
    /// 이 호출에서 페이지가 하나라도 생기면 호출자가 진행을 관찰하도록 돌아간다.
    func processParagraph(
        _ paragraph: CoreHwp.HwpParagraph,
        pageCountBefore: Int
    ) async throws -> ParagraphOutcome {
        // 페이지 상한 도달 후 남은 문단은 레이아웃해도 캐시되지 않는다 —
        // 즉시 종료해 상한이 CPU 상한으로도 작동하게 한다 (#1).
        if didFinishPagination {
            return .yieldToCaller
        }
        // 취소된 로드가 0-높이 문단을 대량 처리할 때 page(at:) 반환 전에
        // 취소를 관찰해 옛 문서 레이아웃이 교체본과 나란히 도는 것을 막는다 (#3).
        try Task.checkCancellation()
        // 글줄 앞 표(#190)를 이미 놓은 문단의 재시도면 문단 **진입** 처리(구역 시작·쪽 나누기
        // 확정, 구역·단 정의, 새 번호 지정)를 되풀이하지 않는다 — 첫 시도에서 이미 적용됐고
        // 표가 그 상태로 쪽을 넘겼다. 되풀이하면 구역 시작 번호가 다시 놓여 쪽 번호가 7·7이
        // 되고(구역 첫 문단의 표가 쪽을 채운 경우), 새 번호 7을 셀 각주가 쓴 뒤 본문 각주가
        // 다시 7)을 받으며, 구역 시작의 미주 확정이 표 셀의 미주를 새 쪽 머리에 낸다 (PR 리뷰).
        if !isRetryingParagraphWithPlacedTables {
            // 구역 시작/쪽 나누기 문단: 진행 중인 페이지를 확정하고 이 문단은
            // 다음 호출에서 새 페이지 첫머리로 다시 처리한다.
            if try flushPageBeforeProcessing(paragraph) {
                return .yieldToCaller
            }
            applySectionDef(in: paragraph)
            applyColumnDef(in: paragraph)
            applyNewNumbers(in: paragraph)
        }
        currentParagraphMargins = paragraphMargins(of: paragraph)

        beginParagraphEntryFlow(for: paragraph)
        // 개요의 시작 쪽은 문단의 **첫 콘텐츠가 놓인** 쪽이다 — 글줄 앞 표(#190)가 먼저 놓이면
        // 그 첫 조각의 쪽이고(`appendTableSegmentBlock`이 기록), 그 뒤 글줄이 밀려 재시도해도
        // 유지된다 (PR 리뷰: 제목 문단의 표가 1쪽부터인데 목록이 글줄의 3쪽을 가리켰다).
        if !isRetryingParagraphWithPlacedTables {
            currentParagraphFirstPlacedPage = nil
        }
        // 번호/개요 문단 머리의 진단 페이지는 문단이 시작하는 첫 페이지다 —
        // placeParagraphText가 다중 페이지 문단의 앞 조각 페이지를 먼저
        // 캐시하므로 배치 전에 첫 페이지를 잡는다 (#3). 글줄 앞 표(#190)를 놓기 **전**의
        // 값이다 — 진단은 종전 값 그대로이고 (루트 AGENTS "쪽 기준이 둘이다"), 표의 첫 조각
        // 쪽을 따르는 것은 개요(`collectOutline`의 `currentParagraphFirstPlacedPage`)뿐이다
        // (PR 리뷰: 공개 `unsupportedElements`의 쪽이 표 착지 쪽으로 바뀌면 안 된다).
        let paragraphFirstPage = cachedPages.count + 1
        // 자리 차지 표는 문단 글줄 **앞**에 놓인다 (#190) — 흐름 배치 문단은 표를 먼저
        // 흘리고 글줄이 그 뒤를 따른다. 절대 캐시 배치 문단은 캐시 간격(띠)이 자리다 (#161).
        // 측정 **앞**이어야 한다: 표가 단·쪽을 넘기면 글줄은 그 단 폭으로 재야 하고, 표 셀
        // 각주가 번호를 먼저 가져가므로 본문 각주 참조 미리보기도 그 뒤 카운터로 구워야
        // 참조와 각주가 같은 번호를 쓴다 (PR 리뷰).
        appendTablesPrecedingText(from: paragraph)
        let widthCenti = Int((currentColumnFrame.width * 100).rounded())
        let replacements = noteReferenceReplacements(for: paragraph)
        let measured = try await measuredParagraph(
            paragraph,
            widthCenti: widthCenti,
            replacements: replacements
        )
        guard placeParagraphText(
            paragraph,
            attributedString: measured.attributedString,
            paragraphFrame: measured.paragraphFrame
        ) else {
            // 현재 페이지가 확정됐고 문단은 다음 페이지에서 다시 처리한다 —
            // 빌드 입력이 그대로면 메모로 build + CT 재실행을 건너뛴다.
            measureMemo = ParagraphMeasureMemo(
                sectionIndex: nextSectionIndex,
                paragraphIndex: nextParagraphIndex,
                widthCenti: widthCenti,
                replacements: replacements,
                attributedString: measured.attributedString,
                paragraphFrame: measured.paragraphFrame
            )
            return .yieldToCaller
        }
        measureMemo = nil
        recordSpacingBottomForNextBand(of: paragraph)
        collectParagraphFootnotesUnlessPlacedPerFragment(paragraph)
        collectMemos(from: paragraph)
        appendControlBlocks(
            from: paragraph,
            numbering: currentParagraphScope,
            skipping: controlsPlacedBeforeParagraphEnd
        )
        collectUnsupported(from: paragraph, firstPage: paragraphFirstPage)
        collectOutline(from: paragraph, firstPage: paragraphFirstPage)
        advanceParagraph()
        await yieldPeriodically()

        // 이 호출에서 이미 페이지가 생겼으면 반환해 호출자가 진행을 관찰하게 한다.
        return cachedPages.count > pageCountBefore ? .yieldToCaller : .advance
    }

    /// 문단의 텍스트 런과 조판 프레임을 만든다 — 직전 호출이 배치에 실패해 남긴
    /// 측정 메모가 같은 입력이면 재사용해 build + CoreText 재실행을 건너뛴다.
    func measuredParagraph(
        _ paragraph: CoreHwp.HwpParagraph,
        widthCenti: Int,
        replacements: [Int: HwpControlMarkerReplacement]
    ) async throws -> (attributedString: NSAttributedString, paragraphFrame: HwpParagraphFrame) {
        if let memo = measureMemo,
           memo.sectionIndex == nextSectionIndex,
           memo.paragraphIndex == nextParagraphIndex,
           memo.widthCenti == widthCenti,
           memo.replacements == replacements
        {
            return (memo.attributedString, memo.paragraphFrame)
        }
        // 글자처럼 취급 표는 그려지는 높이로 줄을 예약한다 (#214) — 메모 열쇠의 단 폭·문단
        // 위치가 그 높이의 입력(단 폭·크기 해석기·셀 번호)도 정하므로 메모는 그대로 유효하다.
        var builder = textRunBuilder()
        builder.inlineTableHeights = inlineTableHeights(for: paragraph)
        let attributedString = builder.build(
            paragraph: paragraph, controlReplacements: replacements,
            number: currentParagraphNumber
        )
        let paragraphFrame: HwpParagraphFrame = if absoluteCachePlacer.canSkipMeasurement(
            for: paragraph,
            attributedString: attributedString,
            columnCount: columnFrames.count
        ) {
            HwpParagraphFrame(totalHeight: 0, lines: [])
        } else {
            try await layout(paragraph, attributedString: attributedString)
        }
        return (attributedString, paragraphFrame)
    }

    /// 문단 커서가 가리키는 최상위 문단의 문단 번호·개요 번호 (#154) — 라벨 전치
    /// (`measuredParagraph`)와 진단 제외(`collectUnsupportedNumberingHeading`)가 같은
    /// 값을 본다. 둘 다 `advanceParagraph()` 앞에서 불리므로 같은 열쇠다.
    var currentParagraphNumber: HwpParagraphNumber? {
        currentParagraphScope.number
    }

    /// 문단 커서가 가리키는 최상위 문단의 번호 열쇠 (#158) — 컨테이너 문단(표 셀·
    /// 글상자·각주·미주·머리말/꼬리말)은 여기서 컨트롤 서수·자식 서수를 이어 붙여
    /// 내려간다(`appendControlBlocks`·`walkUnsupported`·각주 수집·쪽 크롬 등록).
    /// `advanceParagraph()` 앞에서만 유효하다.
    var currentParagraphScope: HwpNumberingScope {
        HwpNumberingScope(
            numbering: paragraphNumbering,
            path: HwpParagraphPath(
                sectionIndex: nextSectionIndex, paragraphIndex: nextParagraphIndex
            )
        )
    }

    /// 문서 끝 처리 — 밴드를 닫고 마지막 본문 페이지를 확정한 뒤, 남은 미주는
    /// 새 쪽에서 시작한다 (한글.app 실측 2026-07-06 — footnote-endnote
    /// 픽스처의 미주가 2쪽에 표시됨을 사용자 확인).
    func finishPagination() throws {
        closeColumnBand()
        if !pendingEndnotes.isEmpty, !currentBlocks.isEmpty || contentHeightUsed > 0 {
            cacheCurrentPage()
        }
        try appendPendingEndnotes()
        cacheCurrentPage()
        // 마지막 페이지에서 넘친 각주가 있으면 빈 페이지를 이어 붙여 모두 배치한다.
        // 페이지 상한에 걸려 cacheCurrentPage가 캐시를 거부하면(didFinishPagination
        // = true, pendingFootnotes 불변) 무한 회전하므로 그때 멈춘다 (#4).
        while !pendingFootnotes.isEmpty, !didFinishPagination {
            // 취소 시 각주 드레인이 페이지 상한까지 동기로 돌아 취소 관찰이
            // 늦어지지 않게 매 페이지 확인 (`processParagraph`의 문단 루프와
            // 같은 이유, P2b).
            try Task.checkCancellation()
            cacheCurrentPage()
        }
        didFinishPagination = true
    }

    /// `yieldBatchSize` 문단마다 한 번만 양보한다.
    ///
    /// 문단마다 양보하면 20,000 문단 문서에서 최대 40,000번의 스케줄러 왕복이
    /// 생기는데, 그 대부분은 다른 Task가 없어 즉시 되돌아온다. 취소 관찰은
    /// `Task.checkCancellation()`이 문단마다 따로 하므로 이 배칭에 영향받지 않는다.
    func yieldPeriodically() async {
        yieldCounter += 1
        if yieldCounter >= Self.yieldBatchSize {
            yieldCounter = 0
            await Task.yield()
        }
    }

    /// 새 구역 정의 (이전 구역의 밴드를 닫고 구역-끝 미주 배치) 또는
    /// 쪽 나누기 (문단 헤더 columnType bit 2)를 만나면 진행 중인 페이지를
    /// 확정한다. 페이지를 확정했으면 true (호출자가 반환하고 같은 문단을
    /// 새 페이지에서 다시 처리한다).
    func flushPageBeforeProcessing(_ paragraph: CoreHwp.HwpParagraph) throws -> Bool {
        if Self.sectionDef(in: paragraph) != nil {
            closeColumnBand()
            if currentSectionDef?.endNoteShape.placesEndnoteAtSectionEnd == true {
                try appendPendingEndnotes()
            }
            if !currentBlocks.isEmpty || contentHeightUsed > 0 {
                cacheCurrentPage()
                return true
            }
        }
        if paragraph.paraHeader.columnType & 0b100 != 0,
           !currentBlocks.isEmpty || contentHeightUsed > 0
        {
            closeColumnBand()
            cacheCurrentPage()
            return true
        }
        return false
    }

    /// 문단 텍스트 블록을 흐름에 배치한다.
    /// 문단이 남은 공간에 안 맞아 페이지를 확정했으면 false (호출자가 반환하고
    /// 같은 문단을 다음 페이지에서 다시 처리한다).
    func placeParagraphText(
        _ paragraph: CoreHwp.HwpParagraph,
        attributedString: NSAttributedString,
        paragraphFrame: HwpParagraphFrame
    ) -> Bool {
        // 조각 단위 각주 수집 여부는 배치 경로가 정한다 (#95) — 매 배치마다
        // 초기화해 앞 문단의 값이 새지 않게 한다. 미룬 컨테이너 각주 버퍼도
        // 열쇠(컨트롤 서수)가 문단 안에서만 유일해 같이 비운다.
        collectedFootnotesDuringPlacement = false
        inlineControlsPlacedPerFragment = [:]
        footnoteCoordinator.resetDeferredNestedFootnotes()
        // 변경 추적 문단이면 배치 전에 paraId를 기록한다 — 배치 중 페이지가
        // 캐시될 때마다 (절대 캐시 run·advanceColumn) 그 조각이 막대를 받게 (#7).
        recordTrackChangeParagraphIfNeeded(for: paragraph)
        // 절대 캐시 모드 (1단): 한글이 계산한 y/페이지 절단점을 그대로 재현한다.
        return if let runs = absoluteCacheRuns(for: paragraph) {
            placeAbsoluteCachedParagraph(
                paragraph,
                attributedString: attributedString,
                paragraphFrame: paragraphFrame,
                runs: runs
            )
        } else {
            placeFlowParagraph(
                paragraph,
                attributedString: attributedString,
                paragraphFrame: paragraphFrame
            )
        }
    }

    /// 이 문단이 절대 캐시 경로(`placeAbsoluteCachedParagraph`)로 배치될 때 그 run들 —
    /// 아니면 nil (흐름 배치). 절대 캐시 모드의 **1단** 밴드에서 줄 캐시가 있는 문단만이다;
    /// 다단 밴드는 절대 캐시 모드라도 흐름 배치(`appendParagraphAcrossColumns`)를 탄다.
    /// 배치(`placeParagraphText`)와 글줄 앞 표 판정(`appendTablesPrecedingText`)이 **같은
    /// 술어**를 봐야 표가 띠와 흐름 어느 쪽으로 갈지 갈리지 않는다 (#190).
    private func absoluteCacheRuns(
        for paragraph: CoreHwp.HwpParagraph
    ) -> [[CoreHwp.HwpParaLineSegInternal]]? {
        guard absoluteCacheMode, columnFrames.count <= 1 else { return nil }
        return HwpAbsoluteCachePlacer.cacheRuns(for: paragraph)
    }

    /// 변경 추적 마크(PARA_RANGE_TAG kind 16/17)가 있으면 paraId를 기록한다.
    /// 실제 막대는 페이지 캐시 직전 emitTrackChangeBars가 조각마다 그린다 (#7).
    private func recordTrackChangeParagraphIfNeeded(for paragraph: CoreHwp.HwpParagraph) {
        let hasTrackChange = (paragraph.paraRangeTagArray ?? []).contains { tag in
            let kind = tag.tag >> 24
            return kind == 16 || kind == 17
        }
        if hasTrackChange {
            trackChangeParagraphIds.insert(paragraph.paraHeader.paraId)
        }
    }

    /// 변경 추적 문단이 이 페이지에 만든 각 텍스트 조각 왼쪽에 한글.app처럼
    /// 빨간 변경 막대를 그린다. 페이지가 캐시되기 직전에 호출돼, 페이지 걸친
    /// 문단의 앞 조각도 자기 페이지에서 막대를 받는다 — 배치 후 currentBlocks만
    /// 보면 이미 캐시된 앞 페이지 조각이 빠진다 (#7, round13 #2 미완).
    private func emitTrackChangeBars(footnoteTop: CGFloat?) {
        guard !trackChangeParagraphIds.isEmpty else { return }
        let barX = currentPageGeometry.contentFrame.minX - 10
        let barColor = CGColor.hwpTrackChange
        // 쪽 끝 적합이 줄 상자까지라(#222) 흐름 블록은 줄 간격 여분·아래 간격만큼 본문 아래로 나갈
        // 수 있다 — 막대는 본문 하단에서 멈춘다(절대 캐시 run 블록이 본문 하단에서 잘리는 것과 같다).
        // 각주가 있는 쪽의 본문 하단은 각주 영역이 칠하는 상단이다 (#222 PR 리뷰 — 쪽 하단까지
        // 두면 넘친 여분을 따라 막대가 구분선·각주 옆으로 내려간다; 구분선 획이 위 여백보다 굵으면
        // 그 획 상단이다 — 예약이 그 몫을 센다). 다만 기록된 마지막 줄 상자는 자르지 않는다: 상자까지는
        // 그려진 글줄이다(각주를 덮는 기존 격차의 문단도 그 줄에 막대가 선다). 상자가 블록 아래로
        // 나간 줄(고정 줄 간격 < 상자 — 기록이 음수)은 그 상자 바닥까지 긋는다 (#222 PR 리뷰).
        let bodyBottom = min(
            currentPageGeometry.contentFrame.maxY, footnoteTop ?? .greatestFiniteMagnitude
        )
        let bars: [AnyHwpBlock] = currentBlocks.enumerated().compactMap { offset, block in
            guard block.kind == .text,
                  let paragraphId = block.source?.paragraphId,
                  trackChangeParagraphIds.contains(paragraphId) else { return nil }
            let lineBoxBottom = trailingSpacesBelowLineBox[offset].map { block.frame.maxY - $0 }
            let drawnBottom = max(block.frame.maxY, lineBoxBottom ?? block.frame.maxY)
            let limit = max(bodyBottom, lineBoxBottom ?? bodyBottom)
            let height = max(0, min(drawnBottom, limit) - block.frame.minY)
            guard height > 0 else { return nil }
            let barRect = CGRect(x: 0, y: 0, width: 1.2, height: height)
            return AnyHwpBlock(
                frame: CGRect(
                    x: barX, y: block.frame.minY, width: barRect.width, height: barRect.height
                ),
                kind: .shape,
                payload: .shape(HwpShapeGeometry(
                    path: CGPath(rect: barRect, transform: nil),
                    fillColor: barColor,
                    strokeColor: nil,
                    strokeWidth: 0
                ))
            )
        }
        currentBlocks.append(contentsOf: bars)
    }

    /// 흐름 기반 문단 배치 (절대 캐시 모드가 아닌 저장본/경로)
    private func placeFlowParagraph(
        _ paragraph: CoreHwp.HwpParagraph,
        attributedString: NSAttributedString,
        paragraphFrame: HwpParagraphFrame
    ) -> Bool {
        // 글줄 앞에 자리 차지 표를 놓은 문단은 저작 문단 위 간격을 **쓰지 않는다** (#190,
        // 한글 12.30 실측: 위 간격 20pt를 준 문단의 표는 표 앞에도, 표와 글줄 사이에도
        // 그 간격 없이 놓인다 — 같은 간격을 준 보통 문단은 20pt 내려간다). 문단 높이와
        // 측정 프레임에서 그 몫을 함께 걷어 높이 출처 판정(`heightIsMeasured`)이 그대로다.
        let suppressedGap = tablesPlacedBeforeText.isEmpty ? 0 : authoredBeforeGap(of: paragraph)
        let paragraphFrame = suppressedGap > 0
            ? HwpParagraphFrame(
                totalHeight: max(1, paragraphFrame.totalHeight - suppressedGap),
                lines: paragraphFrame.lines
            )
            : paragraphFrame
        var paragraphHeight = suppressedGap > 0
            ? max(1, height(for: paragraph, fallback: paragraphFrame.totalHeight + suppressedGap)
                - suppressedGap)
            : height(for: paragraph, fallback: paragraphFrame.totalHeight)
        // 높이 출처가 캐시인지는 수치 일치가 아니라 **선택**으로 기록한다 — 캐시 총높이와 CT
        // 총높이가 우연히 같아도 마지막 줄 간격은 다르다 (단 구분선 바닥, PR 리뷰). 글자처럼 취급
        // 표보다 낮은 캐시는 쓰지 않는다 (`lineCacheHeightIsUsable`, #214 PR 리뷰).
        var cacheHeightUsed = lineCacheHeightIsUsable(
            paragraph, measuredHeight: paragraphFrame.totalHeight + suppressedGap
        )
        // 캐시 높이가 페이지를 넘는데 CT 라인도 하나뿐이면 (표/개체 앵커가 캐시
        // 높이를 지배하는 문단) 캐시 높이를 그대로 쓸 수 없다 — 개체는 별도
        // 블록으로 배치되므로 텍스트 몫은 CT 측정 높이로 폴백한다.
        if paragraphHeight > currentColumnFrame.height, paragraphFrame.lines.count <= 1 {
            paragraphHeight = paragraphFrame.totalHeight
            cacheHeightUsed = false
        }
        let cachedTrailingSpacing = cacheHeightUsed
            ? HwpColumnBandController.cachedTrailingSpacing(of: paragraph) : nil
        // 이 문단이 만들 각주 예약 높이를 미리 반영해 본문/각주 겹침을 막는다.
        let anticipatedFootnotes = anticipatedFootnoteHeight(for: paragraph)
        // 문단-앞 간격은 paragraphHeight에 포함되지만 CoreText는 각 블록(별도
        // 프레임의 첫 문단)에 paragraphSpacingBefore를 렌더하지 않는다 — 모든 배치
        // 경로(다단·초과 조각·단일 블록)가 텍스트 앞에서 커서로 소비한다 (P1, #1).
        let beforeGap = suppressedGap > 0 ? 0 : authoredBeforeGap(of: paragraph)
        // 쪽·단 경계의 분할 규칙(외톨이줄 보호·문단 보호)과 조각별 각주 귀속 문맥 (#207).
        // 귀속 문맥이 있으면 각주 예약은 조각 루프가 줄마다 그 조각 범위로 재므로 문단 전체
        // 예약(`anticipatedFootnotes`)은 통째 배치 판정에만 쓴다.
        let fragmentFootnotes = flowFragmentFootnotes(
            for: paragraph, attributedString: attributedString
        )
        let split = FlowSplitInput(
            paragraph: paragraph,
            attributedString: attributedString,
            paragraphFrame: paragraphFrame,
            paragraphHeight: paragraphHeight,
            beforeGap: beforeGap,
            cachedTrailingSpacing: cachedTrailingSpacing,
            reservedFootnoteHeight: fragmentFootnotes == nil ? anticipatedFootnotes : 0,
            splitPolicy: HwpParagraphSplitPolicy(paraShape: index.paraShapeOrDefault(for: paragraph)),
            fragmentFootnotes: fragmentFootnotes,
            fitLines: paragraphFrame.lines.isEmpty
                ? emptyParagraphLines(paragraph, attributedString: attributedString)
                : paragraphFrame.lines,
            cachedLineBoxBottom: cacheHeightUsed ? cachedLineBoxExtent(paragraph) : nil
        )
        if columnFrames.count > 1 {
            placeMultiColumnParagraph(split)
            return true
        }
        // 쪽 끝 적합은 문단 높이(전진량 합 + 아래 간격)가 아니라 마지막 줄 **상자 하단**까지로
        // 판정한다 (#222 — 한글 12.30 실측: 남은 17.62pt에 16pt·160% 한 줄 문단을 남긴다). 줄
        // 간격 여분과 아래 간격은 쪽 아래로 넘쳐도 되고, 그 몫은 다음 쪽으로 이월하지 않는다
        // (다음 문단이 새 쪽 상단에서 시작한다). 높이와 같은 출처로 잰다
        // (`paragraphFitHeight`).
        let fitHeight = paragraphFitHeight(split)
        if contentHeightUsed > 0,
           !HwpPageEndFit.fits(
               contentHeightUsed + fitHeight, in: effectiveContentHeight - anticipatedFootnotes
           )
        {
            // 문단 전체는 남은 자리에 안 들어간다. 남은 자리에 들어가는 줄이 있으면 그 줄들을
            // 이 쪽에 두고 나머지를 다음 쪽에 잇는다 (#207 — 한글 12.30 실측: 외톨이줄 보호가
            // 꺼진 3줄 문단은 첫 줄이 들어가면 첫 줄만 남기고 둘을 다음 쪽으로 넘긴다). 첫 조각의
            // 줄 수는 조각 루프의 첫 반복과 **같은 함수·입력**으로 정한다 — 여기서 남는다고 본
            // 줄을 루프가 넘기거나 그 반대면 안 된다. 각주 예약은 그 줄들의 각주 몫만 든다
            // (`HwpFlowFragmentFootnotes`).
            //
            // 한 줄도 못 남기면(문단 보호·외톨이줄 보호·한 줄 문단·첫 줄 + 그 각주가 안 들어감)
            // 종전대로 쪽을 확정하고 다음 쪽에서 다시 처리한다 — 재처리가 각주 참조 번호·자동
            // 쪽 번호·진단 쪽을 새 쪽 기준으로 다시 잡는다. 글줄 앞에 놓은 표(#190)는 다시
            // 처리해도 다시 놓이지 않는다 (`appendTablesPrecedingText`가 같은 문단이면 건너뛴다).
            if canSplitAtEntry(split, cacheHeightUsed: cacheHeightUsed),
               entryFragmentLineCount(split) > 0
            {
                appendFlowParagraphAcrossPages(split)
                return true
            }
            cacheCurrentPage()
            return false
        }
        // 빈 페이지에도 안 들어가는 문단 (여러 페이지에 걸친 라인 캐시)은 1단에서도
        // 라인 단위로 나눠 페이지에 흘린다 (1단 밴드의 advanceColumn == 새 페이지).
        //
        // 빈 쪽이라도 본문 하단은 각주 영역 상단이다 (#222 PR 리뷰) — 문단 자신의 각주(와 앞 쪽에서
        // 이월된 각주)를 빼면 안 들어가는 문단은 조각 루프로 보내 줄마다 그 줄의 각주와 함께 판정한다.
        // 종전에는 단 전체 높이와만 견줘, 문단 보호로 빈 쪽에 다시 온 20pt·160% 세 줄 문단(상자
        // 하단 84)이 두 줄 각주를 품고도 통째로 놓여 마지막 줄이 각주 영역을 덮었다(전진량 판정일
        // 때는 문단 높이 116 > 100이라 나뉘었다).
        //
        // 부분 채운 쪽의 진입 분할 게이트(`canSplitAtEntry` — 조각별 각주 귀속·문단 머리 컨트롤·
        // 캐시 줄 수)를 못 지나는 문단도 각주 위 판정에서 기준(#222 이전)의 초과 문단 분할은 그대로
        // 받는다 (PR 리뷰 — 쪽마다 번호를 새로 매기는 구역의 같은 문단은 마지막 줄의 각주를 품고도
        // 통째로 놓여 그 각주를 덮었다). 기준은 문단 높이(`paragraphHeight` — 위 간격 + 전진량 합 +
        // 아래 간격)가 단보다 크면 나눴다. 각주 위 판정에서는 게이트를 못 지나는 문단을 그보다 넓게
        // 나누지 않는다 — 조각별 귀속이 없어 각주가 마지막 조각 쪽으로 가고 문단 전체 예약이 쪽마다
        // 빠지며(그 예약이 쪽만큼 크면 쪽마다 한 줄씩 흘린다), 문단 머리 컨트롤은 뒤 조각 쪽에서
        // 방출된다. 상자가 단 자체를 넘으면(`exceedsColumn`) 게이트와 무관하게 나눈다 — 고정 줄
        // 간격이 상자보다 작아 문단 높이는 단에 들어가도 상자가 넘는 문단도 그렇다(#222).
        //
        // 줄의 각주가 그 줄과 함께 안 들어갈 때 한글은 줄을 남기고 각주만 본문 아래 남은 자리까지
        // 싣고 나머지를 다음 쪽에 잇는다 (한글 12.30 실측 2026-09-24, 쪽마다 번호 구역의 20pt·160%
        // 20줄 문단: 마지막 줄 두 줄 각주면 20줄을 모두 남기고 각주 첫 줄만 싣는다; 첫 줄 각주면
        // 우리처럼 19 + 1로 나눈다). 흐름 경로에는 그 이월이 없어(#207의 남은 격차) 줄을 각주와 함께
        // 넘긴다 — 본문이 각주를 덮지 않게 하는 기준 동작이다.
        let exceedsColumn = !HwpPageEndFit.fits(fitHeight, in: currentColumnFrame.height)
        let exceedsBodyAboveNotes = !HwpPageEndFit.fits(
            fitHeight, in: effectiveContentHeight - anticipatedFootnotes
        ) && (
            paragraphHeight > currentColumnFrame.height
                || canSplitAtEntry(split, cacheHeightUsed: cacheHeightUsed)
        )
        if paragraphFrame.lines.count > 1, exceedsColumn || exceedsBodyAboveNotes {
            appendFlowParagraphAcrossPages(split)
            return true
        }
        contentHeightUsed += beforeGap
        paragraphAnchorTop = currentColumnFrame.minY + contentHeightUsed
        appendBlock(
            height: paragraphHeight - beforeGap,
            attributedString: attributedString,
            hyperlinkURL: hyperlinkURL(in: paragraph),
            paragraphId: paragraph.paraHeader.paraId,
            lines: paragraphFrame.lines,
            // 캐시 높이(`height(for:fallback:)`)를 썼으면 마지막 줄 몫은 측정값이 아니다 (#166).
            heightIsMeasured: abs(paragraphHeight - paragraphFrame.totalHeight) < 0.01,
            paraShape: index.paraShapeOrDefault(for: paragraph),
            cachedTrailingSpacing: cachedTrailingSpacing
        )
        recordFlowTrailingSpace(
            blockHeight: paragraphHeight - beforeGap, fitHeight: fitHeight - beforeGap
        )
        updateBandTrailingSpacing(for: paragraph)
        return true
    }

    /// 다단 밴드 문단 배치: 한글 라인 캐시가 단별 run (loc 리셋 = 단 경계)을
    /// 주면 한글의 단별 텍스트 배분을 그대로 재현하고 — 비등폭 단은 라인 수가
    /// 아니라 단 폭에 맞는 글자 위치로 나뉜다 (Column 픽스처 캐시/PrvImage
    /// 실측) — 아니면 라인 단위로 단을 채운다.
    private func placeMultiColumnParagraph(_ split: FlowSplitInput) {
        // 캐시 run 경로는 한글이 계산한 절대 위치를 그대로 재현하므로 간격 보정을
        // 더하지 않는다 (#1).
        if placeCachedColumnRuns(
            split.paragraph,
            attributedString: split.attributedString,
            paragraphFrame: split.paragraphFrame
        ) {
            return
        }
        appendFlowParagraphAcrossPages(split)
    }

    /// 흐름 문단을 줄 단위로 나누는 세 자리(다단 밴드·부분 채운 1단 쪽·빈 쪽보다 긴 문단)가
    /// `appendParagraphAcrossColumns`에 같은 인자를 넘긴다 (#207).
    private struct FlowSplitInput {
        let paragraph: CoreHwp.HwpParagraph
        let attributedString: NSAttributedString
        let paragraphFrame: HwpParagraphFrame
        let paragraphHeight: CGFloat
        let beforeGap: CGFloat
        let cachedTrailingSpacing: CGFloat?
        /// 조각 루프에 상수로 넘기는 문단 전체 각주 예약 — 조각별 귀속 문맥이 있으면 0이다.
        let reservedFootnoteHeight: CGFloat
        let splitPolicy: HwpParagraphSplitPolicy
        let fragmentFootnotes: HwpFlowFragmentFootnotes?
        /// 쪽 끝 적합(#222)에 쓸 줄 프레임 — `paragraphFrame.lines`이고, 빈 문단은 그것이 비어
        /// 있어 한 번 더 조판한 앵커 줄이다 (`emptyParagraphLines`).
        let fitLines: [HwpLineFrame]
        /// 문단 높이를 저장본 줄 캐시로 잡았을 때 그 캐시의 줄 상자 바닥 (`cachedLineBoxExtent`) —
        /// 아니면 nil.
        let cachedLineBoxBottom: CGFloat?

        /// 흐름 분할의 나머지가 쓸 줄 상자 (#222) — 진입 판정과 조각 루프가 같은 값을 쓴다. 빈
        /// 문단의 상자도 높이와 같은 출처다 — 캐시 높이를 쓴 빈 문단은 캐시의 줄 상자 바닥이다
        /// (`paragraphFitHeight`와 같은 값, #222 리뷰: 다단만 CT 상자로 재 1단과 갈렸다).
        var fitSource: HwpFragmentFitSource {
            HwpFragmentFitSource(
                emptyLineBoxHeight: paragraphFrame.lines.isEmpty
                    ? cachedLineBoxBottom ?? fitLines.first?.boxHeight : nil,
                cachedLastLineBoxBottom: cachedLineBoxBottom
            )
        }
    }

    private func appendFlowParagraphAcrossPages(_ split: FlowSplitInput) {
        appendParagraphAcrossColumns(
            attributedString: split.attributedString,
            paragraphFrame: split.paragraphFrame,
            paragraphHeight: split.paragraphHeight,
            hyperlinkURL: hyperlinkURL(in: split.paragraph),
            paragraphId: split.paragraph.paraHeader.paraId,
            paraShape: index.paraShapeOrDefault(for: split.paragraph),
            reservedFootnoteHeight: split.reservedFootnoteHeight,
            beforeGap: split.beforeGap,
            cachedTrailingSpacing: split.cachedTrailingSpacing,
            splitPolicy: split.splitPolicy,
            fragmentFootnotes: split.fragmentFootnotes,
            fitSource: split.fitSource,
            onFragmentPlaced: {
                registerPageChromeForCurrentFragment(from: split.paragraph)
                appendInlineControlBlocksForCurrentFragment(from: split.paragraph)
            }
        )
        updateBandTrailingSpacing(for: split.paragraph)
    }

    /// 부분 채운 1단 쪽에서 문단을 줄 단위로 나눌 수 있는지 (#207). **각주**가 있는데 조각별
    /// 귀속을 못 하면(쪽별 번호 모드 2·마커 어긋남) 나누지 않는다 — 첫 조각의 각주가 마지막 조각
    /// 쪽에 실리고 뒤 조각의 참조 번호가 낡는다. 미주만 있는 문단은 나눈다 (PR 리뷰): 미주는 쪽이
    /// 아니라 문서·구역 끝에 모이고 번호도 쪽마다 되돌리지 않으므로 문단 단위 수집이면 충분하다.
    /// 저장본 줄 캐시 높이를 따르는 문단은 CT 줄 수가
    /// 캐시 줄 수와 같을 때만 나눈다 — 다르면 마지막 줄의 전진량이 캐시 잔여(1pt 하한)라 실제로
    /// 안 들어가는 줄까지 들어간다고 판정한다. 통째 이동은 종전 동작이라 격차가 늘지 않는다.
    ///
    /// 문단 단위로 마지막 조각 뒤에 나오는 것이 문단 머리에 묶여 있으면 나누지 않는다 — 자리
    /// 차지·글 앞뒤 개체는 `paragraphAnchorTop`(문단 상단) 기준인데 뒤 조각 쪽에서 방출되면 그
    /// 쪽 머리를 기준으로 그려지고, 자동 쪽 번호 필드는 조판 문자열에 진입 쪽 번호로 구워져
    /// 뒤 조각에 그대로 남는다 (PR 리뷰). 종전 통째 이동은 문단과 그것들을 같은 쪽에 두었다.
    private func canSplitAtEntry(_ split: FlowSplitInput, cacheHeightUsed: Bool) -> Bool {
        guard split.paragraphFrame.lines.count > 1,
              split.fragmentFootnotes != nil || !Self.hasFootnotes(split.paragraph),
              !hasParagraphBoundControls(split.paragraph)
        else { return false }
        return !cacheHeightUsed
            || split.paragraphFrame.lines.count
            == split.paragraph.paraLineSeg.paraLineSegInternalArray.count
    }

    /// 문단이 **각주**를 품는지 (직접 또는 컨테이너 안 — 미주 안 각주 포함) — 예약 높이 0을 "각주
    /// 없음"으로 읽으면 이월 각주가 분할 지점에서 멈춘 쪽(`reservationStopsAtSplit`)에서 각주 문단이
    /// 새는다 (PR 리뷰). 미주는 세지 않는다 — 쪽에 실리지 않고 번호도 쪽마다 되돌리지 않는다.
    static func hasFootnotes(_ paragraph: CoreHwp.HwpParagraph) -> Bool {
        (paragraph.ctrlHeaderArray ?? []).contains { ctrl in
            if case .footnote = ctrl {
                return true
            }
            return containsFootnotes(ctrl)
        }
    }

    /// 컨트롤이 품은 문단(셀·글상자·미주 문단·자식) 어딘가에 **각주**가 있는지 — `containsNotes`와
    /// 같은 순회에서 미주만 뺀 것.
    nonisolated static func containsFootnotes(_ ctrl: CoreHwp.HwpCtrlId, depth: Int = 0) -> Bool {
        guard depth < maximumContainerDepth else { return false }
        for (nested, _) in childParagraphSequence(of: ctrl) {
            for child in nested.ctrlHeaderArray ?? [] {
                if case .footnote = child {
                    return true
                }
                if containsFootnotes(child, depth: depth + 1) {
                    return true
                }
            }
        }
        return false
    }

    /// 문단 머리에 묶여 마지막 조각 뒤에 문단 단위로 나오는 컨트롤이 있는지 — 글자처럼 취급이
    /// 아닌 개체(자리 차지·글 앞뒤)와 자동 쪽 번호. 표는 글줄 앞에 **실제로 놓인** 것
    /// (`tablesPlacedBeforeText`, #190 — 자리 차지·문단 기준·오프셋 0 표)만 예외다: 글 앞뒤·
    /// 어울림·쪽 기준·오프셋 있는 표와 레이아웃에 실패한 표는 뒤에 문단 단위로 나온다 (PR 리뷰).
    private func hasParagraphBoundControls(_ paragraph: CoreHwp.HwpParagraph) -> Bool {
        (paragraph.ctrlHeaderArray ?? []).enumerated().contains { ordinal, ctrl in
            switch ctrl {
            case .table:
                !Self.isTreatAsChar(ctrl) && tablesPlacedBeforeText[ordinal] == nil
            case let .autoNumber(other):
                other.autoNumberInfo?.kind == .page
            case .genShapeObject, .shape, .line, .rectangle, .ellipse, .arc, .polygon, .curve,
                 .equation, .equationLegacy, .picture, .ole, .container:
                !Self.isTreatAsChar(ctrl)
            default:
                false
            }
        }
    }

    /// 흐름 분할 조각의 각주 귀속 문맥 (#207) — 조각을 놓을 때마다 그 조각의 컨트롤 서수
    /// 범위로 각주를 걷어 참조가 놓인 쪽에 싣고, 조각을 자르기 전엔 같은 범위의 예약을 줄마다
    /// 적합 판정에 더한다. 각주 참조가 없는 문단도 만든다 (걷을 것이 없어 무동작이고, 최종
    /// 조각의 컨테이너 걷기는 문단 단위 수집과 같다).
    ///
    /// nil이면 문단 전체 예약 + 문단 단위 수집(종전 동작)이다: 마커 ↔ 컨트롤 배열이 어긋난
    /// 문단, 그리고 쪽마다 각주 번호를 새로 시작하는 구역(표 134 numberingMode 2) — 조각 사이
    /// `cacheCurrentPage`가 카운터를 되돌려 뒤 조각의 참조 번호를 다시 매겨야 하는데(절대 캐시
    /// 경로의 `renumberedNoteMarkers`) 흐름 경로엔 그 기계가 없다.
    ///
    /// 다단 밴드도 만들지 않는다 (PR 리뷰): 각주 영역은 **쪽 폭** 하단이라 뒤 단 조각이 걷은 각주가
    /// 이미 끝까지 찬 앞 단의 아랫줄을 덮는다 — 밴드의 모든 단이 문단 전체 예약을 미리 빼는
    /// 종전 회계를 유지한다.
    private func flowFragmentFootnotes(
        for paragraph: CoreHwp.HwpParagraph,
        attributedString: NSAttributedString
    ) -> HwpFlowFragmentFootnotes? {
        guard columnFrames.count <= 1,
              currentSectionDef?.footNoteShape.numberingModeRawValue != 2
        else { return nil }
        return HwpFlowFragmentFootnotes(
            paragraph: paragraph,
            attributedString: attributedString,
            controlCount: paragraph.ctrlHeaderArray?.count ?? 0
        )
    }

    /// 부분 채운 1단 쪽에서 문단의 첫 조각이 남기는 줄 수 (#207) — 조각 루프
    /// (`appendParagraphAcrossColumns`)의 첫 반복과 같은 나머지·남은 자리·규칙·각주 예약으로
    /// 잰다. 0이면 문단을 통째로 다음 쪽에서 다시 처리한다.
    private func entryFragmentLineCount(_ split: FlowSplitInput) -> Int {
        let remainder = HwpFragmentRemainder(
            lines: split.paragraphFrame.lines,
            textHeight: split.paragraphHeight - split.beforeGap,
            measuredWidth: currentColumnFrame.width,
            heightIsMeasured: abs(split.paragraphHeight - split.paragraphFrame.totalHeight) < 0.01,
            fitSource: split.fitSource
        )
        let available = max(1, effectiveContentHeight - split.reservedFootnoteHeight)
            - (contentHeightUsed + split.beforeGap)
        return remainder.fit(
            in: available, policy: split.splitPolicy, columnIsEmpty: false,
            extra: {
                fragmentFootnoteReservation(through: $0, of: remainder, split.fragmentFootnotes)
            }
        ).count
    }

    /// 문단 전체를 한 번에 남길 때의 쪽 끝 적합 높이 (#222) — 문단 위 간격 + 첫 줄 상자 상단부터
    /// 가장 아래 줄 **상자 하단**까지. 줄 간격 여분과 문단 아래 간격은 넣지 않는다 (쪽 아래로
    /// 넘쳐도 된다). 문단 높이(`paragraphHeight`)와 **같은 출처**로 잰다 (#166의 높이 출처 원칙):
    /// 저장본 줄 캐시 높이를 쓴 문단의 마지막 줄은 캐시의 줄 상자 바닥(`vertsize`)으로, 그 밖의
    /// 줄과 측정 높이 문단은 CT 줄 프레임(`HwpFragmentLineAdvances.fitHeight`)으로. 줄이 없으면
    /// 캐시 상자 바닥, 그것도 없으면 문단 높이 전체다.
    private func paragraphFitHeight(_ split: FlowSplitInput) -> CGFloat {
        let lines = split.fitLines
        guard !lines.isEmpty else {
            return split.cachedLineBoxBottom.map { split.beforeGap + $0 } ?? split.paragraphHeight
        }
        // 캐시 높이를 쓰는데 CT 줄 수가 캐시 줄 수와 다르면 캐시의 줄 상자만 본다 (#222 리뷰) — 앞
        // 줄들의 CT 상자는 캐시 높이로 놓는 블록과 좌표계가 달라, 섞으면 캐시로는 들어가는 문단을
        // 종전(캐시 전진량)보다도 엄격하게 넘긴다. 진입 분할도 이때는 하지 않는다(`canSplitAtEntry`).
        if let cached = split.cachedLineBoxBottom,
           lines.count != split.paragraph.paraLineSeg.paraLineSegInternalArray.count
        {
            return split.beforeGap + cached
        }
        // 조각 루프(`HwpFragmentRemainder.fit`)와 **같은 함수**로 잰다 — 문단 전체가 들어간다는
        // 판정과 루프가 모든 줄을 남긴다는 판정이 같아야 한다. 줄 수가 같으면 캐시 높이 문단도 앞
        // 줄들은 CT 상자로 잰다: 렌더러는 캐시 높이 블록 안에서도 줄을 CT 전진량으로 그리므로
        // (`HwpDrawnTextLayout.lines`), CT 줄 상자가 캐시보다 큰 문단(MS 워드 호환 문서의 글꼴 대체,
        // 글자보다 낮은 낡은 캐시)을 캐시 바닥만으로 통째로 두면 그 뒤 줄이 본문 아래·쪽 밖에
        // 그려진다 (#222 PR 리뷰 — 캐시 바닥만 쓰자는 제안을 이 이유로 두지 않았다). 고정 줄 간격이 상자보다 작은 줄은
        // 상자가 전진량보다 커서 이 값이 문단 높이를 넘을 수 있다 — 한글도 그 상자로 판정한다
        // (남은 9pt에 상자 10·전진량 8인 줄을 넘긴다).
        let advances = HwpFragmentLineAdvances(
            lines: lines, textHeight: split.paragraphHeight - split.beforeGap,
            cachedLastLineBoxBottom: split.cachedLineBoxBottom
        )
        return split.beforeGap + advances.fitHeight(from: 0, through: lines.count - 1)
    }

    /// 빈 문단의 줄 프레임 — 페이지네이터의 `layout`은 빈 문단 앵커(#145)의 줄 프레임을 비우므로
    /// (높이만 남긴다) 쪽 끝 적합에 쓸 줄 상자를 한 번 더 조판해 얻는다 (#222). 빈 줄도 한글은
    /// 상자로 판정한다 — 쪽 끝의 빈 문단은 흔하다. 앵커가 아니면(줄이 정말 없는 문단) 빈 배열.
    private func emptyParagraphLines(
        _ paragraph: CoreHwp.HwpParagraph, attributedString: NSAttributedString
    ) -> [HwpLineFrame] {
        guard HwpTextRunBuilder.isEmptyParagraphAnchor(attributedString) else { return [] }
        return HwpParagraphLayout().layout(
            attributedString: attributedString,
            paraShape: index.paraShapeOrDefault(for: paragraph),
            columnWidth: currentColumnFrame.width
        ).lines
    }

    /// 방금 놓은 흐름 텍스트 블록의 마지막 줄 상자 아래 몫을 기록한다 (#222) — 블록 높이
    /// (전진량 합)와 그 블록 줄들의 적합 높이(상자 하단)의 차. 쪽 끝 적합이 줄 상자까지라
    /// 이 몫은 본문 하단을 넘을 수 있고, 각주 이어짐의 본문 하한(`footnoteBodyBottom`)은
    /// 절대 캐시 run 블록과 같이 상자 아래에서 잰다 — 안 빼면 적합 판정이 "줄과 각주가 함께
    /// 들어간다"고 본 쪽에서 각주 자리가 여분만큼 줄어 각주가 나뉘거나 밀린다. 고정 줄 간격이
    /// 상자보다 작아 상자가 블록 아래로 나가면 **음수**다 (#222 PR 리뷰) — 쓰는 쪽(단 구분선·
    /// 각주 이어짐의 본문 하한·변경 막대)이 그 상자 바닥까지 잰다. 한글 12.30 실측(so222n DG):
    /// 12pt·고정 8pt 줄이 단 끝이면 구분선이 전진량 끝이 아니라 상자 바닥에서 끝난다.
    private func recordFlowTrailingSpace(blockHeight: CGFloat, fitHeight: CGFloat) {
        guard !currentBlocks.isEmpty else { return }
        trailingSpacesBelowLineBox[currentBlocks.count - 1] = blockHeight - fitHeight
    }

    /// 나머지의 줄 `lineIndex`까지 놓을 조각이 걷을 각주의 예약 높이 (#207) — 귀속 문맥이
    /// 없으면 0 (그때는 문단 전체 예약이 `reservedFootnoteHeight`로 든다).
    ///
    /// 비최종 조각은 **증분**으로 잰다 (PR 리뷰 2): 후보 줄마다 범위가 `0..<1`, `0..<2`처럼 늘 때
    /// 앞 서수를 다시 훑으면 마커 줄 N개에 N(N+1)/2 순회다 — 커서(`reservationCursor`)가 앞 후보의
    /// 누적 예약·번호 상태를 들고 새로 든 서수만 더한다. 최종 조각은 범위 밖 컨테이너까지 재는
    /// 다른 술어라 한 번 통째로 잰다(메모).
    private func fragmentFootnoteReservation(
        through lineIndex: Int,
        of remainder: HwpFragmentRemainder,
        _ fragmentFootnotes: HwpFlowFragmentFootnotes?
    ) -> CGFloat {
        guard let fragmentFootnotes else { return 0 }
        let ordinals = fragmentFootnotes.ordinals(through: lineIndex, of: remainder)
        let isLast = lineIndex >= remainder.lines.count - 1
        guard isLast else {
            var cursor = fragmentFootnotes.reservationCursor
                ?? footnoteCoordinator.fragmentReservationCursor(from: ordinals.lowerBound)
            if cursor.upperBound > ordinals.upperBound {
                cursor = footnoteCoordinator.fragmentReservationCursor(from: ordinals.lowerBound)
            }
            let total = footnoteCoordinator.extendFragmentReservation(
                &cursor,
                for: fragmentFootnotes.paragraph,
                through: ordinals.upperBound,
                environment: noteEnvironment,
                childParagraphs: Self.childParagraphs(of:),
                numbering: currentParagraphScope
            )
            fragmentFootnotes.reservationCursor = cursor
            return total
        }
        return fragmentFootnotes.reservation(for: ordinals, isLast: true) {
            footnoteCoordinator.anticipatedFootnoteHeight(
                for: fragmentFootnotes.paragraph,
                environment: noteEnvironment,
                childParagraphs: Self.childParagraphs(of:),
                numbering: currentParagraphScope,
                ordinals: ordinals,
                collectsNested: true
            )
        }
    }

    /// 방금 놓은 흐름 조각(나머지의 줄 `lineIndex`까지)의 각주를 이 쪽에 걷는다 (#207) — 곧
    /// 이어지는 `advanceColumn`(1단이면 `cacheCurrentPage`)이 그 쪽에 싣는다. 마지막 조각은
    /// 서수 범위 밖 컨테이너의 각주까지 걷는다 (`collectFootnotes`의 `collectsNested`).
    private func collectFlowFragmentFootnotes(
        through lineIndex: Int,
        of remainder: HwpFragmentRemainder,
        _ fragmentFootnotes: HwpFlowFragmentFootnotes?
    ) {
        guard let fragmentFootnotes else { return }
        let ordinals = fragmentFootnotes.ordinals(through: lineIndex, of: remainder)
        collectFragmentFootnotes(
            from: fragmentFootnotes.paragraph,
            ordinals: ordinals,
            collectsNested: lineIndex >= remainder.lines.count - 1
        )
        fragmentFootnotes.markCollected(ordinals)
        collectedFootnotesDuringPlacement = true
    }

    /// 밴드 마지막 줄의 줄 간격을 기록한다 (단 정의 밴드 마감 시 다음 밴드
    /// 시작 여백으로 사용). 산식은 band.updateTrailingSpacing.
    private func updateBandTrailingSpacing(for paragraph: CoreHwp.HwpParagraph) {
        band.updateTrailingSpacing(for: paragraph)
    }

    /// 한글 라인 캐시의 단별 run을 단 프레임에 그대로 배분한다 (밴드가 비어 있고
    /// 캐시가 단 경계 (loc 리셋 후 0에서 재시작)를 담고 있을 때만).
    /// 단 경계의 스트림 위치 환산·라인 스냅은
    /// HwpAbsoluteCachePlacer.columnRunBoundaries.
    /// 절대 캐시 모드에서는 loc 리셋이 페이지 절단점이므로 이 경로를 쓰지 않는다.
    private func placeCachedColumnRuns(
        _ paragraph: CoreHwp.HwpParagraph,
        attributedString: NSAttributedString,
        paragraphFrame: HwpParagraphFrame
    ) -> Bool {
        let rawTotal = paragraph.paraHeader.charCount
        guard !absoluteCacheMode,
              columnIndex == 0,
              contentHeightUsed == 0,
              rawTotal > 0,
              attributedString.length > 0,
              let runs = HwpAbsoluteCachePlacer.cacheRuns(for: paragraph),
              runs.count > 1,
              runs.count <= columnFrames.count,
              runs.allSatisfy({ $0.first?.lineLocation == 0 }),
              // 글자처럼 취급 표를 실은 줄이 그 표보다 낮은 캐시는 단 배분도 낡았다 (#214 PR
              // 리뷰) — run 높이를 믿으면 뒤 문단이 표를 덮으므로 줄 단위 배분으로 떨어진다.
              !HwpParagraphLayout.lineCacheIsStale(
                  paragraph,
                  inlineTableHeights: columnRunInlineTableHeights(for: paragraph, runs: runs)
              )
        else { return false }

        guard let boundaries = HwpAbsoluteCachePlacer.columnRunBoundaries(
            runs: runs,
            rawTotal: rawTotal,
            attributedLength: attributedString.length,
            lines: paragraphFrame.lines,
            // 생성 라벨(#154)은 WCHAR 스트림에 없으므로 본문만 비례 환산한다.
            prefixLength: HwpTextRunBuilder.numberingLabelLength(of: attributedString)
        ) else { return false }

        // 문단은 첫 단 폭으로 재어졌다 (`columnIndex == 0` 가드) — 뒤 단이 그보다
        // 넓거나 좁으면 조각을 그 단 기하로 다시 푼다.
        let measuredWidth = columnFrames.first?.width ?? currentColumnFrame.width
        for (runIndex, run) in runs.enumerated() {
            guard let firstSegment = run.first else { return false }
            var runBottom = Int(firstSegment.lineLocation)
            for segment in run {
                runBottom = max(runBottom, HwpAbsoluteCachePlacer.lineBottom(of: segment))
            }
            let start = boundaries[runIndex]
            let length = max(0, boundaries[runIndex + 1] - start)
            guard length > 0 else { continue }
            let range = NSRange(location: start, length: length)
            columnIndex = runIndex
            contentHeightUsed = 0
            paragraphAnchorTop = currentColumnFrame.minY
            // 둘째 단부터는 이어지는 조각이라 첫 줄 들여쓰기를 둘째 줄에 맞춘다.
            let fragment = HwpParagraphLayout.continuationFragment(
                of: attributedString, range: range
            )
            // 이 단에 놓이는 줄 (경계는 CT 줄 시작에 스냅돼 있다) — 조각 기준으로
            // 되돌려 줄 앵커 문맥으로 쓴다 (#164). 줄은 첫 단 폭으로 측정됐으므로 단 폭이
            // 다르면(비등폭 단, Column 픽스처) 목적 단 폭으로 다시 조판한 줄을 쓴다.
            let runLines = paragraphFrame.lines.filter {
                NSLocationInRange($0.attributedRange.location, range)
            }
            // 단 구분선 바닥이 뺄 이 run 마지막 줄의 줄 간격 — 정상 다단 캐시는 단 경계에서
            // `lineLocation`이 0으로 돌아가 문단 캐시 검사에 걸리므로 조각에 직접 싣는다 (#191).
            let runSpacing = run.last.map { CGFloat(HwpUnits.points(fromHwpUnit: $0.lineSpacing)) }
            var marked = runIndex < runs.count - 1
                ? HwpTableSplitter.markedAsContinuedFragment(fragment) : fragment
            // 줄 간격이 음수(고정 줄 간격 < 상자)면 블록 높이(`lineBottom` — 음수 간격을 0으로 잡는다)가
            // 이미 상자 바닥까지라 뺄 몫은 0이다 (#222 PR 리뷰) — 표식이 없으면 측정 규칙(음수)이
            // 구분선을 상자 아래로 더 내린다.
            if let runSpacing {
                marked = HwpTableSplitter.marked(
                    marked, cachedTrailingLineSpacing: max(0, runSpacing)
                )
            }
            let fragmentText = placedFragment(marked, reservedWidth: measuredWidth)
            appendBlock(
                height: max(1, HwpUnits.points(
                    fromHwpUnit: Int32(clamping: runBottom - Int(firstSegment.lineLocation))
                )),
                attributedString: fragmentText,
                hyperlinkURL: hyperlinkURL(in: paragraph),
                paragraphId: paragraph.paraHeader.paraId,
                heightIsMeasured: false,
                anchorLines: fragmentAnchorLines(
                    runLines[...], range: range, fragment: fragmentText,
                    paraShape: index.paraShapeOrDefault(for: paragraph),
                    measuredWidth: measuredWidth
                )
            )
            // 앞 단의 줄에 앵커가 있는 글자처럼 취급 개체는 그 단에 지금 놓는다 (#164) —
            // 마지막 단의 문맥만 남으면 앞 단의 개체가 앵커를 잃고 흐름 위치로 간다. 앞 단
            // 조각의 쪽 장식도 지금 등록한다 (#207 PR 리뷰).
            if runIndex < runs.count - 1 {
                registerPageChromeForCurrentFragment(from: paragraph)
                appendInlineControlBlocksForCurrentFragment(from: paragraph)
            }
        }
        updateBandTrailingSpacing(for: paragraph)
        return true
    }

    /// 절대 캐시 문단 배치: run들을 한글이 계산한 y에 그대로 놓고,
    /// 쪽 중간에 새로 열린 단 밴드의 캐시 문단이 남은 본문에 안 들어가는가 (#214 리뷰) — 한글은
    /// 밴드마다 줄 위치를 밴드 상단부터 다시 세므로 앞 밴드의 줄과 견주는 쪽 절단점 판정은 쓸 수
    /// 없다(종전에는 앞 밴드 마지막 줄 위치보다 작다고 쪽을 넘겨 `Column` 꼴 한 쪽 문서가 두 쪽이
    /// 됐다). 대신 **자리**로 판정한다: 첫 run은 한글이 한 쪽에 놓은 줄들이므로, 그 줄 **상자**(줄
    /// 간격 제외) 가운데 하나라도 캐시가 준 자리에서 본문(각주 예약 제외) 아래를 넘으면 한글은 그
    /// 문단을 다음 쪽에 놓았다 — 쪽을 채운 문단 뒤의 단 정의 문단, 첫 줄은 들어가도 문단 보호·외톨이줄
    /// 보호로 통째로 옮긴 문단(#207)이 그렇다. 밴드의 문단마다 쪽이 넘어갈 때까지 본다 — 옮겨진 문단
    /// 뒤의 문단들도 위치가 늘기만 해서 위치로는 절단점이 안 보인다.
    private func bandStartOverflows(_ run: [CoreHwp.HwpParaLineSegInternal]) -> Bool {
        guard absoluteCacheBandRestarted else { return false }
        let usableBottom = currentPageGeometry.contentFrame.maxY - footnoteReservedHeight
        let runBottom = run.reduce(Int.min) {
            max($0, Int($1.lineLocation) + Int(max(0, $1.lineHeight)))
        }
        let bottom = currentColumnFrame.minY + absoluteCacheStaleOffset
            + HwpUnits.points(fromHwpUnit: Int32(clamping: max(0, runBottom)))
        return bottom > usableBottom + 0.01
    }

    /// 낡은 캐시 보정(`staleAdjustedHeight`)이 걸린 쪽에서 이 문단의 첫 run이 보정된 자리에서
    /// 본문(각주 예약 제외) 아래를 넘는가 (#214 PR 리뷰). 캐시의 쪽 절단점은 보정 **전** 자리로
    /// 정해졌으므로 절단점만 따르면, 표가 크게 커진 문서에서 밀린 뒤 문단이 종이 밖으로 나가
    /// 사라진다. 한글은 넘는 문단을 다음 쪽 머리에 놓는다 — 한글 12.30 실측(2026-09-23): 앞 표가
    /// 51.28 → 563.28pt로 커진 문서의 뒤 표 문단은 2쪽 머리(줄 위치 0)에, 제 표가 627.28pt로 커져
    /// 남은 자리에 안 들어가는 문단은 2쪽 머리에 통째로 놓이고 그 뒤 문단은 3쪽 머리다. 자리는 줄
    /// **상자**로 잰다(줄 간격 제외, `bandStartOverflows`와 같다) — 문단 자신이 보정되면 CT 줄 상자다.
    private func staleShiftOverflows(
        _ paragraph: CoreHwp.HwpParagraph,
        attributedString: NSAttributedString,
        frame: HwpParagraphFrame,
        runs: [[CoreHwp.HwpParaLineSegInternal]]
    ) -> Bool {
        let firstLoc = runs[0][0].lineLocation
        let grows = staleLineExtent(
            paragraph, runs: runs, slice: attributedString, frame: frame,
            cachedHeight: absoluteRunBlockHeight(run: runs[0], firstLocation: firstLoc)
        ) != nil
        guard absoluteCacheStaleOffset != 0 || grows else { return false }
        let boxes: CGFloat = if grows {
            frame.lines.map { $0.origin.y + $0.boxHeight }.max() ?? frame.totalHeight
        } else {
            HwpUnits.points(fromHwpUnit: Int32(clamping: runs[0].reduce(Int.min) {
                max($0, Int($1.lineLocation) + Int(max(0, $1.lineHeight)))
            } - Int(firstLoc)))
        }
        let top = currentColumnFrame.minY + absoluteCacheStaleOffset
            + max(0, HwpUnits.points(fromHwpUnit: firstLoc))
        let usableBottom = currentPageGeometry.contentFrame.maxY - footnoteReservedHeight
        return top + boxes > usableBottom + 0.01
    }

    /// `staleShiftOverflows`로 쪽을 넘긴 문단을 새 쪽 머리에 놓는다 — 그 문단의 캐시 위치는 옛 쪽
    /// 기준이므로 이 쪽의 보정을 그 위치만큼 당긴다. 같은 쪽의 뒤 캐시 문단은 같은 보정으로 캐시 간격을
    /// 그대로 잇고, 캐시의 다음 쪽 절단점에서 보정이 풀린다. 다른 문단이 먼저 오면 버린다.
    private func applyPendingAbsoluteCacheRebase(at firstLoc: Int32) {
        guard let pending = absoluteCachePlacer.pendingRebaseLocation else { return }
        absoluteCachePlacer.pendingRebaseLocation = nil
        guard pending == firstLoc else { return }
        absoluteCacheStaleOffset = -max(0, HwpUnits.points(fromHwpUnit: firstLoc))
    }

    /// run 사이 (loc 리셋)마다 페이지를 확정한다. 문단 첫 줄이 현재 페이지의 마지막 줄 뒤의
    /// 한글 쪽 절단점이면 (`HwpAbsoluteCachePlacer.isPageBreak` — loc이 줄거나, 자리를 차지한 줄
    /// 뒤의 같은 loc, #214) 한글이 이 문단을 새 페이지에서 시작한 것이므로 페이지를 확정하고
    /// false를 반환한다 (호출자가 재처리). 쪽 중간에 열린 단 밴드의 첫 캐시 문단은 loc을 밴드
    /// 상단부터 다시 세므로 자리로 판정한다 (`bandStartOverflows`). 낡은 캐시 보정으로 밀린 문단이
    /// 쪽 아래를 넘어도 쪽을 넘기고, 새 쪽 머리에 놓는다 (`staleShiftOverflows`, #214 PR 리뷰).
    private func placeAbsoluteCachedParagraph(
        _ paragraph: CoreHwp.HwpParagraph,
        attributedString: NSAttributedString,
        paragraphFrame: HwpParagraphFrame,
        runs: [[CoreHwp.HwpParaLineSegInternal]]
    ) -> Bool {
        let firstLoc = runs[0][0].lineLocation
        applyPendingAbsoluteCacheRebase(at: firstLoc)
        if !currentBlocks.isEmpty || contentHeightUsed > 0 {
            let cachedBreak = HwpAbsoluteCachePlacer.isPageBreak(
                at: firstLoc, after: lastAbsoluteCacheLoc, previousAdvance: lastAbsoluteCacheAdvance
            ) || bandStartOverflows(runs[0])
            let shiftedOut = !cachedBreak && staleShiftOverflows(
                paragraph, attributedString: attributedString, frame: paragraphFrame, runs: runs
            )
            if cachedBreak || shiftedOut {
                closeColumnBand()
                cacheCurrentPage()
                if shiftedOut {
                    absoluteCachePlacer.pendingRebaseLocation = firstLoc
                }
                return false
            }
        }
        // 이 문단은 캐시 y로 배치된다 — 자리 차지 표의 띠 판정이 이 사실을 요구한다 (#161).
        paragraphEntryFlow?.placedFromCache = true

        // 페이지에 걸친 문단의 각주는 참조가 놓인 **조각의 페이지**에 실린다
        // (#95). 조각을 먼저 다 자른 뒤 그 조각에 실제로 그려진 마커 서수로
        // 범위를 나눈다 — 배치와 귀속이 같은 경계를 쓴다. run마다 수집하면 다음
        // 반복 머리의 cacheCurrentPage가 그 페이지를 확정하며 각주를 배치한다.
        // 경계를 못 믿으면 (서수 불일치) nil이라 호출자가 문단 전체를 마지막
        // 조각 페이지에 귀속시키는 기존 동작으로 폴백한다.
        // 캐시(한글의 절단점)가 더 앞 조각이라 하면 그쪽을 따른다 (#165) — 늦은 귀속은
        // 각주 이어짐과 만나 뒤 쪽으로 연쇄한다 (`earliestOrdinalRanges`).
        let slices = absoluteRunSlices(
            runs: runs,
            attributedString: attributedString,
            lines: paragraphFrame.lines
        )
        let controlCount = paragraph.ctrlHeaderArray?.count ?? 0
        let ordinalRanges = HwpAbsoluteCachePlacer.earliestOrdinalRanges(
            HwpAbsoluteCachePlacer.controlOrdinalRanges(
                slices: slices.map(\.text), controlCount: controlCount
            ),
            HwpAbsoluteCachePlacer.cachedControlOrdinalRanges(
                runs: runs, paragraph: paragraph, controlCount: controlCount
            )
        )
        // 조각에 걸쳐 그려진 마커는 조각마다 **일부**만 갖는다 — 그 일부를 완전한
        // 번호로 바꾸면 다음 쪽에 남은 나머지와 합쳐 깨진다 (번호가 그대로여도).
        let splitMarkers = HwpAbsoluteCachePlacer.ordinalsSpanningSlices(slices.map(\.text))
        // 앞 조각이 가져간 각주의 참조 마커는 **뒤 조각에** 그려질 수 있다 (#165의 캐시
        // 귀속) — 그 조각의 재매김 범위에는 없으므로, 수집이 확정한 번호를 들고 가
        // 실제로 그 마커가 나오는 조각에서 적용한다 (아래 `renumberedNoteMarkers`).
        var carriedNoteNumbers: [Int: HwpControlMarkerReplacement] = [:]
        for (runIndex, run) in runs.enumerated() {
            if runIndex > 0 {
                cacheCurrentPage()
            }
            guard let runFirstSegment = run.first else { continue }
            let runFirst = runFirstSegment.lineLocation
            var height = absoluteRunBlockHeight(run: run, firstLocation: runFirst)
            let slice = slices[runIndex]
            let sliceText = renumberedNoteMarkers(
                in: slice.text,
                paragraph: paragraph,
                ordinals: ordinalRanges?[runIndex],
                skipping: splitMarkers,
                carrying: &carriedNoteNumbers
            )
            // appendBlock은 columnFrame.minY + contentHeightUsed에 배치하므로
            // 한글이 준 절대 y (+ stale 캐시 보정)로 커서를 옮긴다.
            contentHeightUsed = max(0, HwpUnits.points(fromHwpUnit: runFirst))
                + absoluteCacheStaleOffset
            let cachedHeight = height
            height = staleAdjustedHeight(
                height, paragraph: paragraph, runs: runs, slice: sliceText, frame: paragraphFrame
            )
            paragraphAnchorTop = currentColumnFrame.minY + contentHeightUsed
            // 여러 run이면 `slice.lines`는 조각 기준 줄이라 앵커 문맥으로만 쓴다.
            appendBlock(
                height: height,
                attributedString: sliceText,
                hyperlinkURL: hyperlinkURL(in: paragraph),
                paragraphId: paragraph.paraHeader.paraId,
                lines: runs.count == 1 ? slice.lines : [],
                heightIsMeasured: false,
                anchorLines: runs.count == 1 ? [] : renumberedAnchorLines(
                    of: slice.text, lines: slice.lines,
                    renumbered: sliceText, paragraph: paragraph
                )
            )
            recordAbsoluteRunTrailingSpacing(
                run: run, firstLocation: runFirst, blockHeight: height,
                isStaleAdjusted: height != cachedHeight
            )
            lastAbsoluteCacheLoc = run.last?.lineLocation ?? runFirst
            lastAbsoluteCacheAdvance = run.last.map(HwpAbsoluteCachePlacer.signedAdvance(of:)) ?? 0
            collectFragmentFootnotes(
                from: paragraph,
                ordinals: ordinalRanges?[runIndex],
                collectsNested: runIndex == runs.count - 1
            )
            // 앞 조각의 줄에 앵커가 있는 글자처럼 취급 개체는 이 쪽이 확정되기 전에
            // 놓는다 (#164). 앞 조각의 쪽 장식도 이 쪽이 확정되기 전에 등록한다 (#207 PR
            // 리뷰). 마지막 조각은 종전대로 문단 단위 방출이 맡는다.
            if runIndex < runs.count - 1 {
                registerPageChromeForCurrentFragment(from: paragraph)
                appendInlineControlBlocksForCurrentFragment(from: paragraph)
            }
        }
        collectedFootnotesDuringPlacement = ordinalRanges != nil
        return true
    }

    /// 문단 단위 각주 수집 — 배치가 조각마다 이미 담았으면 건너뛴다 (#95).
    /// 건너뛰지 않으면 같은 각주가 두 번 세어져 번호와 개수가 어긋난다.
    private func collectParagraphFootnotesUnlessPlacedPerFragment(
        _ paragraph: CoreHwp.HwpParagraph
    ) {
        guard !collectedFootnotesDuringPlacement else { return }
        collectFootnotes(from: paragraph, includeTableCells: false)
    }

    /// 이 페이지 조각에 실린 각주만 지금 페이지에 담는다 (#95).
    ///
    /// 다음 run 머리의 `cacheCurrentPage`가 이 페이지를 확정하며 방금 담은 각주를
    /// 배치한다 — 그 사이에 예약(`footnoteReservedHeight`)을 읽는 코드가 없어
    /// 본문 절단점이 흔들리지 않는다. `ordinals`가 nil이면 조각 경계를 못 믿는
    /// 문단이라 아무것도 하지 않고, 호출자가 문단 단위로 수집한다 (기존 동작).
    /// 표 셀 각주 제외는 문단 단위 수집과 같은 필터다 (행 페이지 귀속).
    private func collectFragmentFootnotes(
        from paragraph: CoreHwp.HwpParagraph,
        ordinals: Range<Int>?,
        collectsNested: Bool
    ) {
        guard let ordinals else { return }
        collectFootnotes(
            from: paragraph,
            includeTableCells: false,
            ordinals: ordinals,
            collectsNested: collectsNested
        )
    }

    /// run별 텍스트 조각 — 배치 **전에** 한 번에 자른다 (#95). 각주 귀속이 이
    /// 조각들을 근거로 나뉘므로 (`controlOrdinalRanges`) 자르는 곳이 한 군데여야
    /// 배치와 귀속이 갈리지 않는다.
    private func absoluteRunSlices(
        runs: [[CoreHwp.HwpParaLineSegInternal]],
        attributedString: NSAttributedString,
        lines: [HwpLineFrame]
    ) -> [(text: NSAttributedString, lines: [HwpLineFrame])] {
        let totalSegments = runs.reduce(0) { $0 + $1.count }
        var slices: [(text: NSAttributedString, lines: [HwpLineFrame])] = []
        slices.reserveCapacity(runs.count)
        var lineCursor = 0
        for (runIndex, run) in runs.enumerated() {
            slices.append(HwpAbsoluteCachePlacer.runAttributedSlice(
                runIndex: runIndex,
                runShare: HwpAbsoluteCachePlacer.RunShare(
                    segments: run.count,
                    total: totalSegments,
                    runCount: runs.count
                ),
                attributedString: attributedString,
                lines: lines,
                lineCursor: &lineCursor
            ))
        }
        return slices
    }

    /// 재매김된 조각의 앵커 줄 (PR 리뷰). `slice.lines`는 번호를 다시 쓰기 **전** 문자열로
    /// 잰 것이라, 번호 폭이 바뀌면 (10) → 9)) 그 마커 **뒤**의 글자처럼 취급 개체가 옛 x·
    /// 옛 줄에 남는다 — 편집이 있었으면 재매김된 문자열을 같은 단 폭으로 다시 조판해
    /// 앵커를 뽑는다 (비등폭 단 이월의 `fragmentAnchorLines`와 같은 처방).
    ///
    /// 술어가 **인스턴스 동일성**인 것은 우연이 아니라 계약이다 —
    /// `HwpTextRunBuilder.renumberingNoteMarkers`는 바꿀 것이 없으면 입력을 그대로
    /// 돌려준다. 번호가 이어지는 문서(코퍼스 전부)에서는 이 갈래가 발동하지 않아
    /// 렌더가 불변이고 조판 비용도 0이다.
    ///
    /// 재조판은 조각을 **홀로** 재므로 중간 조각의 첫 줄에도 첫 줄 들여쓰기가 걸리는
    /// 근사를 안는다 — 옛 번호로 잰 줄(확실히 어긋난다)과의 교환이라 순 개선이다.
    private func renumberedAnchorLines(
        of original: NSAttributedString,
        lines: [HwpLineFrame],
        renumbered: NSAttributedString,
        paragraph: CoreHwp.HwpParagraph
    ) -> [HwpLineFrame] {
        guard renumbered !== original else { return lines }
        return HwpParagraphLayout().layout(
            attributedString: renumbered,
            paraShape: index.paraShapeOrDefault(for: paragraph),
            columnWidth: currentColumnFrame.width
        ).lines
    }

    /// 조각의 각주/미주 참조 마커를 **그 조각이 실릴 페이지의 번호**로 다시 쓴다.
    ///
    /// 마커 번호는 조판 전에 문단 단위로 한 번 구워지는데, "쪽마다 새로 시작"
    /// (표 134 numberingMode 2) 구역에서 문단이 페이지에 걸치면 run 사이
    /// `cacheCurrentPage`가 카운터를 리셋해 뒤 조각의 마커가 수집 번호와 어긋난다
    /// (참조는 2), 각주는 1)). 배치 직전 현재 카운터로 다시 계산하면 둘이 같은
    /// 번호를 쓴다 — 수집은 이 뒤에 오므로 카운터는 앞 조각 몫까지만 반영돼 있다.
    /// 번호가 그대로면 (연속 번호 문서 전부) 원본을 그대로 돌려줘 렌더가 불변이다.
    /// 쪽 번호 필드 (atno kind 0)는 대상이 아니다 — 같은 낡음이 있지만 코퍼스
    /// 실측 없이 바꾸면 렌더가 조용히 달라진다.
    ///
    /// **남는 근사**: 조판 (`paragraphFrame`) 과 슬라이스는 옛 번호로 이미 끝난
    /// 뒤라, 번호 폭이 바뀌면 (9) → 10)) 그 조각 **안**의 줄바꿈이 조판 당시와
    /// 달라질 수 있다 — 조각의 **높이**(캐시 몫)와 **소속**(문자 범위로 고정)이
    /// 그 축이다. 텍스트가 다른 쪽으로 새지는 않는다. 근본 해결은 순환이다 —
    /// 번호는 실릴 쪽이 정해져야 알 수 있고, 그 쪽은 배치가, 배치는 조판이 끝나야
    /// 안다. 고정점 반복을 새로 들이는 값이 모드 2 문서 (코퍼스 0건) 하나에 비해 크다.
    ///
    /// **개체 앵커 축만은 닫혀 있다** (PR 리뷰): 편집이 있으면 배치가 재매김된 조각을
    /// 다시 조판해 앵커를 뽑으므로 (`renumberedAnchorLines`) 마커 뒤 개체가 옛 x·옛
    /// 줄에 남지 않는다. 여기는 순환이 아니다 — 번호는 이 시점에 이미 정해져 있다.
    /// 가드: `testRenumberingKeepsMarkerAndNoteInSyncWhenWidthChanges` (번호 정합),
    /// `HwpFootnoteRenumberAnchorTests` (앵커 정합).
    /// `carrying`: 앞 조각들에서 확정한 각주 번호 (#165 리뷰). 조각 귀속이 캐시를 따라
    /// 마커보다 **앞선** 조각으로 갈 수 있으므로 (`earliestOrdinalRanges`), 이 조각의
    /// 서수 범위만 보면 뒤에 그려진 마커가 문단 조판 때 구워진 옛 번호로 남는다 — 쪽마다
    /// 번호를 새로 시작하는 문서 (표 134 모드 2) 에서 참조와 각주가 어긋난다. 범위에서
    /// 계산한 번호를 여기 쌓아 두고, 그 마커가 실제로 나오는 조각에서 적용한다.
    /// 마커는 조각 하나에만 있으므로 (걸친 서수는 `splitMarkers`가 뺀다) 누적해도
    /// 같은 마커가 두 번 바뀌지 않는다.
    private func renumberedNoteMarkers(
        in slice: NSAttributedString,
        paragraph: CoreHwp.HwpParagraph,
        ordinals: Range<Int>?,
        skipping splitMarkers: Set<Int>,
        carrying carried: inout [Int: HwpControlMarkerReplacement]
    ) -> NSAttributedString {
        guard let ctrls = paragraph.ctrlHeaderArray else { return slice }
        if let ordinals, !ordinals.isEmpty {
            // 자동 쪽 번호는 쌓지 않는다 — 쪽마다 값이 달라 뒤 조각에 나르면 옛 쪽 번호가
            // 그려진다. 각주·미주 참조만 남긴다.
            carried.merge(
                noteReferenceReplacements(for: paragraph, ordinals: ordinals)
                    .filter { ordinal, _ in
                        guard !splitMarkers.contains(ordinal),
                              ctrls.indices.contains(ordinal) else { return false }
                        return switch ctrls[ordinal] {
                        case .footnote, .endnote: true
                        default: false
                        }
                    }
            ) { _, fresh in fresh }
        }
        guard !carried.isEmpty else { return slice }
        return HwpTextRunBuilder.renumberingNoteMarkers(in: slice, replacements: carried)
    }

    /// 낡은 캐시 보정된 run 높이 — 캐시가 현재 내용과 안 맞는 문단(캐시 줄 높이 < 선언 글자 크기,
    /// 또는 글자처럼 취급 표를 실은 줄 < 그 표)은 블록을 CT **줄 범위**로 키우고 이후 문단을 그만큼
    /// 민다 (`absoluteCacheStaleOffset`). 높이·판정은 `staleLineExtent`가 정한다.
    private func staleAdjustedHeight(
        _ height: CGFloat,
        paragraph: CoreHwp.HwpParagraph,
        runs: [[CoreHwp.HwpParaLineSegInternal]],
        slice: NSAttributedString,
        frame: HwpParagraphFrame
    ) -> CGFloat {
        guard let lineExtent = staleLineExtent(
            paragraph, runs: runs, slice: slice, frame: frame, cachedHeight: height
        ) else { return height }
        absoluteCacheStaleOffset += lineExtent - height
        return lineExtent
    }

    /// 낡은 캐시 보정이 이 문단에 쓸 블록 높이 — 대상이 아니거나 커지지 않으면 nil.
    ///
    /// 한글.app도 캐시가 내용과 안 맞는 문단은 열 때 재조판한다. 글자 크기 쪽은 CharShape 실물,
    /// 표 쪽은 #214 PR 리뷰의 한글 12.30 실측이다 (`HwpParagraphLayout.lineCacheIsStale`: 줄 예약이
    /// 표의 그려지는 높이라 셀 내용이 저장 뒤에 표를 키운 문서는 캐시 줄보다 CT 줄이 크다 — 표 51.28
    /// → 371.28pt, 호스트 캐시 56.94pt에서 한글은 표 줄을 376.94pt로 키우고 뒤 문단을 320pt 내렸다).
    /// 캐시 줄 높이가 글자 크기 이상이라도 표 쪽 판정은 걸린다. 여러 run으로 나뉜 문단은 대상이
    /// 아니다 — 조각마다 CT 높이를 다시 배분할 수 없다.
    ///
    /// 높이는 CT 문단 높이에서 저작 문단 위·아래 간격을 뺀 **줄 범위**다 — 캐시 run 높이도 줄
    /// 위치·높이만 담고, 두 간격은 캐시 위치(이 문단 첫 줄·다음 문단 첫 줄)에 이미 들어 있다. CT
    /// 문단 높이를 쓰면 뒤 문단이 두 간격만큼 더 밀린다 (한글 12.30 실측: 위 10·아래 5pt 문단의 같은
    /// 표에서 뒤 문단은 캐시 위치 + 320pt — CT 문단 높이 차는 335pt). 트리거와 무관한 기하라 글자
    /// 크기 쪽도 같은 높이를 쓴다 (코퍼스의 그 사례인 CharShape는 간격이 0이라 종전과 같다). 밀린
    /// 문단이 쪽 아래를 넘으면 `staleShiftOverflows`가 쪽을 넘긴다.
    private func staleLineExtent(
        _ paragraph: CoreHwp.HwpParagraph,
        runs: [[CoreHwp.HwpParaLineSegInternal]],
        slice: NSAttributedString,
        frame: HwpParagraphFrame,
        cachedHeight: CGFloat
    ) -> CGFloat? {
        guard runs.count == 1,
              HwpAbsoluteCachePlacer.cacheIsStale(run: runs[0], attributedString: slice)
              || HwpParagraphLayout.lineCacheIsStale(
                  paragraph, inlineTableHeights: inlineTableHeights(for: paragraph)
              )
        else { return nil }
        let lineExtent = frame.totalHeight - authoredBeforeGap(of: paragraph)
            - authoredAfterGap(of: paragraph)
        return lineExtent > cachedHeight ? lineExtent : nil
    }

    /// 절대 캐시 run의 블록 높이 — 산식은 HwpAbsoluteCachePlacer, 하단 경계
    /// (현재 단 상단·본문 하단)만 여기서 주입한다.
    private func absoluteRunBlockHeight(
        run: [CoreHwp.HwpParaLineSegInternal],
        firstLocation: Int32
    ) -> CGFloat {
        HwpAbsoluteCachePlacer.absoluteRunBlockHeight(
            run: run,
            firstLocation: firstLocation,
            columnTop: currentColumnFrame.minY,
            contentBottom: currentPageGeometry.contentFrame.maxY
        )
    }

    /// 방금 놓은 절대 캐시 run 블록의 마지막 줄 줄 간격 몫을 기록한다 (#165) — 블록
    /// 아래(전진량)와 마지막 줄 상자 아래의 차. 하단 경계에 잘린 블록은 잘린 만큼만 남는다.
    ///
    /// **낡은 캐시로 CT 줄 범위까지 커진 블록은 0이다** (PR 리뷰): 그 블록의 아래는 캐시
    /// 전진량이 아니라 다시 조판한 CT 줄 범위라 캐시의 줄 간격이 들어 있지 않고, 커진 몫을
    /// "블록 아래 − 캐시 잉크"로 재면 재조판으로 늘어난 글자 높이까지 통째로 빼 본문 하한이
    /// 캐시 잉크로 되돌아간다 — 각주 구분선이 커진 글자 위에 그어진다. CT 마지막 줄의
    /// 상자 아래는 낡은 캐시로는 알 수 없으므로 CT 줄 범위 전체를 보수적으로 하한으로 둔다.
    private func recordAbsoluteRunTrailingSpacing(
        run: [CoreHwp.HwpParaLineSegInternal],
        firstLocation: Int32,
        blockHeight: CGFloat,
        isStaleAdjusted: Bool
    ) {
        guard !isStaleAdjusted else {
            trailingSpacesBelowLineBox[currentBlocks.count - 1] = 0
            return
        }
        let inkBottom = run.reduce(Int(firstLocation)) {
            max($0, Int($1.lineLocation) + Int(max(0, $1.lineHeight)))
        }
        let inkHeight = max(
            1, HwpUnits.points(fromHwpUnit: Int32(clamping: inkBottom - Int(firstLocation)))
        )
        trailingSpacesBelowLineBox[currentBlocks.count - 1] = max(0, blockHeight - inkHeight)
    }

    /// 이 쪽 본문이 각주 영역에 남긴 하한 (#165) — 캐시 run 블록은 마지막 줄 **상자**
    /// 아래 (줄 간격 제외, 한글 실측), 그 밖의 본문 블록(표·개체·흐름 문단)은 **그려지는**
    /// 하한 (`HwpHitTester.paintedObjectBounds`, #165 리뷰): 표·글상자의 오버레이·쪽
    /// 기준 자식은 프레임을 키우지 않고 그 아래로 그려지므로 프레임만 보면 각주 스택이
    /// 그 개체를 덮는다 — 겹침 가드가 재는 자와 같아야 한다. 본문 블록이 없으면 nil
    /// (이월 드레인의 빈 쪽). 크롬·변경 막대를 붙이기 **전에** 재야 한다 — 막대는
    /// 텍스트 블록 프레임(전진량)을 그대로 따른다.
    ///
    /// **미주 블록은 본문이다** (#165 리뷰): 미주는 흐름 콘텐츠라 쪽 위에서부터 놓이고
    /// (`appendPendingEndnotes`) 이월된 각주는 그 아래 자리에 실려야 한다. 쪽 각주는 이
    /// 하한을 잰 **뒤에** 붙으므로 (`placePageFootnotes`) 이 시점의 `.footnote` 종류
    /// 블록은 전부 미주다 — 그것을 빼면 미주만 있는 쪽이 빈 쪽으로 보여 각주 스택이 쪽
    /// 전체에 바닥 정렬되고, 진행 보장으로 놓인 미주를 덮는다 (재현: 미주 하단 104.67pt
    /// 위 구분선 92.6pt).
    private func footnoteBodyBottom() -> CGFloat? {
        currentBlocks.enumerated().compactMap { offset, block -> CGFloat? in
            guard block.role == .body else { return nil }
            return HwpHitTester.paintedObjectBounds(of: block).maxY
                - (trailingSpacesBelowLineBox[offset] ?? 0)
        }.max()
    }

    /// 문단에 붙은 구역 정의를 현재 페이지 지오메트리에 반영한다.
    func applySectionDef(in paragraph: CoreHwp.HwpParagraph) {
        guard let sectionDef = Self.sectionDef(in: paragraph) else { return }
        currentPageGeometry = HwpPageGeometry.compute(
            pageDef: sectionDef.pageDef,
            sectionDef: sectionDef
        )
        currentSectionDef = sectionDef
        pageChrome.applySectionHideFlags(sectionDef)
        // 구역은 항상 새 페이지에서 시작하므로 여기서 논리 쪽 번호를 재설정해도 안전하다.
        // 사용자 지정 시작 번호가 없으면 구역 시작 종류(표 130 bits 20-21)에 따라 홀짝이
        // 어긋난 번호만 1 건너뛴다 — 한글 12.30은 빈 쪽을 끼우지 않고 번호만 건너뛰므로
        // (물리 4쪽에 1·3·4·5) 쪽 자체는 추가하지 않는다 (#185). 새 번호 지정(nwno)의
        // 보류 리셋은 이 문단이 배치될 때 이 값을 덮는다 — 컨트롤이 구역보다 늦다.
        nextLogicalPageNumber = sectionDef.firstPageNumber(continuing: nextLogicalPageNumber)
        // 이월 각주의 예약을 새 구역의 기하·구분선으로 다시 잰다 (#165 리뷰) — 앞 쪽을 확정하며
        // 잰 값은 이전 구역의 폭·구분선·쪽 높이 기준이라, 새 구역 첫 쪽의 배치(새 폭·새 구분선)와
        // 갈려 흐름 문단·표가 헛되이 밀리거나 각주 자리를 먹는다. 밴드를 열기 전에 잰다.
        if !pendingFootnotes.isEmpty {
            footnoteReservedHeight = reservedFootnoteHeight(for: pendingFootnotes)
        }
        // 단 정의는 구역에 종속: 새 구역의 단 컨트롤이 다시 적용하기 전까지 1단.
        currentColumnDef = nil
        openColumnBand(top: currentPageGeometry.contentFrame.minY)
        if sectionDef.footNoteShape.numberingModeRawValue != 0 {
            footnoteCounter = Self.initialNoteNumber(
                startingNumber: sectionDef.footNoteShape.startingNumber
            )
        }
        if sectionDef.endNoteShape.numberingModeRawValue != 0 {
            endnoteCounter = Self.initialNoteNumber(
                startingNumber: sectionDef.endNoteShape.startingNumber
            )
        }
    }

    /// shape 해석은 `paraShapeOrDefault`다 — 스타일 부착
    /// (`HwpTextRunBuilder.attachParagraphStyle`)과 **같은 폴백**이어야 측정이
    /// 부착본을 그대로 framesetting할 수 있다 (#80 조각 3의 측정 입력 계약).
    /// 종전에는 `paraShape(for:)`가 nil이면 빈 프레임으로 조기 반환했는데,
    /// paraShape 표가 통째로 빈 문서에서 그 문단은 높이 0으로 잡힌 채 텍스트만
    /// 그려졌다 (뒤 문단과 겹친다). 이제 부착과 같은 기본 shape로 조판한다.
    func layout(
        _ paragraph: CoreHwp.HwpParagraph,
        attributedString: NSAttributedString
    ) async throws -> HwpParagraphFrame {
        await yieldPeriodically()
        // 빈 문단의 한 줄 높이는 `HwpParagraphMeasurer`와 같은 규약이다 (#137) —
        // 조판 문자열이 빈 문단 앵커(#145)라 `layout`이 실물 높이를 내고, 줄
        // 프레임만 비운다. 라인 캐시가 유효하면 `height(for:fallback:)`이 캐시
        // 높이를 쓰므로 이 값은 캐시가 없거나 무효일 때만 쓰인다.
        let frame = HwpParagraphLayout().layout(
            attributedString: attributedString,
            paraShape: index.paraShapeOrDefault(for: paragraph),
            columnWidth: currentColumnFrame.width
        )
        guard HwpTextRunBuilder.isEmptyParagraphAnchor(attributedString) else { return frame }
        return HwpParagraphFrame(totalHeight: frame.totalHeight, lines: [])
    }

    /// 전체 문단 대비 처리 위치 (0...1 근사) — 프로그레시브 로딩 진행률
    public func progressEstimate() -> Double {
        let total = sections.reduce(0) { $0 + $1.paragraph.count }
        guard total > 0 else { return 1 }
        let done = sections.prefix(min(nextSectionIndex, sections.count))
            .reduce(0) { $0 + $1.paragraph.count } + nextParagraphIndex
        return min(1, max(0, Double(done) / Double(total)))
    }

    func nextParagraph() -> CoreHwp.HwpParagraph? {
        while sections.indices.contains(nextSectionIndex) {
            let paragraphs = sections[nextSectionIndex].paragraph
            if paragraphs.indices.contains(nextParagraphIndex) {
                return paragraphs[nextParagraphIndex]
            }
            nextSectionIndex += 1
            nextParagraphIndex = 0
        }
        return nil
    }

    func advanceParagraph() {
        nextParagraphIndex += 1
        while sections.indices.contains(nextSectionIndex),
              nextParagraphIndex >= sections[nextSectionIndex].paragraph.count
        {
            nextSectionIndex += 1
            nextParagraphIndex = 0
        }
    }

    /// `lines`는 온전한 (분할되지 않은) 문단 블록의 줄 — 줄 앵커 문맥과 다단 균형
    /// 재배치(`bandTextBlocks`)가 함께 읽는다. `anchorLines`는 쪽·단에 걸친 **조각**의
    /// 조각 기준 줄 프레임(`HwpParagraphLayout.fragmentLineFrames`)으로 줄 앵커 문맥에만
    /// 쓴다 (#164) — 균형 재배치 단위는 종전대로 조각 블록 통째다.
    ///
    /// `heightIsMeasured`는 `height`가 `lines`의 측정 전진량에서 왔는지 — 저장본 줄 캐시
    /// 높이면 false로 넘겨 균형 재배치가 잔여 줄 조각에 측정 줄 조각 표식을 달지 않게 한다 (#166).
    /// `paraShape`는 균형 재배치가 조각을 폭이 다른 단으로 옮길 때 그 단 폭으로 다시 재는 데
    /// 쓴다 — 측정 높이 블록만 필요하다. `startsParagraph`는 블록이 문단 머리에서 시작하는지
    /// (쪽·단 경계로 나뉜 문단의 뒤 조각 블록은 false) — 그 재측정이 블록 전체를 문단으로
    /// 볼지 조각으로 볼지 가른다. `metricsReference`는 그 재측정의 문단 지표를 뽑을 **문단
    /// 전체** 조판 문자열이다 — 뒤 조각 블록의 문자열은 문단의 일부라 큰 글자를 놓칠 수 있다
    /// (PR 리뷰); nil이면 블록 문자열이 곧 문단이다.
    func appendBlock(
        height: CGFloat,
        attributedString: NSAttributedString,
        hyperlinkURL: String? = nil,
        paragraphId: UInt32? = nil,
        lines: [HwpLineFrame] = [],
        heightIsMeasured: Bool = true,
        paraShape: CoreHwp.HwpParaShape? = nil,
        startsParagraph: Bool = true,
        metricsReference: NSAttributedString? = nil,
        anchorLines: [HwpLineFrame] = [],
        cachedTrailingSpacing: CGFloat? = nil
    ) {
        // 문단의 첫 콘텐츠가 페이지에 놓이는 지금 보류된 쪽 번호 리셋을 확정한다 —
        // 열/쪽에 걸친 조각이 캐시되기 전에 적용해야 시작 페이지가 새 번호를
        // 갖는다 (조각 캐시 후 적용하면 시작 페이지가 옛 번호로 남는다 — #12).
        // 미적합 재시도는 appendBlock 전에 return하므로 리셋이 보류로 남아 올바르다.
        // 글줄 앞 표(#190)가 먼저 놓인 문단은 그 첫 조각이 이미 확정했다.
        applyPendingPageNumberReset()
        // 여기가 문단의 첫 콘텐츠가 쪽에 놓이는 지점이라 개요의 시작 쪽도 여기서
        // 확정된다 (위 쪽 번호 리셋과 같은 순간이다).
        if currentParagraphFirstPlacedPage == nil {
            currentParagraphFirstPlacedPage = cachedPages.count + 1
        }
        let immutable = NSAttributedString(
            attributedString: Self.markedWithCachedTrailingSpacing(
                attributedString, cachedTrailingSpacing: cachedTrailingSpacing
            )
        )
        let columnFrame = currentColumnFrame
        let frame = CGRect(
            x: columnFrame.minX,
            y: columnFrame.minY + contentHeightUsed,
            width: columnFrame.width,
            height: height
        )
        currentBlocks.append(AnyHwpBlock(
            frame: frame,
            kind: .text,
            attributedString: immutable,
            hyperlinkURL: hyperlinkURL,
            // 위치 열쇠(구역·문단 서수)는 이 시점의 문단 커서다 — 조각·재시도·
            // 다단 재분배 모두 `advanceParagraph()` 전에 여기를 지난다. 복사가
            // 열/쪽에 걸친 같은 문단을 잇는 identity로 쓴다 (`paraId`는 한글.app
            // 저장본에서 0·0x80000000이 되풀이돼 문단을 가르지 못한다, #145).
            source: HwpBlockSource(
                paragraphId: paragraphId,
                sectionIndex: nextSectionIndex,
                paragraphIndex: nextParagraphIndex
            )
        ))
        bandTextBlocks.append(HwpColumnBandController.BandTextBlock(
            blockIndex: currentBlocks.count - 1, lines: lines,
            heightIsMeasured: heightIsMeasured, paraShape: paraShape,
            startsParagraph: startsParagraph, metricsReference: metricsReference
        ))
        // 줄 중간 앵커 기준: 온전한 문단 블록의 줄, 또는 조각 기준으로 되돌린 조각의 줄 —
        // 렌더러가 조각을 한 줄로 접으면 앵커도 그 한 줄에서 찾는다.
        let contextLines = anchorLines.isEmpty
            ? lines
            : HwpParagraphLayout.fragmentLineFramesAsDrawn(
                anchorLines, fragment: immutable, columnWidth: frame.width
            )
        currentParagraphContext = contextLines.isEmpty ? nil : (frame, contextLines)
        contentHeightUsed += height
        markBandUsage()
    }

    /// 새 번호 지정(nwno)의 보류된 쪽 번호 리셋을 **문단의 첫 콘텐츠가 쪽에 놓이는 지점**에서
    /// 확정한다 — 글줄 블록(`appendBlock`)과 글줄 앞 표 조각(`appendTableSegmentBlock`, #190)이
    /// 같은 지점이다. 표가 먼저 놓이는 문단은 표의 첫 조각이 실린 쪽부터 새 번호가 이어진다
    /// (PR 리뷰: 새 쪽 번호 9 + 두 쪽 표 → 9·10·11; 글줄에서만 확정하면 1·2·9). 이미 확정됐으면
    /// 무동작이다.
    private func applyPendingPageNumberReset() {
        guard let reset = pendingPageNumber else { return }
        nextLogicalPageNumber = reset
        pendingPageNumber = nil
    }

    /// 다단 밴드에서 문단 라인을 현재 단부터 채워 넣는다.
    /// 단이 차면 다음 단으로, 마지막 단이 차면 새 페이지로 이어진다.
    func containsHyperlinkFieldSpans(_ attributedString: NSAttributedString) -> Bool {
        var found = false
        attributedString.enumerateAttribute(
            HwpAttributedStringKey.hyperlink,
            in: NSRange(location: 0, length: attributedString.length)
        ) { value, _, stop in
            if value != nil {
                found = true
                stop.pointee = true
            }
        }
        return found
    }

    /// reservedFootnoteHeight는 이 문단이 만들 각주 예약분 (본문/각주 겹침 방지).
    /// `onFragmentPlaced`는 마지막이 아닌 조각을 놓은 직후, 단·쪽을 넘기기 **전**에
    /// 불린다 — 그 조각의 줄 앵커가 있는 개체를 그 단·쪽에 놓을 기회다 (#164).
    /// `paraShape`는 조각의 줄 앵커를 목적 단 폭으로 다시 조판할 때, 그리고 측정 높이 문단의
    /// 나머지를 폭이 다른 단에서 다시 잴 때 쓴다 (`HwpFragmentRemainder`) — 줄은 이 함수에
    /// 들어올 때의 단 폭으로 측정됐고, 비등폭 단으로 이월된 조각은 렌더가 그 단 폭으로
    /// 다시 줄바꿈한다.
    ///
    /// `splitPolicy`는 쪽·단 경계의 분할 규칙(외톨이줄 보호·문단 보호, #207)이고
    /// `fragmentFootnotes`는 조각별 각주 귀속 문맥이다 — 있으면 각주 예약은 조각 범위로 줄마다
    /// 재고(`reservedFootnoteHeight`는 0으로 온다) 조각을 놓을 때마다 그 각주를 걷는다.
    func appendParagraphAcrossColumns(
        attributedString: NSAttributedString,
        paragraphFrame: HwpParagraphFrame,
        paragraphHeight: CGFloat,
        hyperlinkURL: String?,
        paragraphId: UInt32?,
        paraShape: CoreHwp.HwpParaShape = CoreHwp.HwpParaShape(),
        reservedFootnoteHeight: CGFloat = 0,
        beforeGap: CGFloat = 0,
        cachedTrailingSpacing: CGFloat? = nil,
        splitPolicy: HwpParagraphSplitPolicy = .none,
        fragmentFootnotes: HwpFlowFragmentFootnotes? = nil,
        fitSource: HwpFragmentFitSource = .none,
        onFragmentPlaced: () -> Void = {}
    ) {
        let lines = paragraphFrame.lines
        // 조각들은 독립 CT 프레임이라 문단-앞 간격이 렌더되지 않는다 — 첫 조각
        // 앞에서 커서로 소비하고 이후 산술은 텍스트 몫(textHeight)만 쓴다 (#1).
        // 넘김 판정은 (커서+gap) + text = 커서 + paragraphHeight로 종전과 동치.
        // 빈 단에서 gap을 먼저 더하면 단이 점유된 듯 보여 초과 문단이 빈 단을
        // 건너뛴다 — gap 추가 전 빈 단 여부를 보존한다 (R54 #3).
        let startedEmpty = contentHeightUsed <= 0
        contentHeightUsed += beforeGap
        let textHeight = paragraphHeight - beforeGap
        // 조각마다 같은 문단 문맥 — 예약이 묶인 단 폭·높이 출처·URL (`fragmentPlacement`).
        var placement = fragmentPlacement(
            attributedString: attributedString, paragraphFrame: paragraphFrame,
            paragraphHeight: paragraphHeight, hyperlinkURL: hyperlinkURL,
            paragraphId: paragraphId, paraShape: paraShape,
            cachedTrailingSpacing: cachedTrailingSpacing
        )
        placement.beforeGap = beforeGap
        placement.reservedFootnoteHeight = reservedFootnoteHeight
        placement.splitPolicy = splitPolicy
        placement.fragmentFootnotes = fragmentFootnotes
        paragraphAnchorTop = currentColumnFrame.minY + contentHeightUsed
        // 라인별 실제 전진량(origin.y 델타)으로 조각을 나눈다 — 산식과 조각 첫 줄
        // ascent 초과분(#164 리뷰)은 `HwpFragmentLineAdvances`. 나머지가 폭이 다른 단으로
        // 넘어가면 그 단 폭으로 다시 잰다 (`HwpFragmentRemainder`, PR 리뷰).
        var remainder = HwpFragmentRemainder(
            lines: lines, textHeight: textHeight,
            measuredWidth: currentColumnFrame.width, heightIsMeasured: placement.heightIsMeasured,
            fitSource: fitSource
        )
        // 이 문단 말고는 아무것도 없는 단인지 — 진입한 빈 단, 또는 단·쪽을 넘긴 뒤의 새 단.
        // 커서(`contentHeightUsed`)로는 못 가른다: 통째로 넘긴 새 단 머리에 문단 위 간격이
        // 다시 실려(`advancePastUnplacedFragment`·`moveWholeParagraphToNextColumn`) 커서가
        // 양수라도 단은 비어 있다. 분할 규칙의 빈 단 예외(문단 보호 무시)와 아래 진행 보장이 같은
        // 술어를 봐야 한다 — 부분 채운 단에서 시작한 문단 보호 문단이 새 단마다 0줄을 내면 쪽
        // 상한까지 빈 쪽을 만든다 (PR 리뷰). 한 줄 문단을 통째로 옮긴 뒤 좁은 단에서 여러 줄로
        // 다시 재어 조각 루프로 넘어온 경우도 같다 (PR 리뷰 2: 진입 시 값을 그대로 쓰면 빈 둘째
        // 단을 건너뛴다).
        var columnHoldsOnlyThisParagraph = startedEmpty
        if lines.count <= 1 || textHeight <= 0,
           placeSingleLineParagraph(
               &remainder, columnHoldsOnlyThisParagraph: &columnHoldsOnlyThisParagraph,
               attributedString: attributedString, placement: placement
           )
        {
            return
        }

        while !remainder.isExhausted {
            let isAtParagraphStart = remainder.isAtParagraphStart
            let available = max(1, effectiveContentHeight - reservedFootnoteHeight)
                - contentHeightUsed
            let columnIsEmpty = contentHeightUsed <= 0 || columnHoldsOnlyThisParagraph
            // 남는 줄 수는 분할 규칙(#207)으로 깎이고, 줄마다 그 줄까지의 각주 예약이 든다.
            var (takeCount, takenHeight) = remainder.fit(
                in: available,
                policy: splitPolicy,
                columnIsEmpty: columnIsEmpty,
                extra: { fragmentFootnoteReservation(through: $0, of: remainder, fragmentFootnotes) }
            )
            // 빈 단(gap만 charge)에서 gap+첫 줄이 안 맞는 초과 문단은 gap을 무르고
            // 첫 줄을 현재 단 top에 flush한다 — 빈 단을 건너뛰지 않는다 (R54 #3).
            // 분할 규칙이 빈 단에서 0줄을 내는 경우(두 줄도 안 들어가는 단의 외톨이줄 보호)도
            // 같은 진행 보장이다.
            let onEmptyStartColumn = columnHoldsOnlyThisParagraph && isAtParagraphStart
            if columnIsEmpty, takeCount == 0 {
                if onEmptyStartColumn {
                    contentHeightUsed = 0
                    paragraphAnchorTop = currentColumnFrame.minY
                }
                (takeCount, takenHeight) = (1, remainder.firstLineHeight)
            }
            if takeCount <= 0 {
                // 페이지 상한 도달: cacheCurrentPage가 밴드/커서를 리셋하지
                // 않고 종료하므로 같은 lineIndex 재시도는 무한 루프다 —
                // 남은 줄은 상한 절단 계약대로 버린다 (#1).
                guard advancePastUnplacedFragment(
                    &remainder, isAtParagraphStart: isAtParagraphStart,
                    attributedString: attributedString, placement: placement
                ) else { return }
                columnHoldsOnlyThisParagraph = true
                continue
            }
            appendLineSliceBlock(
                remainder.lines[remainder.lineIndex ..< remainder.lineIndex + takeCount],
                of: remainder,
                takenHeight: takenHeight,
                attributedString: attributedString,
                placement: placement
            )
            let placedThrough = remainder.lineIndex + takeCount - 1
            remainder.place(takeCount)
            // 이 조각의 각주는 이 쪽에 — 쪽을 넘기기 **전**에 걷어야 `cacheCurrentPage`가 싣는다.
            collectFlowFragmentFootnotes(through: placedThrough, of: remainder, fragmentFootnotes)
            if !remainder.isExhausted {
                onFragmentPlaced()
                advanceColumn()
                columnHoldsOnlyThisParagraph = true
                if didFinishPagination {
                    return
                }
                remeasureRemainderIfNeeded(
                    &remainder, attributedString: attributedString, placement: placement
                )
            }
        }
    }

    /// 한 줄 문단(또는 텍스트 몫 0)의 배치 — 나눌 줄이 없으니 들어가면 놓고 아니면 통째로 다음
    /// 단으로 옮긴다. 빈 단에서 gap+text가 안 맞는 초과 문단이면 gap을 무르고 현재 단 top에
    /// flush한다 — 빈 단을 건너뛰지 않는다 (R54 #3). 각주 몫은 조각 귀속 문맥이 있으면 그 줄의
    /// 각주 예약이다 (#207). 통째로 옮기며 다시 재어 여러 줄이 됐으면 false를 돌려 조각 루프가 이
    /// 단부터 나눠 놓는다 (PR 리뷰) — 통째로 놓으면 목적 단보다 큰 상자가 여백·뒤 내용으로 넘친다.
    ///
    /// `columnHoldsOnlyThisParagraph`는 진입 시 빈 단 여부로 들어와, 통째로 옮기면 참이 된다 —
    /// 옮긴 새 단은 이 문단만 든 단이다 (PR 리뷰 2).
    private func placeSingleLineParagraph(
        _ remainder: inout HwpFragmentRemainder,
        columnHoldsOnlyThisParagraph: inout Bool,
        attributedString: NSAttributedString,
        placement: HwpFragmentPlacement
    ) -> Bool {
        // 적합은 줄 상자 하단까지로 잰다 (#222) — 줄 간격 여분·아래 간격은 단 아래로 넘쳐도 된다.
        let fitHeight = remainder.remainingFitHeight
        let usableHeight = max(1, effectiveContentHeight - placement.reservedFootnoteHeight)
        let noteReservation = fragmentFootnoteReservation(
            through: 0, of: remainder, placement.fragmentFootnotes
        )
        if columnHoldsOnlyThisParagraph {
            if !HwpPageEndFit.fits(
                placement.beforeGap + fitHeight + noteReservation, in: usableHeight
            ) {
                contentHeightUsed = 0
                paragraphAnchorTop = currentColumnFrame.minY
            }
        } else if !HwpPageEndFit.fits(
            contentHeightUsed + fitHeight + noteReservation, in: usableHeight
        ) {
            moveWholeParagraphToNextColumn(
                &remainder, attributedString: attributedString, placement: placement
            )
            columnHoldsOnlyThisParagraph = true
        }
        guard remainder.lines.count <= 1 else { return false }
        appendBlock(
            height: remainder.advances.textHeight,
            // 다시 잰 문자열(목적 단으로 다시 푼 개체 예약)을 그대로 그린다 (PR 리뷰).
            attributedString: placedFragment(attributedString, reservedWidth: placement.reservedWidth),
            hyperlinkURL: placement.hyperlinkURL,
            paragraphId: placement.paragraphId,
            lines: remainder.lines,
            heightIsMeasured: remainder.heightIsMeasured,
            paraShape: placement.paraShape,
            cachedTrailingSpacing: remainder.cachedTrailingSpacing(from: placement)
        )
        recordFlowTrailingSpace(
            blockHeight: remainder.advances.textHeight, fitHeight: remainder.remainingFitHeight
        )
        collectFlowFragmentFootnotes(
            through: max(0, remainder.lines.count - 1), of: remainder, placement.fragmentFootnotes
        )
        return true
    }

    /// 조각 루프에서 줄이 하나도 안 들어가 단·쪽을 넘긴다 — 쪽 상한에 닿았으면 false.
    ///
    /// 아직 아무 줄도 안 놓은 통째 이동이면 진입 시 charge한 gap을 구 단 사용량에서 무른다 —
    /// 렌더되지 않을 gap이 markBandUsage로 밴드 하단을 부풀린다 (R56 #3). 문단 첫 줄을 통째로
    /// 새 단으로 옮기면(아직 아무 줄도 안 놓음) 문단 위 간격을 새 단 top에도 유지한다 — 본문
    /// 단일 열이 새 페이지 top에서 gap을 렌더하는 것(placeFlowParagraph)과 일치 (R53 #1).
    /// gap+첫 줄이 빈 단보다 크면 진행 보장을 위해 flush 배치한다. 단 이동이 페이지를 넘기면
    /// 각주 예약이 바뀌므로 usable을 재계산하고 (R55 #4), gap을 물리면 .paragraph 기준 개체의
    /// anchor도 함께 내린다 (R55 #5). "첫 줄"의 크기는 다음 반복의 적합 판정과 **같은 출처**인
    /// 그 줄의 **상자 높이**다 (`firstLineFitHeight`, #222 — 방출·진행 보장은 여전히 줄 전진량이다).
    /// 조각을 걷지 않고 넘겼으니 새 쪽의 각주 상태로 예약을 다시 잰다 (#207).
    private func advancePastUnplacedFragment(
        _ remainder: inout HwpFragmentRemainder,
        isAtParagraphStart: Bool,
        attributedString: NSAttributedString,
        placement: HwpFragmentPlacement
    ) -> Bool {
        if isAtParagraphStart {
            contentHeightUsed = max(0, contentHeightUsed - placement.beforeGap)
        }
        advanceColumn()
        placement.fragmentFootnotes?.invalidateReservations()
        if didFinishPagination {
            return false
        }
        remeasureRemainderIfNeeded(
            &remainder, attributedString: attributedString, placement: placement
        )
        let usableAfterAdvance = max(1, effectiveContentHeight - placement.reservedFootnoteHeight)
        if isAtParagraphStart,
           HwpPageEndFit.fits(
               placement.beforeGap + remainder.firstLineFitHeight, in: usableAfterAdvance
           )
        {
            contentHeightUsed += placement.beforeGap
            paragraphAnchorTop = currentColumnFrame.minY + contentHeightUsed
        }
        return true
    }

    /// 부분 채운 단에 안 맞는 한 줄 문단을 통째로 다음 단으로 옮긴다 — 다중 줄·본문 경로와
    /// 일치 (R54 #2). 이동 문단의 gap은 구 단에 렌더되지 않으므로 markBandUsage 전에 무른다
    /// (밴드 하단이 부풀면 다음 밴드가 밀리거나 불필요한 새 페이지, R56 #3). 폭이 다른 단이면
    /// 문단을 통째로 그 폭으로 다시 잰다 — 한 줄로 잰 문단이 좁은 단에서 여러 줄이 되면
    /// 상자도 그만큼 커야 한다 (PR 리뷰). 새 단 top에는 gap+첫 줄이 들어갈 때만 gap을
    /// 재적용한다(조각 루프의 통째 이동 규칙과 같다 — 빈 단보다 크면 진행 보장을 위해 flush).
    /// 단 이동이 페이지를 넘기면 각주 예약이 바뀌므로 usable을 재계산한다 (R55 #4).
    private func moveWholeParagraphToNextColumn(
        _ remainder: inout HwpFragmentRemainder,
        attributedString: NSAttributedString,
        placement: HwpFragmentPlacement
    ) {
        contentHeightUsed -= placement.beforeGap
        advanceColumn()
        // 조각을 걷지 않고 넘겼으니 새 쪽의 각주 상태로 예약을 다시 잰다 (#207).
        placement.fragmentFootnotes?.invalidateReservations()
        remeasureRemainderIfNeeded(
            &remainder, attributedString: attributedString, placement: placement
        )
        if HwpPageEndFit.fits(
            placement.beforeGap + remainder.firstLineFitHeight,
            in: max(1, effectiveContentHeight - placement.reservedFootnoteHeight)
        ) {
            contentHeightUsed += placement.beforeGap
        }
        paragraphAnchorTop = currentColumnFrame.minY + contentHeightUsed
    }

    /// 나머지가 줄을 잰 폭과 다른 단으로 넘어왔으면 그 단 폭으로 다시 잰다 (#166 PR 리뷰,
    /// `HwpFragmentRemainder`). 측정 줄 조각 표식은 접힘만 막아, 넓은 단에서는 CT가 줄을
    /// 합쳐 잰 높이의 상자 아래가 비고 좁은 단에서는 줄이 늘어 상자를 넘쳤다 — 한글처럼
    /// 옮겨진 단 폭으로 다시 줄바꿈해 조각 높이·줄 수·앵커를 그 줄바꿈으로 잡는다. 저장본
    /// 줄 캐시 높이를 따르는 문단은 다시 재지 않는다 (그 높이는 한글의 것이다).
    ///
    /// 다시 재는 문자열은 조각을 그릴 문자열과 같아야 한다 — 이어지는 조각의 문단 스타일
    /// (`continuationFragment`)과 목적 단으로 다시 푼 개체 예약(`placedFragment`)까지. 문단
    /// 머리가 아닌 나머지는 표식을 단 채로 재어 문단 단위 한 줄 넘침 규칙을 건너뛴다
    /// (`markedAsMeasuredLineFragment` — 조각을 접으면 한글의 줄바꿈과 갈린다); 문단 머리부터
    /// 통째로 옮긴 나머지는 문단이라 그 규칙을 따른다. 텍스트 몫은 `layout`의 높이에서 문단 위
    /// 간격(첫 조각 앞에서 커서로 이미 소비)을 뺀 것이다.
    private func remeasureRemainderIfNeeded(
        _ remainder: inout HwpFragmentRemainder,
        attributedString: NSAttributedString,
        placement: HwpFragmentPlacement
    ) {
        guard remainder.heightIsMeasured, remainder.canRemeasure,
              currentColumnFrame.width != remainder.measuredWidth,
              let range = remainder.remainingRange(in: attributedString), range.length > 0
        else { return }
        let fragment = placedFragment(
            HwpParagraphLayout.continuationFragment(of: attributedString, range: range),
            reservedWidth: placement.reservedWidth
        )
        // 문단 지표(마지막 줄 높이·줄 뒤 간격)는 문단 전체 문자열로 — 조각만 보면 큰 글자가
        // 앞 조각에만 있는 문단의 나머지 마지막 줄이 짧아진다 (PR 리뷰).
        let frame = HwpParagraphLayout().layout(
            attributedString: range.location > 0
                ? HwpParagraphLayout.markedAsMeasuredLineFragment(fragment) : fragment,
            paraShape: placement.paraShape,
            columnWidth: currentColumnFrame.width,
            maxLineFrames: remainder.lineBudget,
            metricsReference: attributedString
        )
        guard !frame.lines.isEmpty else { return }
        // 문단 위 간격은 첫 조각 앞에서 커서로 소비했다 — `authoredBeforeGap`과 같이 0 하한.
        let spacingBefore = max(0, HwpParagraphLayout.ParagraphMetrics(
            paraShape: placement.paraShape, attributedString: attributedString
        ).paragraphSpacingBefore)
        remainder.replace(
            with: frame, textHeight: max(1, frame.totalHeight - spacingBefore),
            width: currentColumnFrame.width, range: range
        )
    }

    /// `appendParagraphAcrossColumns`가 조각마다 같은 값으로 쓰는 문단 문맥 — 개체 예약이
    /// 묶인 단 폭은 진입 시의 현재 단 폭이고, 높이 출처는 문단 높이가 측정값
    /// (`paragraphFrame.totalHeight`)과 같은지로 가른다 (아니면 저장본 줄 캐시라 마지막 줄의
    /// 전진량은 캐시 잔여다, #166).
    /// 필드 스팬 문단(hyperlink attribute 보유)의 조각 블록엔 URL을 전파하지 않는다 — 링크는
    /// 조각 substring의 attribute region이 운반하고, block URL은 region 없는 평문 조각 전체를
    /// 폴백 링크로 만든다 (#4).
    private func fragmentPlacement(
        attributedString: NSAttributedString,
        paragraphFrame: HwpParagraphFrame,
        paragraphHeight: CGFloat,
        hyperlinkURL: String?,
        paragraphId: UInt32?,
        paraShape: CoreHwp.HwpParaShape,
        cachedTrailingSpacing: CGFloat? = nil
    ) -> HwpFragmentPlacement {
        HwpFragmentPlacement(
            paraShape: paraShape,
            reservedWidth: currentColumnFrame.width,
            heightIsMeasured: abs(paragraphHeight - paragraphFrame.totalHeight) < 0.01,
            cachedTrailingSpacing: cachedTrailingSpacing,
            paragraphId: paragraphId,
            hyperlinkURL: hyperlinkURL,
            fragmentURL: containsHyperlinkFieldSpans(attributedString) ? nil : hyperlinkURL
        )
    }

    /// 문단 줄 가운데 `slice`만 담은 블록을 놓는다 (`appendParagraphAcrossColumns`의 조각).
    /// 문단 전체면 온전한 줄 목록을, 조각이면 조각 기준 줄(`fragmentLineFrames`)을 앵커
    /// 문맥으로 준다 (#164). 이어지는 조각은 첫 줄 들여쓰기를 둘째 줄에 맞춘다. 이 블록의
    /// 단 폭이 줄을 잰 폭(`remainder.measuredWidth`)과 다르면 앵커 문맥은 목적 단 폭으로
    /// 다시 조판한 줄이다 — 측정 높이 문단은 나머지를 목적 단 폭으로 다시 재므로
    /// (`remeasureRemainderIfNeeded`) 여기 오는 줄은 이미 이 단 폭의 것이고, 캐시 높이 문단만
    /// 잰 폭의 줄로 온다.
    ///
    /// 블록 높이는 누적 전진량 `takenHeight`다 — 줄 프레임 원점이 줄 상자 상단이라 조각 상단이
    /// 곧 첫 줄 상자 상단이고 뒤 조각으로 넘길 몫이 없다 (#180). 그 높이가 측정
    /// 줄 전진량만으로 났으면(`HwpFragmentLineAdvances.heightIsMeasured`) 측정 줄 조각 표식을
    /// 단다 (`HwpParagraphLayout.measuredLineFragment`, #166) — 블록 높이가 측정한 줄 전진량이라
    /// 렌더러가 조각을 한 줄로 접으면 아래가 빈다. 이 단이 잰 폭보다 좁으면(캐시 높이 문단의
    /// 비등폭 단 이월) 렌더러가 이 단 폭으로 다시 줄바꿈하므로 그 판정은 폭 허용 오차 없이
    /// 실제 줄바꿈으로 한다. 앵커 문맥(`fragmentAnchorLines`)과 개체 예약(`placedFragment`)의
    /// "같은 폭"도 같은 정확 비교다 (PR 리뷰) — 표식이 붙어 렌더러가 이 단 폭의 줄바꿈으로
    /// 그리는 조각의 앵커를 잰 폭의 줄로 잡으면 개체가 다른 줄·다른 x에 놓인다.
    private func appendLineSliceBlock(
        _ slice: ArraySlice<HwpLineFrame>,
        of remainder: HwpFragmentRemainder,
        takenHeight: CGFloat,
        attributedString: NSAttributedString,
        placement: HwpFragmentPlacement
    ) {
        let range = slice.dropFirst().reduce(slice[slice.startIndex].attributedRange) {
            NSUnionRange($0, $1.attributedRange)
        }
        let advances = remainder.advances
        let height = takenHeight
        let heightIsMeasured = advances.heightIsMeasured(
            endingBefore: slice.endIndex, textHeightIsMeasured: remainder.heightIsMeasured
        )
        let isWholeParagraph = remainder.start == 0 && slice.count == remainder.lines.count
        let sameWidth = currentColumnFrame.width == remainder.measuredWidth
        let measured = HwpParagraphLayout.measuredLineFragment(
            placedFragment(
                HwpParagraphLayout.continuationFragment(of: attributedString, range: range),
                reservedWidth: placement.reservedWidth
            ),
            heightIsMeasured: heightIsMeasured,
            measuredLineCount: slice.count,
            measuredWidth: remainder.measuredWidth,
            columnWidth: currentColumnFrame.width
        )
        // 뒤에 놓을 줄이 남은 조각은 이어짐 표식을 단다 — 표 행 분할·각주 이어짐과 같은
        // 마커다 (PR 리뷰: 없으면 조각 끝 줄이 문단 마지막 줄로 오인돼 양쪽 정렬이 풀리고
        // MS 워드 호환 문단 끝 상자가 앞 조각에 든다).
        let fragment = slice.endIndex < remainder.lines.count
            ? HwpTableSplitter.markedAsContinuedFragment(measured) : measured
        appendBlock(
            height: height,
            attributedString: fragment,
            hyperlinkURL: isWholeParagraph ? placement.hyperlinkURL : placement.fragmentURL,
            paragraphId: placement.paragraphId,
            lines: isWholeParagraph ? remainder.lines : [],
            heightIsMeasured: heightIsMeasured,
            paraShape: placement.paraShape,
            startsParagraph: remainder.start == 0 && slice.startIndex == 0,
            metricsReference: isWholeParagraph ? nil : attributedString,
            anchorLines: isWholeParagraph && sameWidth
                ? []
                : fragmentAnchorLines(
                    slice, range: range, fragment: fragment,
                    paraShape: placement.paraShape, measuredWidth: remainder.measuredWidth
                ),
            cachedTrailingSpacing: remainder.cachedTrailingSpacing(from: placement)
        )
        recordFlowTrailingSpace(
            blockHeight: height,
            fitHeight: advances.fitHeight(from: slice.startIndex, through: slice.endIndex - 1)
        )
    }

    /// 조각이 실제로 놓이는 단의 기하로 푼 조각 문자열 (#164 리뷰). 단 폭이 줄을 잰
    /// 폭과 같으면 그대로고, 다르면 단 폭에 딸린 예약 폭('단'·'문단' 기준 개체)을 목적
    /// 단으로 다시 푼 사본이다 — 예약을 그대로 두면 문단을 처음 잰 단의 폭이 남아,
    /// 놓이는 단으로 크기를 푸는 paint(`objectSize`)와 갈려 개체가 뒤 글자를 덮는다.
    ///
    /// 렌더 문자열과 앵커 문맥(`fragmentAnchorLines`)이 **같은 사본**이어야 마커 x가
    /// 그려진 자리와 맞으므로, 다시 조판하기 전에 여기서 한 번 갈아 둘 다에 넘긴다.
    /// "같은 폭"은 허용 오차 없는 정확 비교다 — 같은 단·등폭 단의 폭은 같은 기하에서 온
    /// 같은 값이고, 비등폭 단은 HWPUNIT 단위로 저작돼 0.5pt 안의 차이도 실제 차이다.
    private func placedFragment(
        _ fragment: NSAttributedString,
        reservedWidth: CGFloat
    ) -> NSAttributedString {
        guard currentColumnFrame.width != reservedWidth else { return fragment }
        return rescaledInlineTableHeights(HwpInlineObjectReservation.rescaledForColumn(
            fragment, resolver: objectSizeResolver
        ))
    }

    /// 조각의 줄 앵커 문맥 (#164 리뷰): 조각이 놓이는 단의 폭이 줄을 잰 폭과 같으면 측정한
    /// 줄을 조각 기준으로 되돌린 것이고, 다르면(비등폭 단으로 이월) 렌더러가 그 단 폭으로
    /// 다시 줄바꿈하므로 조각 문자열을 목적 단 폭으로 다시 조판한 줄이다 — 첫 단 폭의
    /// 줄로 앵커를 잡으면 마커가 다른 줄·다른 x에 놓여 개체가 글자를 덮는다. 다시 조판한
    /// 줄은 이미 조각 기준(범위 0부터, 첫 줄 델타 0)이다.
    ///
    /// "같은 폭"은 허용 오차 없는 정확 비교다 (PR 리뷰, #166): 측정 줄 조각 표식이 붙은
    /// 조각은 렌더러가 목적 단 폭의 줄바꿈으로 그리므로, 0.5pt 안의 차이라도 잰 폭의 줄을
    /// 재사용하면 개체가 그려진 마커와 다른 줄에 놓인다 (0.4pt 좁은 단에서 30자 + 도형
    /// / `끝`으로 나뉜 조각의 도형이 첫 줄 끝에 남았다). 다시 조판한 줄은 같은 문자열을 같은
    /// 술어로 재므로 표식 유무와 무관하게 렌더러의 줄과 같다.
    private func fragmentAnchorLines(
        _ slice: ArraySlice<HwpLineFrame>,
        range: NSRange,
        fragment: NSAttributedString,
        paraShape: CoreHwp.HwpParaShape,
        measuredWidth: CGFloat
    ) -> [HwpLineFrame] {
        guard currentColumnFrame.width != measuredWidth else {
            return HwpParagraphLayout.fragmentLineFrames(slice, range: range)
        }
        return HwpParagraphLayout().layout(
            attributedString: fragment,
            paraShape: paraShape,
            columnWidth: currentColumnFrame.width
        ).lines
    }

    func hyperlinkURL(in paragraph: CoreHwp.HwpParagraph) -> String? {
        paragraph.hyperlinkURL
    }

    // MARK: - 자동 번호/새 번호 (표 142~144)

    /// 새 번호 지정 (nwno)을 카운터에 반영한다. 문단 처리 전에 호출해
    /// 같은 문단의 각주 참조/각주 번호가 재설정된 값부터 시작하게 한다.
    /// (문단 재처리 시에도 같은 값으로 다시 설정되므로 멱등하다.)
    func applyNewNumbers(in paragraph: CoreHwp.HwpParagraph) {
        for ctrl in paragraph.ctrlHeaderArray ?? [] {
            guard case let .newNumber(other) = ctrl,
                  let info = other.newNumberInfo
            else { continue }
            switch info.kind {
            case .page:
                pendingPageNumber = max(1, Int(info.number))
            case .footnote:
                footnoteCounter = max(1, Int(info.number))
            case .endnote:
                endnoteCounter = max(1, Int(info.number))
            case .picture, .table, .equation:
                break
            }
        }
    }

    /// 본문 문단의 extended 마커 치환 (각주/미주 번호 미리보기 + 자동 쪽 번호)
    /// — 산식은 HwpFootnoteCoordinator.noteReferenceReplacements 참조.
    func noteReferenceReplacements(
        for paragraph: CoreHwp.HwpParagraph,
        ordinals: Range<Int>? = nil
    ) -> [Int: HwpControlMarkerReplacement] {
        footnoteCoordinator.noteReferenceReplacements(
            for: paragraph,
            footnoteShape: currentSectionDef?.footNoteShape,
            endnoteShape: currentSectionDef?.endNoteShape,
            pageNumber: pendingPageNumber ?? nextLogicalPageNumber,
            ordinals: ordinals
        )
    }

    // MARK: - Unsupported walk (단일 traversal 지점 유지)

    func collectUnsupported(from paragraph: CoreHwp.HwpParagraph, firstPage: Int) {
        // 번호/개요 마커는 문단 첫 페이지 첫 줄에 속하므로 firstPage로 보고하고,
        // 컨트롤은 현재 배치 페이지 기준으로 보고한다 (#3).
        collectUnsupportedNumberingHeading(
            from: paragraph, page: firstPage, number: currentParagraphNumber
        )
        collectRecoveredParseFailures(from: paragraph, page: firstPage)
        guard let ctrls = paragraph.ctrlHeaderArray else { return }
        walkUnsupported(
            ctrls: ctrls,
            pages: UnsupportedPageContext(
                page: cachedPages.count + 1,
                flowPage: cachedPages.count + 1,
                placedPages: controlsPlacedBeforeParagraphEnd
            ),
            numbering: currentParagraphScope
        )
    }

    /// recover 모드(`HwpLoadOptions.recoverPartialContent`)가 남긴 placeholder를
    /// 사용자에게 보이게 한다 — 복구가 내용을 조용히 숨기지 않도록 하는
    /// 진단 채널이다 (#65). 구역 placeholder는 템플릿 문단만 가지므로 구역의
    /// 첫 문단 시점에 구역 단위로 한 번 보고한다.
    private func collectRecoveredParseFailures(
        from paragraph: CoreHwp.HwpParagraph,
        page: Int
    ) {
        if sections.indices.contains(nextSectionIndex),
           nextParagraphIndex == 0,
           let sectionFailure = sections[nextSectionIndex].parseFailure
        {
            collectedUnsupported.append(HwpUnsupportedElement(
                kind: .placeholder,
                page: page,
                hint: "손상 구역 복구 (파싱 실패: \(sectionFailure))"
            ))
        }
        if let paragraphFailure = paragraph.parseFailure {
            collectedUnsupported.append(HwpUnsupportedElement(
                kind: .placeholder,
                page: page,
                hint: "손상 문단 복구 (파싱 실패: \(paragraphFailure))"
            ))
        }
        collectMemoParseFailures(in: paragraph, page: page)
    }

    /// 메모 복구 placeholder는 호스트 문단이 정상 파싱되므로 호스트
    /// `parseFailure`로는 드러나지 않는다 — 메모 그룹과, 컨트롤 안 중첩 문단
    /// (표 셀·리스트·글상자)이 가진 메모 그룹까지 재귀로 보고한다. 렌더는
    /// placeholder 메모의 빈 텍스트를 `collectMemos`가 건너뛰므로 이 보고가
    /// 유일한 흔적이다 (#65). 재귀는 파스 시점 `maxNestingDepth`로 유한하다.
    private func collectMemoParseFailures(in paragraph: CoreHwp.HwpParagraph, page: Int) {
        for memoParagraph in (paragraph.memoParagraphGroups ?? []).flatMap({ $0 }) {
            if let failure = memoParagraph.parseFailure {
                collectedUnsupported.append(HwpUnsupportedElement(
                    kind: .placeholder,
                    page: page,
                    hint: "손상 메모 문단 복구 (파싱 실패: \(failure))"
                ))
            }
            collectMemoParseFailures(in: memoParagraph, page: page)
        }
        for ctrl in paragraph.ctrlHeaderArray ?? [] {
            for (nested, _) in Self.childParagraphs(of: ctrl) {
                collectMemoParseFailures(in: nested, page: page)
            }
        }
    }

    /// 개요(머리 종류 1)/번호(2) 문단 머리의 생성 라벨은 numbering 정의에 있고
    /// PARA_TEXT에 없다 — 라벨 문자열은 `paragraphNumbering`이 만들고(#153)
    /// `HwpTextRunBuilder.appendNumberingHeading`이 문단 앞에 전치하므로(#154)
    /// 번호가 있고 그 수준의 형식 슬롯이 있는 문단은 보고하지 않는다 — 슬롯이 빈
    /// 문자열이면 빈 라벨이 한글과 같은 결과다. 남는 것은 라벨이 나오지 못한 문단이다
    /// — 참조가 없거나 댕글링이면 그 사실을, 정의에 닿았는데 그 수준의 형식 슬롯
    /// 자체가 없으면(확장 형식 없는 5.0 저장본의 8수준 이상 — 번호는 세지만 라벨이
    /// 빈다) "(N수준 형식 없음)"을, 정의·슬롯이 있는데도 번호가 없으면(순회 상한·
    /// 취소로 `isTruncated`) "(미렌더)"를 적어 번호가 조용히 사라지지 않게 한다.
    /// 글머리표(3)는 appendBulletHeading이 렌더하므로 제외 (#1).
    ///
    /// 참조 해석은 `HwpNumberingHeadingReference`다 (#152) — 개요는 문단 모양이
    /// 아니라 **현재 구역 정의**의 `numberParaShapeId`를 따르므로, 종전의
    /// `paraShape.numberingOrBulletId > 0` 게이트로는 실문서 개요 문단(헌법주석
    /// 1,944개, 그 값이 전부 0)이 한 건도 잡히지 않았다. 집계 단위는 문단이고
    /// 쪽은 문단이 시작한 쪽이다. `currentSectionDef`는 `applySectionDef`가 이
    /// 문단 처리 앞에서 세우므로 구역 첫 문단도 자기 구역의 정의를 본다.
    ///
    /// `number`는 이 문단에 생성된 번호 — 최상위는 `currentParagraphNumber`, 컨테이너
    /// 안 문단은 `walkUnsupported`가 경로로 찾아 넘긴다 (#158). 컨테이너 문단의
    /// 개요 정의도 현재 구역의 것이다(생성기와 같은 규칙). 컨테이너 안 문단의 쪽은
    /// 문단이 시작한 쪽이 아니라 컨트롤 진단과 같은 **컨테이너를 배치한 뒤의 현재
    /// 쪽**(`walkUnsupported`의 `page`)이다 — 컨테이너 문단에는 별도의 시작 쪽 기록이
    /// 없다.
    private func collectUnsupportedNumberingHeading(
        from paragraph: CoreHwp.HwpParagraph,
        page: Int,
        number: HwpParagraphNumber?
    ) {
        guard let paraShape = index.paraShape(
            id: UInt32(paragraph.paraHeader.paraShapeId)
        ), let reference = HwpNumberingHeadingReference.resolve(
            paraShape: paraShape, sectionDef: currentSectionDef, index: index
        ) else { return }
        let hasFormat = reference.format(in: index) != nil
        if hasFormat, number != nil {
            return
        }
        let missingFormat = !hasFormat && reference.numbering(in: index) != nil
        collectedUnsupported.append(HwpUnsupportedElement(
            kind: .placeholder,
            page: page,
            hint: missingFormat ? reference.missingFormatHint : reference.unsupportedHint
        ))
    }

    /// 개요·책갈피 탐색 목록 수집 (#77). `collectUnsupported`와 같은 자리에서
    /// 같은 두 페이지 값을 쓴다 — 문단 머리는 문단이 **시작한** 쪽(`firstPage`),
    /// 컨트롤은 배치가 **끝난** 쪽. 탐색 목록은 라벨 전치·미지원 신고와 독립이라
    /// 번호를 만들지 못한 개요 문단은 신고와 탐색 목록에 함께 뜬다
    /// (`HwpOutlineCollector.collectHeading` doc-comment 참조).
    func collectOutline(from paragraph: CoreHwp.HwpParagraph, firstPage: Int) {
        // 상한에 걸린 쪽은 끝내 캐시되지 않는데 문단 배치는 한 쪽 더 진행되므로,
        // 안 막으면 **문서에 없는 쪽**을 가리키는 항목이 남는다. 다만 자르는 것은
        // **쪽 값마다 따로**다 (`collect`의 `maximumPage`) — 하나로 묶으면 상한
        // 쪽에서 시작해 걸치는 제목까지 버린다. 클램프가 아니라 버리는 근거는
        // 루트 `AGENTS.md`의 "개요·책갈피 탐색 (#77)".
        outlineCollector.collect(
            from: paragraph,
            // 개요 쪽은 문단의 **첫 조각이 놓인** 쪽이다 — 인자로 받은 사전
            // 포착값은 다단에서 낡는다 (`currentParagraphFirstPlacedPage` 참조).
            // 텍스트 블록이 하나도 없는 문단(개체만 있는 문단)은 기록이 없으므로
            // 그때만 사전 포착값으로 폴백한다. 진단(`collectUnsupported`)은 종전
            // 값을 그대로 쓴다 — 보고 문자열이고 공개 출력이라 별건이다.
            headingPage: currentParagraphFirstPlacedPage ?? firstPage,
            bookmarkPage: cachedPages.count + 1,
            maximumPage: maximumPages,
            childParagraphs: outlineChildParagraphs(of:context:)
        )
    }

    /// 진단 순회가 나르는 쪽 문맥 — 컨트롤이 **어디에 그려지는가**로 쪽이 갈린다
    /// (PR 리뷰). 인자 여럿 대신 한 값으로 묶어 재귀가 셋을 함께 내린다.
    struct UnsupportedPageContext {
        /// 부모 컨테이너(최상위는 문단)가 그려진 쪽 — 컨테이너가 콘텐츠로 그리는
        /// 자손의 쪽이기도 하다.
        var page: Int
        /// 컨테이너가 소비하지 않아 문단 끝 흐름으로 나가는 컨트롤의 쪽.
        /// `collectUnsupported`가 `appendControlBlocks` **뒤에** 돌므로 그 시점의
        /// `cachedPages.count + 1`이 곧 폴백이 놓인 쪽이다.
        var flowPage: Int
        /// 조각과 함께 놓인 **최상위** 컨트롤 서수 → 그 조각의 쪽.
        var placedPages: [Int: Int] = [:]
        /// 부모 컨테이너 문맥 (최상위는 `.none`).
        var parentContainer: HwpPaginator.ContainerContext = .none

        /// `ordinal`번째 컨트롤이 실제로 그려진 쪽.
        func page(of ctrl: CoreHwp.HwpCtrlId, ordinal: Int) -> Int {
            if let placed = placedPages[ordinal] {
                return placed
            }
            return HwpPaginator.rendersInsideParent(ctrl, container: parentContainer)
                ? page : flowPage
        }

        /// `ctrl` 안 문단을 훑을 때의 문맥 — 서수 공간이 바뀌므로 `placedPages`는 비운다.
        func inside(_ ctrl: CoreHwp.HwpCtrlId, page: Int) -> Self {
            Self(
                page: page,
                flowPage: flowPage,
                placedPages: [:],
                parentContainer: HwpPaginator.containerContext(of: ctrl)
            )
        }
    }

    /// `numbering`은 이 컨트롤들을 품은 문단의 번호 열쇠 (#158) — 컨테이너 안
    /// 문단마다 경로로 번호를 찾아 번호 문단 머리 진단(`collectUnsupportedNumberingHeading`)
    /// 을 같은 규칙으로 적용한다. 자식 서수는 컨트롤 없는 문단도 차지하므로
    /// `ctrlHeaderArray` 필터 **앞**에서 센다.
    func walkUnsupported(
        ctrls: [CoreHwp.HwpCtrlId],
        pages: UnsupportedPageContext,
        tableDepth: Int = 0,
        containerDepth: Int = 0,
        numbering: HwpNumberingScope? = nil
    ) {
        for (controlIndex, ctrl) in ctrls.enumerated() {
            // 앞 조각과 함께 놓인 개체는 문단 끝의 쪽(마지막 조각)이 아니라 그때 기록한
            // 쪽에 그려져 있다 (PR 리뷰) — 진단의 쪽이 렌더 쪽을 가리켜야 사용자가 그
            // 개체를 찾아갈 수 있다. 그 쪽은 **컨테이너가 콘텐츠로 그리는 자손**에만
            // 이어진다 (`rendersInsideParent`) — 컨테이너가 소비하지 않는 중첩 컨트롤
            // (OLE·수식·oleArray 품은 도형)은 `appendControlBlocks`가 마지막 조각 뒤
            // 흐름에 내므로 그 쪽은 `flowPage`다 (AGENTS.md "조각의 줄 앵커").
            let page = pages.page(of: ctrl, ordinal: controlIndex)
            if let element = unsupportedDetector.classify(ctrl: ctrl, page: page) {
                collectedUnsupported.append(element)
            }
            let isTable = if case .table = ctrl {
                true
            } else {
                false
            }
            // 렌더 경로 (HwpTableLayout)는 중첩 depth 3까지만 재귀 배치하므로
            // 그보다 깊은 중첩 표는 조용히 생략되는 대신 unsupported로 보고한다.
            if isTable, tableDepth > HwpTableLayout.maximumNestingDepth {
                collectedUnsupported.append(HwpUnsupportedElement(
                    kind: .placeholder,
                    page: page,
                    hint: "중첩 표 (깊이 \(HwpTableLayout.maximumNestingDepth) 초과)"
                ))
                continue
            }
            let children = Self.childParagraphs(of: ctrl).map(\.0)
            // 이 깊이에서 appendNestedControlBlocks가 자식 방출을 멈춘다 — 그 안의
            // 그림·도형·표·글상자가 조용히 사라지므로 진단으로 보고한다 (R72 #4).
            // 표는 자체 한도 (HwpTableLayout.maximumNestingDepth)와 전용 진단을
            // 쓰므로 제외한다 — 여기서 가로채면 위의 "중첩 표" 보고가 사라진다.
            if !isTable,
               containerDepth >= Self.maximumContainerDepth,
               children.contains(where: { !($0.ctrlHeaderArray ?? []).isEmpty })
            {
                collectedUnsupported.append(HwpUnsupportedElement(
                    kind: .placeholder,
                    page: page,
                    hint: "중첩 컨테이너 (깊이 \(Self.maximumContainerDepth) 초과)"
                ))
                continue
            }
            let container = numbering?.container(controlIndex: controlIndex)
            for (childIndex, nested) in children.enumerated() {
                let scope = container?.paragraph(childIndex: childIndex)
                collectUnsupportedNumberingHeading(from: nested, page: page, number: scope?.number)
                guard let nestedCtrls = nested.ctrlHeaderArray else { continue }
                walkUnsupported(
                    ctrls: nestedCtrls,
                    pages: pages.inside(ctrl, page: page),
                    tableDepth: isTable ? tableDepth + 1 : tableDepth,
                    containerDepth: containerDepth + 1,
                    numbering: scope
                )
            }
        }
    }

    /// 이 표가 세그먼트 상한에 걸려 **일부 행만 방출**됐다면 그 행 수.
    ///
    /// **인스턴스 id만으로 찾으면 안 된다.** "문서 내 각 개체에 대한 고유 아이디"라는
    /// 모델 doc과 달리 파서는 중복을 거부하지 않고 공개 기본값이 0이라, 잘린 표가
    /// 남긴 상한이 뒤의 **온전히 렌더된** 표에 적용돼 실제로 그려진 행의 책갈피가
    /// 조용히 사라진다 (실측: 잘린 3행 표 뒤 2행 표에서 2행 앵커가 목록에만 없다).
    /// id는 버킷을 좁히는 데만 쓰고 표 값으로 확정한다 — 잘린 표가 없는 정상
    /// 문서는 miss 한 번이라 깊은 비교를 하지 않는다.
    private func truncatedRowLimit(of table: CoreHwp.HwpTable) -> Int? {
        truncatedTableRowLimits[table.commonCtrlProperty.instanceId]?
            .first { $0.table == table }?.rowLimit
    }

    /// 탐색 목록 전용 순회 — 개체(gso 계열)는 **렌더되는 컴포넌트만** 본다.
    ///
    /// `childParagraphs`는 전 컴포넌트를 도는데 `HwpTextboxLayout`은 텍스트를 가진
    /// **첫** 컴포넌트만 그리므로, 그대로 쓰면 그려지지 않은 텍스트의 앵커가
    /// 목록에 올라 누르면 아무것도 없는 자리로 간다 (실측: 컴포넌트 2개 중 첫째만
    /// 렌더되는데 목록엔 둘 다). 진단·흐름 경로는 `childParagraphs`를 그대로
    /// 쓴다 — 그쪽은 "그려지지 않는 것"을 보고하는 것이 일이다.
    func outlineChildParagraphs(
        of ctrl: CoreHwp.HwpCtrlId,
        context: HwpOutlineCollector.RenderContext
    ) -> [HwpOutlineCollector.ChildParagraph] {
        // 각주는 **어디에 있든** `HwpFootnoteCoordinator`가 걷어 그리므로, 안
        // 그려지는 자리 안이라도 그 각주는 순회한다 (실측: 각주 안 글상자 속
        // 각주 텍스트가 렌더에 있는데 목록은 비어 있었다).
        switch ctrl {
        case .footnote, .endnote:
            return Self.childParagraphs(of: ctrl).map {
                HwpOutlineCollector.ChildParagraph(paragraph: $0.0, rendersText: true)
            }
        default:
            break
        }
        // 그 밖에는 아무것도 그려지지 않는 자리에서 더 내려가지 않는다.
        guard context.drawsAnything else { return [] }
        return switch ctrl {
        case let .table(table):
            // 배치가 거부한 셀(선언 격자 밖·occupancy 충돌)은 그려지지 않는다.
            // 세그먼트 상한에 걸려 방출되지 않은 행도 같다 — 배치는 받아들였지만
            // 페이지에 그려진 적이 없다.
            tableLayout.renderedCells(of: table, rowLimit: truncatedRowLimit(of: table))
                .flatMap(\.paragraphArray)
                .map { HwpOutlineCollector.ChildParagraph(paragraph: $0, rendersText: true) }
        case let .shape(shape),
             let .line(shape),
             let .rectangle(shape),
             let .ellipse(shape),
             let .arc(shape),
             let .polygon(shape),
             let .curve(shape),
             let .equation(shape),
             let .equationLegacy(shape),
             let .picture(shape),
             let .ole(shape),
             let .container(shape):
            // 수식 근사 텍스트로 그려지는 개체는 글상자 경로를 타지 않는다 —
            // 렌더 분기(`appendControlBlocks`)와 같은 판정을 공유한다.
            equationAttributedString(shape) != nil ? [] : objectChildParagraphs(
                of: ctrl, components: shape.shapeComponentArray, context: context
            )
        case let .genShapeObject(genShape):
            objectChildParagraphs(
                of: ctrl, components: genShape.shapeComponentArray, context: context
            )
        default:
            Self.childParagraphs(of: ctrl).map {
                HwpOutlineCollector.ChildParagraph(paragraph: $0.0, rendersText: true)
            }
        }
    }

    /// 이 컨트롤의 **전 컴포넌트가** 그려지는가.
    ///
    /// 부모가 표 셀·각주라는 것만으로는 모자란다 — `HwpParagraphObjectCollector`가
    /// 건너뛰는 컨트롤(수집 대상이 아닌 종류, OLE를 품은 컴포넌트)은 컨테이너
    /// 안에서도 **흐름 경로**가 그리고, 그쪽은 첫 컴포넌트만 본다. 판정을 그
    /// 수집기의 술어(`handledControl`·`collectible`)에서 그대로 파생시켜야
    /// 갈리지 않는다 (실측: OLE를 품은 개체를 셀에 넣으면 렌더는 첫 컴포넌트뿐인데
    /// 목록엔 둘 다 올랐다). 셀·각주 수집기는 `collectsTextboxes: true`로 부른다
    /// (`HwpTableLayout`·`HwpFootnoteLayout`).
    private func containerDrawsEveryComponent(_ ctrl: CoreHwp.HwpCtrlId) -> Bool {
        guard let (_, components) = HwpParagraphObjectCollector.handledControl(ctrl)
        else { return false }
        return HwpParagraphObjectCollector.collectible(components, collectsTextboxes: true)
    }

    /// 개체의 글상자 문단 — **문맥별 렌더 범위**를 그대로 따른다.
    ///
    /// - 컨테이너(표 셀·각주)가 그리는 개체: 전 컴포넌트의 텍스트가 그려진다.
    /// - **각주에서 수집기가 건너뛴 개체: 아무도 그리지 않는다** — 각주는
    ///   `appendNestedControlBlocks`를 부르지 않아 흐름 폴백이 없다 (실측: 각주 안
    ///   OLE 포함 개체의 글상자 텍스트가 렌더에 없는데 목록엔 앵커가 있었다).
    /// - 그 밖(흐름·표 셀의 폴백): 첫 글상자 컴포넌트의 **텍스트만** 그려지지만
    ///   중첩 컨트롤은 `appendNestedControlBlocks`가 전 컴포넌트에서 방출하므로,
    ///   나머지 컴포넌트도 **자식만** 따라가도록 남긴다 (실측: 둘째 컴포넌트 안
    ///   중첩 표는 그려지는데 그 셀 앵커가 빠졌다).
    private func objectChildParagraphs(
        of ctrl: CoreHwp.HwpCtrlId,
        components: [CoreHwp.HwpShapeComponent],
        context: HwpOutlineCollector.RenderContext
    ) -> [HwpOutlineCollector.ChildParagraph] {
        if context.containerDraws, containerDrawsEveryComponent(ctrl) {
            // 수집기가 그리지만 **컴포넌트마다 다르다** — 그림이 있는 컴포넌트는
            // 그림만 그리고 반환하므로 그 글상자는 그려지지 않는다
            // (`HwpParagraphObjectCollector.collect(component:)`).
            return components.flatMap { component in
                let draws = HwpParagraphObjectCollector.drawsTextbox(
                    component, collectsTextboxes: true
                )
                // 안 그려지는 글상자도 흐름 폴백이 있으면 **자식만** 따라간다.
                guard draws || context.hasFlowFallback else {
                    return [HwpOutlineCollector.ChildParagraph]()
                }
                return component.textBoxListArray.flatMap(\.paragraphArray).map {
                    HwpOutlineCollector.ChildParagraph(paragraph: $0, rendersText: draws)
                }
            }
        }
        // 수집기가 안 그리는 컨트롤은 흐름이 받는다 — 각주엔 그 폴백이 없다.
        guard context.hasFlowFallback else { return [] }
        let renderedIndex = HwpTextboxLayout.renderedTextboxComponentIndex(of: components)
        return components.enumerated().flatMap { index, component in
            component.textBoxListArray.flatMap(\.paragraphArray).map {
                HwpOutlineCollector.ChildParagraph(
                    paragraph: $0, rendersText: index == renderedIndex
                )
            }
        }
    }

    /// 개체의 글상자 문단 — **그려지는 컴포넌트만**.
    ///
    /// 그 범위가 문맥마다 다르다: 흐름에 놓인 개체는 `HwpTextboxLayout`이 텍스트를
    /// 가진 **첫** 컴포넌트만 그리지만, 표 셀·각주 안 개체는
    /// `HwpParagraphObjectCollector`가 **전 컴포넌트**를 그린다 (실측: 셀 안
    /// 컴포넌트 2개가 둘 다 렌더된다). 한쪽으로 통일하면 반드시 한 문맥이 틀린다 —
    /// 흐름 기준으로 좁히면 셀 안 뒤 컴포넌트의 앵커가 조용히 빠지고, 컨테이너
    /// 기준으로 넓히면 흐름 개체가 없는 자리를 가리킨다.
    private func renderedTextboxParagraphs(
        of components: [CoreHwp.HwpShapeComponent],
        allComponents: Bool
    ) -> [(CoreHwp.HwpParagraph, HwpBlockKind)] {
        let rendered: [CoreHwp.HwpShapeComponent] = if allComponents {
            components
        } else if let component = HwpTextboxLayout.renderedTextboxComponent(of: components) {
            [component]
        } else {
            []
        }
        return rendered
            .flatMap(\.textBoxListArray)
            .flatMap(\.paragraphArray)
            .map { ($0, HwpBlockKind.textbox) }
    }

    // MARK: - 컨트롤 블록 방출

    /// 컨테이너 문맥 — 컨테이너 레이아웃이 셀/글상자 콘텐츠로 그린 컨트롤의
    /// 페이지 흐름 재방출 억제에 쓴다 (R29 #1).
    enum ContainerContext {
        case none, tableCell, textbox
    }

    /// 문단에 붙은 컨트롤을 실제 레이아웃 엔진으로 방출한다.
    /// depth는 컨테이너 안 컨테이너 재귀 제한 (표 안 글상자 등).
    /// 셀 안 중첩 표는 HwpTableLayout이 이미 셀 안에 재귀 배치했으므로
    /// 별도 블록으로 방출하지 않는다.
    /// `numbering`은 이 문단의 번호 열쇠 (#158) — 표 셀·글상자·각주·머리말 안 문단이
    /// 컨트롤 서수·자식 서수로 자기 번호를 찾아 라벨을 전치한다. 최상위는
    /// `currentParagraphScope`, 중첩은 `appendNestedControlBlocks`가 내려 준다.
    /// `skipping`은 조각의 쪽에 이미 놓은 최상위 컨트롤 서수 (#164,
    /// `inlineControlsPlacedPerFragment`) — 개체 자체를 다시 내면 두 번 그려지므로, 그 안
    /// 문단의 미수집 컨트롤 흐름 폴백(`appendNestedControlBlocks`)만 종전 시점에 낸다.
    func appendControlBlocks(
        from paragraph: CoreHwp.HwpParagraph,
        depth: Int = 0,
        container: ContainerContext = .none,
        numbering: HwpNumberingScope? = nil,
        skipping: [Int: Int] = [:]
    ) {
        guard let ctrls = paragraph.ctrlHeaderArray else { return }
        for (ctrlIndex, ctrl) in ctrls.enumerated() {
            // 글줄 앞 표보다 앞선 쪽 장식은 표를 놓기 전에 등록됐다 (#190) — 되풀이하면
            // 쪽 감추기 마스크가 두 번 쌓인다.
            if depth == 0, chromeRegisteredBeforeText.contains(ctrlIndex) {
                continue
            }
            // 줄 중간 앵커 문맥은 본문 문단 (depth 0)에서만 유효하다.
            let anchorIndex = depth == 0 ? ctrlIndex : nil
            let children = numbering?.container(controlIndex: ctrlIndex)
            if skipping[ctrlIndex] != nil {
                appendNestedControlBlocks(of: ctrl, depth: depth, numbering: children)
                continue
            }
            // 컨테이너 안 개체 (그림/도형/글상자)는 컨테이너 레이아웃이 이미
            // 콘텐츠로 배치했다 — 페이지 흐름 블록으로 다시 방출하면 컨테이너
            // 밖 좌표에 그려지고 흐름을 밀어낸다 (noori 실측 3쪽).
            if container != .none, Self.rendersInsideContainer(ctrl, container: container) {
                // 렌더된 컨트롤이라도 자식 문단의 미수집 컨트롤 (글상자 안
                // 글상자 등)은 흐름 폴백을 유지한다.
                appendNestedControlBlocks(of: ctrl, depth: depth, numbering: children)
                continue
            }
            appendControlBlock(
                ctrl,
                anchorIndex: anchorIndex,
                depth: depth,
                container: container,
                numbering: children
            )
        }
    }

    /// 방금 놓인 **조각**의 줄에 앵커가 있는 글자처럼 취급 컨트롤을 그 조각의 쪽·단에
    /// 지금 놓는다 (#164).
    ///
    /// 쪽·단에 걸친 문단의 컨트롤은 문단의 모든 조각이 놓인 뒤 한 번에 방출된다 —
    /// 그때 앞 조각의 쪽은 이미 확정돼 (`cacheCurrentPage`가 줄 문맥을 비운다) 앵커를
    /// 못 찾은 표·개체가 마지막 조각 뒤 흐름 위치로 갔고, 절대 캐시 모드에서는 다음
    /// 문단이 캐시 y에 놓이므로 그 자리와 겹쳤다 (헌법주석 667쪽의 인용 표 3개).
    ///
    /// 여기서 놓는 것은 **이 조각의 줄에 앵커가 있는** 글자처럼 취급 컨트롤뿐이다 —
    /// 줄 안 자리가 곧 그 개체의 자리라 조각과 함께 확정할 수 있다. 앵커 없는 글자처럼
    /// 취급 개체(CT 줄 상한 밖·마커 없는 컨트롤), 자리 차지·글 앞뒤 개체, 쪽 크롬은
    /// 종전대로 마지막 조각 뒤 `appendControlBlocks`가 맡는다. 자리 차지 표를 조각별로
    /// 흘리면 앞 조각의 쪽 끝에서 넘쳐 한글에 없는 쪽이 생길 수 있는데, 코퍼스에 그
    /// 저작이 없어 (다중 run 문단의 컨트롤은 각주·찾아보기·이 글자처럼 취급 표 3개뿐)
    /// 한글의 자리를 실측할 수 없다. 놓은 서수는 `inlineControlsPlacedPerFragment`에
    /// 남겨 마지막 방출이 건너뛴다.
    ///
    /// 순회는 **이 조각의 앵커**(조각 줄에 그려진 마커)만 돈다 — 조각마다 컨트롤 전부를
    /// 훑으면 O(run × 컨트롤)이라 run·컨트롤이 각 10,000인 조작 문서가 페이지네이션을
    /// 세운다 (#95의 각주 조각 순회와 같은 이유). 앵커 합은 마커 수를 넘지 않는다.
    ///
    /// 두 가지는 조각에서 놓지 않고 마지막 조각 뒤로 남긴다: (1) 안에 각주·미주를 품은
    /// 개체 — 그 노트는 조각 단위 각주 귀속(#95)이 마지막 조각에서 걷어 그 쪽에 싣도록
    /// 미루므로, 개체만 앞 쪽에 놓으면 참조와 각주가 다른 쪽에 갈린다. (2) 줄 안 배치가
    /// 성립하지 않아 흐름 폴백으로 가는 개체(`appendInlineControlBlock` false) — 흐름
    /// 블록은 쪽·단을 넘길 수 있고, 조각 사이에서 넘기면 절대 캐시 run 루프가 다음
    /// 반복 머리에서 거의 빈 쪽을 확정한다.
    private func appendInlineControlBlocksForCurrentFragment(from paragraph: CoreHwp.HwpParagraph) {
        guard let ctrls = paragraph.ctrlHeaderArray, currentParagraphContext != nil else { return }
        let numbering = currentParagraphScope
        for ordinal in inlineAnchoredControlOrdinals()
            where ctrls.indices.contains(ordinal)
            && inlineControlsPlacedPerFragment[ordinal] == nil
            && Self.isTreatAsChar(ctrls[ordinal])
            && !Self.containsNotes(ctrls[ordinal])
        {
            if appendInlineControlBlock(
                ctrls[ordinal],
                controlIndex: ordinal,
                numbering: numbering.container(controlIndex: ordinal)
            ) {
                // 이 시점의 `cachedPages.count + 1`이 곧 이 조각의 쪽이다 — 흐름 분할은
                // `advanceColumn` **전**에, 절대 캐시 run은 다음 반복 머리의
                // `cacheCurrentPage` **전**에 여기를 부르고, 줄 안 배치 경로는 쪽을
                // 확정하지 않으므로 그 사이에 밀리지 않는다.
                inlineControlsPlacedPerFragment[ordinal] = cachedPages.count + 1
            }
        }
    }

    /// 방금 놓인 조각에 그려진 마지막 컨트롤 서수까지의 쪽 장식(머리말·꼬리말·쪽 번호 위치·
    /// 감추기)을 **이 쪽**에 등록한다 (#207 PR 리뷰). 등록은 문단 단위 방출(`appendControlBlocks`)이
    /// 마지막 조각 뒤에 하므로 나뉜 문단의 앞 조각 쪽에는 장식이 빠졌다 — 문두에 쪽 번호 위치
    /// 컨트롤을 둔 3줄 문단이 나뉘면 1쪽엔 번호가 없고 2쪽부터 `- 2 -`. 글줄 앞 표(#190)가 표의
    /// 첫 조각에서 하는 등록과 같은 기록(`chromeRegisteredBeforeText`)이라 뒤 방출이 되풀이하지
    /// 않는다. 조각 문자열은 방금 `appendBlock`이 낸 마지막 블록이다 — 흐름 분할·절대 캐시 run·
    /// 다단 캐시 run 모두 블록을 낸 직후 이 훅을 부른다.
    private func registerPageChromeForCurrentFragment(from paragraph: CoreHwp.HwpParagraph) {
        guard let ctrls = paragraph.ctrlHeaderArray,
              let fragment = currentBlocks.last?.attributedString,
              let last = HwpAbsoluteCachePlacer.lastControlOrdinal(in: fragment)
        else { return }
        registerPageChromePreceding(
            min(last + 1, ctrls.count), in: ctrls, numbering: currentParagraphScope
        )
    }

    /// 글자처럼 취급 컨트롤의 **줄 안 배치만** 시도한다 (#164) — 표 레이아웃 실패의
    /// 자리표시자, 데이터 없는 그림의 자리표시자, 안 문단의 중첩 컨트롤 흐름 방출처럼
    /// 흐름 커서를 움직이는 방출은 하지 않고 false를 돌려 마지막 조각 뒤 문단 단위
    /// 방출(`appendControlBlocks`)에 맡긴다. 중첩 컨트롤은 놓은 개체라도 그쪽이 낸다
    /// (`skipping` 분기). 앵커는 호출자가 이미 확인했으므로 여기서 내는 블록은 전부
    /// `appendInlineAnchoredTable`·`appendInlineAnchoredBlock`의 줄 안 블록이다.
    private func appendInlineControlBlock(
        _ ctrl: CoreHwp.HwpCtrlId,
        controlIndex: Int,
        numbering: HwpNumberingScope.Container?
    ) -> Bool {
        switch ctrl {
        case let .table(table):
            return appendInlineTableBlock(table, controlIndex: controlIndex, numbering: numbering)
        case let .genShapeObject(genShape):
            return appendInlineShapeObjectBlocks(
                components: genShape.shapeComponentArray,
                commonProperty: genShape.commonCtrlProperty,
                controlIndex: controlIndex,
                numbering: numbering
            )
        case let .shape(shape),
             let .line(shape),
             let .rectangle(shape),
             let .ellipse(shape),
             let .arc(shape),
             let .polygon(shape),
             let .curve(shape),
             let .equation(shape),
             let .equationLegacy(shape),
             let .picture(shape),
             let .ole(shape),
             let .container(shape):
            if appendEquationBlock(shape, controlIndex: controlIndex) {
                return true
            }
            return appendInlineShapeObjectBlocks(
                components: shape.shapeComponentArray,
                commonProperty: shape.commonCtrlProperty ?? CoreHwp.HwpCommonCtrlProperty(),
                controlIndex: controlIndex,
                numbering: numbering
            )
        default:
            return false
        }
    }

    /// 글자처럼 취급 표의 줄 안 블록 — 레이아웃이 실패하면 (자리표시자 폴백) 놓지 않는다.
    private func appendInlineTableBlock(
        _ table: CoreHwp.HwpTable,
        controlIndex: Int,
        numbering: HwpNumberingScope.Container?
    ) -> Bool {
        guard case let .success(frame) = layoutTable(table, numbering: numbering),
              appendInlineAnchoredTable(frame, table: table, controlIndex: controlIndex)
        else { return false }
        // 줄 안에 놓인 표 뒤의 표를 띠로 되감으면 문서 순서가 뒤집힌다 (#161).
        paragraphEntryFlow?.bandClosed = true
        return true
    }

    /// 글자처럼 취급 개체의 줄 안 블록들 — 그림 요소가 하나라도 BinData를 못 찾으면
    /// (`appendImageBlock`이 흐름 자리표시자를 내므로) 아무것도 내지 않고 false다.
    /// 나머지(글상자·차트·도형)는 앵커가 있으니 전부 줄 안 배치다.
    private func appendInlineShapeObjectBlocks(
        components: [CoreHwp.HwpShapeComponent],
        commonProperty: CoreHwp.HwpCommonCtrlProperty,
        controlIndex: Int,
        numbering: HwpNumberingScope.Container?
    ) -> Bool {
        let picturesHaveData = components.allSatisfy { component in
            guard let picture = component.pictureArray.first else { return true }
            let binItemId = picture.pictureProperty.map { UInt32($0.binItemId) }
                ?? picture.binaryDataId.map(UInt32.init)
            return binItemId.map { imageStore.data(forBinItemId: $0) != nil } ?? false
        }
        guard picturesHaveData else { return false }
        appendShapeObjectBlocks(
            components: components,
            commonProperty: commonProperty,
            controlIndex: controlIndex,
            numbering: numbering
        )
        return true
    }

    /// 컨트롤이 품은 문단(셀·글상자·자식) 어딘가에 각주·미주가 있는지 — 깊이 상한은
    /// 컨테이너 재귀 상한과 같다. 조각별 배치가 이런 개체를 마지막 조각 뒤로 남긴다.
    nonisolated static func containsNotes(_ ctrl: CoreHwp.HwpCtrlId, depth: Int = 0) -> Bool {
        guard depth < maximumContainerDepth else { return false }
        for (nested, _) in childParagraphSequence(of: ctrl) {
            for child in nested.ctrlHeaderArray ?? [] {
                switch child {
                case .footnote, .endnote:
                    return true
                default:
                    if containsNotes(child, depth: depth + 1) {
                        return true
                    }
                }
            }
        }
        return false
    }

    /// 글자처럼 취급(표 70 `treatAsChar`) 컨트롤인지 — `appendControlBlock`이 개체
    /// 경로로 보내는 종류만 본다 (표·묶음 개체·도형·그림·수식·OLE).
    static func isTreatAsChar(_ ctrl: CoreHwp.HwpCtrlId) -> Bool {
        switch ctrl {
        case let .table(table):
            table.commonCtrlProperty.propertyInfo.treatAsChar
        case let .genShapeObject(genShape):
            genShape.commonCtrlProperty.propertyInfo.treatAsChar
        case let .shape(shape),
             let .line(shape),
             let .rectangle(shape),
             let .ellipse(shape),
             let .arc(shape),
             let .polygon(shape),
             let .curve(shape),
             let .equation(shape),
             let .equationLegacy(shape),
             let .picture(shape),
             let .ole(shape),
             let .container(shape):
            shape.commonCtrlProperty?.propertyInfo.treatAsChar ?? false
        default:
            false
        }
    }

    /// `ctrl`이 품은 문단의 컨테이너 문맥 — 방출(`appendNestedControlBlocks`)과
    /// 진단(`walkUnsupported`)이 **같은 함수**를 봐야 두 축이 갈리지 않는다 (R29 #1).
    static func containerContext(of ctrl: CoreHwp.HwpCtrlId) -> ContainerContext {
        if case .table = ctrl {
            .tableCell
        } else if let (_, components) = HwpParagraphObjectCollector.handledControl(ctrl),
                  components.contains(where: { !$0.textBoxListArray.isEmpty })
        {
            .textbox
        } else {
            .none
        }
    }

    /// 이 컨트롤이 **부모 컨테이너 안에** 그려지는가 — 그렇다면 부모의 쪽이 곧 이
    /// 컨트롤의 쪽이고, 아니면 문단 끝 흐름 폴백의 쪽이다 (진단 쪽 판정, PR 리뷰).
    ///
    /// `appendControlBlocks`의 흐름 억제 분기 **둘**과 같은 술어여야 한다: 셀 안 중첩
    /// 표(`appendControlBlock`의 `container != .tableCell` 가드 — `handledControl`에
    /// `.table`이 없어 아래 술어만으로는 잡히지 않는다)와 `rendersInsideContainer`.
    static func rendersInsideParent(
        _ ctrl: CoreHwp.HwpCtrlId,
        container: ContainerContext
    ) -> Bool {
        if case .table = ctrl {
            return container == .tableCell
        }
        return rendersInsideContainer(ctrl, container: container)
    }

    /// 컨테이너 레이아웃 (HwpTableLayout/HwpTextboxLayout)이 컨테이너
    /// 콘텐츠로 이미 배치한 컨트롤인지 —
    /// HwpParagraphObjectCollector.collectible과 반드시 일치 (R29 #1).
    static func rendersInsideContainer(
        _ ctrl: CoreHwp.HwpCtrlId,
        container: ContainerContext
    ) -> Bool {
        guard let (_, components) = HwpParagraphObjectCollector.handledControl(ctrl) else {
            return false
        }
        return HwpParagraphObjectCollector.collectible(
            components, collectsTextboxes: container == .tableCell
        )
    }

    /// 컨트롤 하나를 종류별 레이아웃 경로로 방출한다 (appendControlBlocks 본문).
    private func appendControlBlock(
        _ ctrl: CoreHwp.HwpCtrlId,
        anchorIndex: Int?,
        depth: Int,
        container: ContainerContext,
        numbering: HwpNumberingScope.Container?
    ) {
        switch ctrl {
        case let .table(table):
            if container != .tableCell {
                appendTableBlocks(table, controlIndex: anchorIndex, numbering: numbering)
            }
            appendNestedControlBlocks(of: ctrl, depth: depth, numbering: numbering)
        case let .genShapeObject(genShape):
            appendShapeObjectBlocks(
                components: genShape.shapeComponentArray,
                commonProperty: genShape.commonCtrlProperty,
                controlIndex: anchorIndex,
                numbering: numbering
            )
            appendNestedControlBlocks(of: ctrl, depth: depth, numbering: numbering)
        case let .shape(shape),
             let .line(shape),
             let .rectangle(shape),
             let .ellipse(shape),
             let .arc(shape),
             let .polygon(shape),
             let .curve(shape),
             let .equation(shape),
             let .equationLegacy(shape),
             let .picture(shape),
             let .ole(shape),
             let .container(shape):
            // 수식 (eqed)은 EQEDIT 스크립트 근사 텍스트 우선 —
            // eqEdit이 없는 개체는 false를 돌려 기존 개체 경로로 간다
            if !appendEquationBlock(shape, controlIndex: anchorIndex) {
                appendShapeObjectBlocks(
                    components: shape.shapeComponentArray,
                    commonProperty: shape.commonCtrlProperty
                        ?? CoreHwp.HwpCommonCtrlProperty(),
                    controlIndex: anchorIndex,
                    numbering: numbering
                )
            }
            appendNestedControlBlocks(of: ctrl, depth: depth, numbering: numbering)
        case .header, .footer, .pageNumberPosition, .pageHide:
            pageChrome.register(ctrl, numbering: numbering)
        case .footnote, .endnote:
            // 각주/미주는 collectFootnotes(from:depth:)가 컨트롤 블록 방출 전에
            // 수집한다 (참조 위치 페이지 귀속).
            //
            // 각주 문단 안 개체는 형제 케이스처럼 appendNestedControlBlocks로
            // 흐름 방출하지 **않는다** — 각주 영역 안 콘텐츠라 흐름으로 내보내면
            // 본문 자리에 그려지고 흐름까지 밀어낸다 (한글.app 실측: 헌법주석
            // 883쪽 각주 29의 표는 각주 영역 안에 있다). `HwpFootnoteLayout`이
            // `HwpParagraphObjectCollector`로 담고 (#94), 그것이 담지 못하는
            // 컨트롤 (OLE·수식)은 walkUnsupported가 각주 문단까지 걸어
            // (childParagraphs) 진단으로 보고하므로 손실이 조용하지 않다.
            break
        default:
            break
        }
    }

    /// 컨테이너 문단 안에 중첩된 컨트롤 (표 셀 안 글상자/이미지 등)을 재귀 방출한다.
    /// `numbering`은 이 컨트롤이 품은 문단들의 번호 열쇠 (#158) — 자식 서수는
    /// 컨트롤 없는 문단도 차지하므로 `ctrlHeaderArray` 필터 **앞**에서 센다.
    func appendNestedControlBlocks(
        of ctrl: CoreHwp.HwpCtrlId,
        depth: Int,
        numbering: HwpNumberingScope.Container? = nil
    ) {
        guard depth < Self.maximumContainerDepth else { return }
        let container = Self.containerContext(of: ctrl)
        for (childIndex, (nested, _)) in Self.childParagraphs(of: ctrl).enumerated()
            where nested.ctrlHeaderArray != nil
        {
            appendControlBlocks(
                from: nested, depth: depth + 1, container: container,
                numbering: numbering?.paragraph(childIndex: childIndex)
            )
        }
    }

    // MARK: 표

    /// `numbering`은 이 표 컨트롤이 품은 셀 문단들의 번호 열쇠 (#158).
    func appendTableBlocks(
        _ table: CoreHwp.HwpTable,
        controlIndex: Int? = nil,
        numbering: HwpNumberingScope.Container? = nil
    ) {
        switch layoutTable(table, numbering: numbering) {
        case let .failure(element):
            collectedUnsupported.append(HwpUnsupportedElement(
                kind: element.kind,
                page: cachedPages.count + 1,
                hint: element.hint
            ))
            appendPlaceholderBlock(hint: element.hint)
        case let .success(frame):
            // 글자처럼 취급 표 (표 70): FFFC 앵커 라인 위치에 인라인 배치.
            // 줄 공간은 run delegate가 표 크기로 예약했으므로 흐름을 추가
            // 소비하지 않는다 (noori 실측: 캐시 줄 높이 = 표 높이).
            if table.commonCtrlProperty.propertyInfo.treatAsChar,
               appendInlineAnchoredTable(frame, table: table, controlIndex: controlIndex)
            {
                // 줄 안에 놓인 표의 셀 각주는 표가 그려지는 이 쪽에 담는다 — 띠·세그먼트
                // 경로와 같은 규약이다 (#164 리뷰). 문단 단위 수집은 표 셀을 건너뛰므로
                // (`includeTableCells: false`) 여기서 담지 않으면 그 각주가 통째로 빠진다.
                collectTableCellFootnotes(
                    cellsByRow: HwpTableLayout.cellRowIndex(for: table),
                    rows: nil,
                    numbering: numbering?.tableCells(of: table)
                )
                // 줄 안에 놓인 표 뒤의 표를 띠로 되감으면 문서 순서가 뒤집힌다 (#161).
                paragraphEntryFlow?.bandClosed = true
                return
            }
            // 글 앞/뒤로 표는 흐름 소비·페이지 분할 없이 기준+오프셋에 통째로
            // 둔다 (개체와 동일 경로) — 흐름 경로로 보내면 밀리고 잘린다 (#2).
            if appendFloatingTableIfNeeded(frame, table: table) {
                return
            }
            // 자리 차지 표는 저장본이 문단 글줄 **앞**에 비워 둔 띠에 놓는다 (#161).
            if appendBandedTableIfNeeded(
                frame, table: table, controlIndex: controlIndex, numbering: numbering
            ) {
                return
            }
            // 흐름(글줄 뒤)으로 간 표 뒤에는 띠를 닫는다 — 뒤 표가 그 위로 되감기면
            // 문서 순서와 그리는 순서가 뒤집힌다 (#161).
            paragraphEntryFlow?.bandClosed = true
            appendFlowTableSegments(
                frame, table: table, numbering: numbering, anchorsHorizontally: controlIndex != nil
            )
        }
    }

    /// 표를 흐름에 row 단위로 흘린다 — 글줄 뒤 흐름 배치(`appendTableBlocks`)와 글줄 앞
    /// 배치(`appendTablesPrecedingText`)가 같은 입력으로 부른다. 반환값은 첫 조각이 놓인
    /// 1-기반 쪽 (`appendTableSegments`).
    ///
    /// `anchorsHorizontally`는 자리 차지·어울림 표의 가로 자리를 앵커 규칙으로 잡을지다
    /// (#254, `flowTableOriginX`) — 최상위 문단의 표만 참이다. 글상자 안 문단의 표(컨테이너
    /// 경로, `controlIndex` nil)는 그 글상자의 기하를 모르는 채 본문 흐름에 놓이므로 앵커
    /// 기준(문단·단)이 엉뚱한 본문 문단을 가리킨다 — 종전대로 단 왼쪽에 둔다.
    @discardableResult
    private func appendFlowTableSegments(
        _ frame: HwpTableFrame,
        table: CoreHwp.HwpTable,
        numbering: HwpNumberingScope.Container?,
        margins: TableFlowMargins = .none,
        anchorsHorizontally: Bool
    ) -> Int? {
        appendTableSegments(
            frame,
            table: table,
            instanceId: table.commonCtrlProperty.instanceId,
            pageBreakMode: table.tableProperty.pageBreakMode,
            headerRowCount: HwpTableSplitter.repeatingHeaderRowCount(of: table),
            numbering: numbering,
            margins: margins,
            anchor: anchorsHorizontally
                && Self.anchorsFlowTableHorizontally(table.commonCtrlProperty)
                ? table.commonCtrlProperty : nil
        )
    }

    /// 자리 차지(위·아래 배치) 표를 문단 글줄 **앞**에 흐름으로 놓는다 (#190).
    ///
    /// 한컴오피스 한글 12.30은 세로 기준이 '문단'인 자리 차지 표를 그 문단의 글줄 위에
    /// 두고 글줄을 표 아래로 내린다 — 표가 단·쪽을 넘으면 뒤 조각이 다음 단 첫머리에
    /// 서고 글줄은 마지막 조각 아래를 따른다 (`line-shapes` 2단 실측: 1단 7행 / 2단
    /// 10행 뒤 `table anchor` 줄 = 캐시 `vertpos` 13386 = 위 여백 283 + 10행 12820 +
    /// 아래 여백 283). 절대 캐시 배치 문단은 캐시 간격이 곧 그 자리라 띠 판정
    /// (`appendBandedTableIfNeeded`, #161)이 맡고, 여기는 **흐름 배치** 문단만 본다 —
    /// 다단 밴드(절대 캐시 모드라도 흐름 배치)와 캐시 없는 문단이 그것이다. 두 경로의
    /// 갈림은 `absoluteCacheRuns(for:)` 하나가 소유한다.
    ///
    /// 표는 조각마다 위 바깥 여백 뒤에서 시작하고 아래 바깥 여백을 남긴다 (한글 실측 —
    /// 이어지는 단의 조각도 단 상단에서 위 여백만큼 내려 시작한다). 놓은 서수는
    /// `tablesPlacedBeforeText`에 남겨 문단 단위 방출이 건너뛰고, 그 뒤 표는 띠로
    /// 되감지 않는다 (`bandClosed`). 레이아웃에 실패한 표(자리표시자)는 종전대로 글줄
    /// 뒤 방출에 맡긴다. 컨테이너 안 문단은 이 경로를 지나지 않는다 — `processParagraph`
    /// 가 최상위 문단마다 한 번 부른다.
    private func appendTablesPrecedingText(from paragraph: CoreHwp.HwpParagraph) {
        let numbering = currentParagraphScope
        // 글줄이 쪽에 안 들어가 같은 문단을 다음 쪽에서 다시 처리하는 중이면 표는 이미
        // 놓였다 — 서수 기록은 그대로 두고 건너뛴다 (다시 놓으면 표가 두 번 그려진다).
        if tablesPlacedBeforeTextParagraph == numbering.path {
            paragraphEntryFlow?.bandClosed = !tablesPlacedBeforeText.isEmpty
            return
        }
        tablesPlacedBeforeTextParagraph = numbering.path
        tablesPlacedBeforeText = [:]
        chromeRegisteredBeforeText = []
        chromeScannedBefore = 0
        guard absoluteCacheRuns(for: paragraph) == nil,
              let ctrls = paragraph.ctrlHeaderArray
        else { return }
        // 취소된 로드가 표를 많이 품은 문단을 처리 중이면 남은 표의 레이아웃을 돌리지 않는다 —
        // 조각 루프는 자기 취소를 보지만 이 루프가 이어 돌면 교체 로드가 그만큼 늦는다 (PR 리뷰).
        for (ordinal, ctrl) in ctrls.enumerated() where !Task.isCancelled {
            guard case let .table(table) = ctrl,
                  Self.precedesParagraphText(table.commonCtrlProperty),
                  case let .success(frame) = layoutTable(
                      table, numbering: numbering.container(controlIndex: ordinal)
                  )
            else { continue }
            // 표보다 앞선 쪽 장식(머리말·꼬리말·쪽 번호 위치·감추기)은 표의 **첫 조각이 놓이는
            // 순간** 등록한다 — 종전 순서(서수 순 등록 뒤 표 흐름)를 지켜 표의 첫 쪽부터 장식이
            // 실린다 (PR 리뷰: 쪽 번호 컨트롤 뒤 10행 표에서 첫 쪽 번호가 빠지고 둘째 쪽이 `- 2 -`).
            // 놓기 **전**에 등록하면 첫 행이 안 들어가 쪽을 넘길 때 문단이 없는 앞 쪽이 그
            // 장식으로 확정된다 (PR 리뷰 2). 표 뒤의 장식은 종전대로 글줄 뒤 방출이 등록한다.
            pendingChromeRegistration = PendingChromeRegistration(
                tableOrdinal: ordinal, controls: ctrls, numbering: numbering
            )
            // 진단이 보고할 쪽은 표의 첫 조각이 **실제로 놓인** 쪽이다 — 조각을 내기 전에
            // 단·쪽을 넘길 수 있으므로 놓기 전 값이 아니라 방출이 돌려준 값을 쓴다 (PR 리뷰).
            let firstSegmentPage = appendFlowTableSegments(
                frame,
                table: table,
                numbering: numbering.container(controlIndex: ordinal),
                margins: TableFlowMargins(outerMargins: table.commonCtrlProperty.marginArray),
                anchorsHorizontally: true
            )
            pendingChromeRegistration = nil
            // 조각을 하나도 안 낸 표(행 없는 표)는 놓인 것이 아니다 — 기록하면 글줄 앞에 아무것도
            // 없는데 문단 위 간격을 걷고 띠를 닫는다 (PR 리뷰). 종전 경로가 그대로 처리한다.
            guard let firstSegmentPage else { continue }
            paragraphEntryFlow?.bandClosed = true
            tablesPlacedBeforeText[ordinal] = firstSegmentPage
        }
    }

    /// 이번 `processParagraph` 호출이 글줄 앞 표(#190)를 이미 놓은 같은 문단의 재시도인지 —
    /// 글줄이 쪽에 안 들어가 `placeParagraphText`가 false를 돌려 다음 쪽에서 다시 처리하는
    /// 경우다. 표를 놓지 않은 문단의 재시도는 종전대로 (새 번호 지정 반복이 무해하다 —
    /// 아직 아무 번호도 소비되지 않았다).
    private var isRetryingParagraphWithPlacedTables: Bool {
        !tablesPlacedBeforeText.isEmpty
            && tablesPlacedBeforeTextParagraph == currentParagraphScope.path
    }

    /// `ordinal`보다 앞선 쪽 장식 컨트롤 가운데 아직 등록하지 않은 것을 서수 순으로 등록한다
    /// (#190). 등록한 서수는 `chromeRegisteredBeforeText`에 남아 글줄 뒤 방출이 건너뛴다.
    private func registerPageChromePreceding(
        _ ordinal: Int, in ctrls: [CoreHwp.HwpCtrlId], numbering: HwpNumberingScope
    ) {
        // 앞 표가 훑은 서수는 다시 보지 않는다 — 표는 서수 순으로 놓이므로 커서는 단조다.
        let start = min(chromeScannedBefore, ordinal)
        defer { chromeScannedBefore = max(chromeScannedBefore, ordinal) }
        for index in start ..< ordinal {
            switch ctrls[index] {
            case .header, .footer, .pageNumberPosition, .pageHide:
                pageChrome.register(ctrls[index], numbering: numbering.container(controlIndex: index))
                chromeRegisteredBeforeText.insert(index)
            default:
                continue
            }
        }
    }

    /// 문단 글줄 **앞**에 놓이는 자리 차지 표인지 — 글자처럼 취급이 아니고, 배치 방식이
    /// 자리 차지(위·아래)이며, 세로 기준이 '문단'이고 세로 오프셋이 0인 표 (#161·#190).
    /// 실측한 것은 이 조합뿐이다 — 어울림(`square`)은 한글이 표 **옆**으로 글을 흘리고
    /// (`consumesFlow`는 둘과 미지 값(nil)을 함께 담으므로 그것으로 게이트하면 안 된다),
    /// 오프셋이 있으면 저작이 자리를 직접 지정한 것이다. 바깥 여백 넷이 있어야 위·아래
    /// 몫을 읽을 수 있다. 띠 판정(`floatingTableBand`)과 흐름 배치
    /// (`appendTablesPrecedingText`)가 **같은 술어**를 본다.
    static func precedesParagraphText(_ property: CoreHwp.HwpCommonCtrlProperty) -> Bool {
        let info = property.propertyInfo
        return !info.treatAsChar
            && info.textWrap == .topAndBottom
            && info.verticalRelativeTo == .paragraph
            && property.verticalOffset == 0
            && property.marginArray.count == 4
    }

    /// 본문 표의 레이아웃 — `appendTableBlocks`와 조각별 줄 안 배치(#164)가 같은 입력으로
    /// 부른다. 어느 배치 방식이든 저작 폭을 단 폭으로 자르지 않는다 (#254 — 한글은 넓은 표를
    /// 넘겨 그린다, `HwpTableLayout.resolvedWidths`). 글자처럼 취급 표는 줄 예약
    /// (`inlineTableHeights`, #214)이 먼저 잰 결과를 메모에서 다시 쓴다. `columnWidth`는 특정 단의
    /// 폭으로 잴 때 준다 (다단 캐시 run의 낡은 캐시 판정, #214 PR 리뷰) — 가용 폭과 크기 해석기가
    /// 모두 그 단의 것이라, 그 단에서 배치가 조판할 표와 같다 (메모도 그대로 이어받는다).
    private func layoutTable(
        _ table: CoreHwp.HwpTable,
        numbering: HwpNumberingScope.Container?,
        columnWidth: CGFloat? = nil
    ) -> Result<HwpTableFrame, HwpUnsupportedElement> {
        let width = columnWidth ?? currentColumnFrame.width
        let sizeResolver = columnWidth.map { objectSizeResolver(columnWidth: $0) }
            ?? objectSizeResolver
        let key = inlineTableFrameKey(
            for: table, numbering: numbering, availableWidth: width, sizeResolver: sizeResolver
        )
        if let key, let frame = inlineTableFrames.frame(for: key, owner: currentParagraphScope.path) {
            return .success(frame)
        }
        let result = tableLayout.layout(
            table: table,
            availableWidth: width,
            index: index,
            sizeResolver: sizeResolver,
            numbering: numbering
        )
        if let key, case let .success(frame) = result {
            inlineTableFrames.store(frame, for: key, owner: currentParagraphScope.path)
        }
        return result
    }

    /// 문단의 글자처럼 취급 표가 **이 단에** 그려질 높이 (controlIndex → pt) — 줄 예약이 저작
    /// 높이 대신 쓴다 (#214). 배치(`appendInlineAnchoredTable`)와 같은 `layoutTable`·같은
    /// 높이(`flowBlockHeight`)라 예약과 그림이 갈리지 않는다. 조판이 실패한 표는 싣지 않는다
    /// — 저작 높이 예약이 남고, 실패 보고는 배치가 한다.
    func inlineTableHeights(for paragraph: CoreHwp.HwpParagraph) -> [Int: CGFloat] {
        guard let ctrls = paragraph.ctrlHeaderArray else { return [:] }
        let scope = currentParagraphScope
        var heights: [Int: CGFloat] = [:]
        // 취소된 로드는 남은 표를 조판하지 않는다 (`appendTablesPrecedingText`와 같은 이유).
        for (ordinal, ctrl) in ctrls.enumerated() where !Task.isCancelled {
            guard case let .table(table) = ctrl,
                  table.commonCtrlProperty.propertyInfo.treatAsChar,
                  case let .success(frame) = layoutTable(
                      table, numbering: scope.container(controlIndex: ordinal)
                  )
            else { continue }
            heights[ordinal] = frame.flowBlockHeight
        }
        return heights
    }

    /// `layoutTable`이 메모를 쓸 열쇠 — 문단 경로가 있는 글자처럼 취급 표만 (줄 예약과 배치가
    /// 같은 표를 두 번 조판하는 경우뿐이다).
    func inlineTableFrameKey(
        for table: CoreHwp.HwpTable,
        numbering: HwpNumberingScope.Container?,
        availableWidth: CGFloat,
        sizeResolver: HwpObjectSizeResolver
    ) -> InlineTableFrameMemo.Key? {
        guard let numbering, table.commonCtrlProperty.propertyInfo.treatAsChar else { return nil }
        return InlineTableFrameMemo.Key(
            hostPath: numbering.hostPath,
            controlIndex: numbering.controlIndex,
            availableWidth: availableWidth,
            sizeResolver: sizeResolver
        )
    }

    /// 다단 캐시 run(`placeCachedColumnRuns`)의 글자처럼 취급 표가 그려질 높이 (controlIndex → pt) —
    /// 표를 실은 캐시 줄이 속한 run의 **단 폭**에서 잰다 (#214 PR 리뷰). 표는 그 단에 놓여 그 폭으로
    /// 조판되므로(`appendInlineAnchoredTable`) 문단을 잰 첫 단의 폭으로 재면, 폭 기준이 단·문단이라
    /// 표 폭이 그 단 폭 100%를 따르는(#254) 비등폭 단에서 신선한 캐시를 낡았다고 오판한다. 줄 위치를 못 푸는 표는 run들의 단
    /// 폭 가운데 가장 낮게 나오는 높이다 — 어느 단인지 모를 때 캐시를 버리는 쪽으로 기울지 않는다.
    func columnRunInlineTableHeights(
        for paragraph: CoreHwp.HwpParagraph,
        runs: [[CoreHwp.HwpParaLineSegInternal]]
    ) -> [Int: CGFloat] {
        guard let ctrls = paragraph.ctrlHeaderArray else { return [:] }
        let hosts = HwpParagraphLayout.controlHostSegments(of: paragraph)
        // run은 세그먼트를 순서대로 나눈 것이다 — 세그먼트 색인 → run(단) 색인.
        let runOfSegment = runs.indices.flatMap { Array(repeating: $0, count: runs[$0].count) }
        let runColumns = columnFrames.prefix(runs.count)
        let scope = currentParagraphScope
        var heights: [Int: CGFloat] = [:]
        for (ordinal, ctrl) in ctrls.enumerated() where !Task.isCancelled {
            guard case let .table(table) = ctrl,
                  table.commonCtrlProperty.propertyInfo.treatAsChar
            else { continue }
            let hostColumn = hosts?[ordinal]
                .flatMap { runOfSegment.indices.contains($0) ? runOfSegment[$0] : nil }
                .flatMap { runColumns.indices.contains($0) ? runColumns[$0] : nil }
            let candidates = hostColumn.map { [$0] } ?? Array(runColumns)
            let laidOut = candidates.compactMap { column -> CGFloat? in
                guard case let .success(frame) = layoutTable(
                    table, numbering: scope.container(controlIndex: ordinal),
                    columnWidth: column.width
                ) else { return nil }
                return frame.flowBlockHeight
            }
            heights[ordinal] = laidOut.min()
        }
        return heights
    }

    /// 조각이 줄을 잰 단과 폭이 다른 단에 놓일 때, 조각에 든 글자처럼 취급 표 마커의 예약
    /// 높이를 **그 단에서** 그려질 높이로 다시 잡은 사본 (#214) — 폭 기준이 단·문단이면 표 폭이
    /// 그 단 폭 100%를 따라(#254 — 절대 폭 표는 단과 무관하다) 셀 줄바꿈이 달라져 높이가 바뀌는데, 배치(`appendInlineAnchoredTable`)는
    /// 놓이는 단의 폭으로 표를 조판한다. 폭 예약을 다시 푸는 `rescaledForColumn`과 짝이다.
    ///
    /// 폭도 그 단에서 그려질 바깥 폭으로 다시 잡는다 (#254 PR 리뷰) — `rescaledForColumn`은
    /// 상대 기준 표를 기준 폭 100%로만 다시 푸는데, 레이아웃(`HwpTableLayout.resolvedWidths`)은
    /// 칸이 1pt 하한에 걸리면 그보다 넓게 그린다(`coveringWidth`). 예약이 그리는 폭보다 좁으면 표가
    /// 뒤 글자를 덮고 앵커가 그려진 표와 갈린다. 여기 오는 마커는 줄을 잰 단에서 이미 예약을 받은
    /// 표뿐이므로(빌더는 `reservedWidth`가 nil인 표를 예약하지 않는다) 조건 없이 그 단에서 그려질
    /// 폭을 싣는다 — 목적 단의 기준 폭이 1pt로 접혀 저작 폭을 풀 수 없으면 레이아웃은 가용 폭으로
    /// 그리는데, 다시 푼 예약은 1pt다.
    func rescaledInlineTableHeights(_ fragment: NSAttributedString) -> NSAttributedString {
        guard sections.indices.contains(nextSectionIndex),
              sections[nextSectionIndex].paragraph.indices.contains(nextParagraphIndex),
              let ctrls = sections[nextSectionIndex].paragraph[nextParagraphIndex].ctrlHeaderArray
        else { return fragment }
        let scope = currentParagraphScope
        var outerHeights: [Int: CGFloat] = [:]
        var outerWidths: [Int: CGFloat] = [:]
        for ordinal in HwpInlineObjectReservation.reservedMarkerControlIndices(in: fragment)
            where ctrls.indices.contains(ordinal)
        {
            guard case let .table(table) = ctrls[ordinal],
                  table.commonCtrlProperty.propertyInfo.treatAsChar,
                  case let .success(frame) = layoutTable(
                      table, numbering: scope.container(controlIndex: ordinal)
                  )
            else { continue }
            let margins = HwpObjectAnchorGeometry.OuterMargins(table.commonCtrlProperty)
            outerHeights[ordinal] = frame.flowBlockHeight + margins.vertical
            outerWidths[ordinal] = frame.outerFrame.width + margins.horizontal
        }
        return HwpInlineObjectReservation.withReservedHeights(
            fragment, outerHeights: outerHeights, outerWidths: outerWidths
        )
    }

    /// 글자처럼 취급 표를 앵커 라인 위치에 배치한다. 앵커가 없으면 false
    /// (호출자가 flow 배치로 폴백 — 라인 분할된 문단 등).
    private func appendInlineAnchoredTable(
        _ frame: HwpTableFrame,
        table: CoreHwp.HwpTable,
        controlIndex: Int?
    ) -> Bool {
        // 줄 앵커는 바깥 상자(표 + 바깥 여백)의 원점이다 — 표는 왼쪽·위쪽 여백만큼 안 (#193).
        guard let position = inlineObjectPosition(
            for: controlIndex, margins: .init(table.commonCtrlProperty)
        ) else { return false }
        // 줄 예약(`inlineTableHeights`, #214)과 같은 높이 — 둘이 갈리면 표가 다음 줄을 덮는다.
        let height = frame.flowBlockHeight
        currentBlocks.append(AnyHwpBlock(
            frame: CGRect(
                x: position.x,
                y: position.y,
                width: frame.outerFrame.width,
                height: height
            ),
            kind: .table,
            payload: .table(frame),
            source: HwpBlockSource(controlInstanceId: table.commonCtrlProperty.instanceId)
        ))
        bandHasNonTextContent = true
        return true
    }

    /// 글 앞/뒤로 표 (behindText/inFrontOfText)를 기준+오프셋 위치에 통째로
    /// 배치한다 (흐름 소비·페이지 분할 없음 — 일반 개체 appendFloatingBlock과
    /// 동일 경로). 흐름을 소비하는 wrap (square/topAndBottom)이거나 treatAsChar면
    /// false를 반환해 호출자가 흐름 분할 경로 (appendTableSegments)로 폴백한다 (#2).
    private func appendFloatingTableIfNeeded(
        _ frame: HwpTableFrame,
        table: CoreHwp.HwpTable
    ) -> Bool {
        let info = table.commonCtrlProperty.propertyInfo
        guard !info.treatAsChar,
              !HwpParagraphObjectCollector.consumesFlow(info) else { return false }
        let height = frame.flowBlockHeight
        appendFloatingBlock(
            ObjectBlockSpec(
                kind: .table,
                size: CGSize(width: frame.outerFrame.width, height: height),
                payload: .table(frame),
                attributedString: nil,
                instanceId: table.commonCtrlProperty.instanceId,
                zOrder: table.commonCtrlProperty.zOrder
            ),
            commonProperty: table.commonCtrlProperty
        )
        return true
    }

    /// 문단 진입 시점의 흐름 위치·페이지·단을 잡아 둔다 — 자리 차지 표의 띠 판정
    /// 기준점이다 (#161). 구역·단 정의를 반영한 **뒤**에 불러야 한다.
    func beginParagraphEntryFlow(for _: CoreHwp.HwpParagraph) {
        paragraphEntryFlow = ParagraphEntryFlow(
            top: currentColumnFrame.minY + contentHeightUsed,
            pageIndex: cachedPages.count,
            columnFrame: currentColumnFrame,
            precedingSpacingBottom: lastPlacedSpacingBottom
        )
    }

    /// 다음 문단의 띠 계산에 넘길 저작 아래 간격 — **이 문단을 캐시로 배치했을 때만**
    /// 넘긴다 (#161). 흐름 배치는 `paragraphHeight`(= `totalHeight`, CT가
    /// `paragraphSpacing`으로 담는다)로 커서를 전진시켜 그 여백을 이미 소비했으므로,
    /// 넘기면 같은 몫이 두 번 빠져 유효한 띠가 좁다고 오판된다.
    func recordSpacingBottomForNextBand(of paragraph: CoreHwp.HwpParagraph) {
        lastPlacedSpacingBottom = paragraphEntryFlow?.placedFromCache == true
            ? authoredAfterGap(of: paragraph)
            : 0
    }

    /// 저작 문단 위 간격 (표 43 `paragraphSpacingTop`의 절반, pt). 흐름 배치는 텍스트
    /// 앞에서 커서로 소비하고(`placeFlowParagraph` — 글줄 앞에 자리 차지 표를 놓은 문단은
    /// 쓰지 않는다, #190), 절대 캐시 배치는 한글이 준 줄 위치에 이미 담겨 있다.
    func authoredBeforeGap(of paragraph: CoreHwp.HwpParagraph) -> CGFloat {
        index.paraShape(for: paragraph).map {
            max(0, HwpUnits.points(fromHwpUnit: $0.paragraphSpacingTop) / 2)
        } ?? 0
    }

    /// 저작 문단 아래 간격 (표 43 `paragraphSpacingBottom`의 절반, pt). 절대 캐시
    /// 블록 높이는 줄 위치·높이만 보므로 이 몫은 **다음 문단 캐시 줄까지의 간격**에
    /// 남는다 — 띠 판정이 앞 문단 몫으로 빼야 한다 (#161).
    func authoredAfterGap(of paragraph: CoreHwp.HwpParagraph) -> CGFloat {
        index.paraShape(for: paragraph).map {
            max(0, HwpUnits.points(fromHwpUnit: $0.paragraphSpacingBottom) / 2)
        } ?? 0
    }

    /// 흐름으로 흘리는 표 조각의 위·아래 바깥 여백 (pt, 표 70 `marginArray`의 위·아래 몫).
    /// 조각마다 위 여백 뒤에서 시작하고 아래 여백을 남긴다 — 이어지는 단·쪽의 조각도
    /// 단 상단에서 위 여백만큼 내려 시작하며, 아래 여백은 적합 판정에 든다 (한글 12.30
    /// 실측 #190: 아래 여백 6pt에서 7행째가 남은 공간 5.05pt에 들어가지 않아 다음 단으로
    /// 갔다). 글줄 뒤 흐름 배치(종전 경로)는 여백을 실측하지 않아 `none`으로 부른다.
    struct TableFlowMargins {
        let top: CGFloat
        let bottom: CGFloat

        static let none = TableFlowMargins(top: 0, bottom: 0)

        init(top: CGFloat, bottom: CGFloat) {
            self.top = top
            self.bottom = bottom
        }

        /// 표 70 바깥 여백 (왼쪽·오른쪽·위쪽·아래쪽) — 넷이 아니면 여백 없음.
        init(outerMargins: [CoreHwp.HWPUNIT16]) {
            guard outerMargins.count == 4 else {
                self = .none
                return
            }
            top = max(0, HwpUnits.points(fromHwpUnit16: outerMargins[2]))
            bottom = max(0, HwpUnits.points(fromHwpUnit16: outerMargins[3]))
        }

        var total: CGFloat {
            top + bottom
        }
    }

    /// 자리 차지 표가 놓일 띠 — 문단 진입 흐름 위치 기준 오프셋과 아래 바깥 여백.
    private struct FloatingTableBand {
        /// 표 블록을 놓을 `contentHeightUsed` 값 (띠 상단 + 위쪽 바깥 여백)
        let contentTop: CGFloat
        /// 표 아래 바깥 여백 — 흐름 커서를 이만큼 더 내린다
        let bottomMargin: CGFloat
    }

    /// 띠 판정의 허용 오차 (pt). 캐시 간격과 요구량이 **정확히 같은** 것이 실물이라
    /// (`numbering-sequence`: 1848 = 1282 + 283 × 2) HWPUNIT → pt 나눗셈의 이진
    /// 반올림만 흡수한다.
    private static let floatingBandTolerance: CGFloat = 0.01

    /// 자리 차지(위·아래 배치) 표를 저장본이 문단 글줄 **앞**에 비워 둔 띠에 놓는다 (#161).
    ///
    /// 한컴오피스 한글 12.30이 저장한 문서에서 세로 기준이 '문단'인 자리 차지 표는
    /// 그 문단의 글줄 **위**에 놓이고 문단의 자기 줄은 표 높이 + 위·아래 바깥 여백만큼
    /// 내려간다. 그 결정은 줄 캐시에 남아 있다 — 문단 진입 시점의 흐름 위치와 문단
    /// 줄 위치 사이의 간격이 곧 표가 들어갈 띠다. 그래서 **절대 캐시 모드에서만**
    /// 판정한다: 캐시가 곧 오라클이고, 뒤 문단의 y도 캐시로 고정돼 있어 표를 글줄
    /// 뒤에 두면 그 자리가 이미 다음 내용의 자리다 (이 이슈의 겹침).
    ///
    /// 캐시가 없는 흐름 배치는 규칙이 미실측이라 손대지 않는다 — 그쪽 간격은 문단 위
    /// 간격(`beforeGap`)이라 작은 표가 우연히 조건에 걸릴 수 있다. 그래서 문서 전체
    /// 판정인 `absoluteCacheMode`가 아니라 **이 문단이 캐시로 배치됐는지**를 본다
    /// (`ParagraphEntryFlow.placedFromCache`). 2007 계열 저장본은 표를 글줄 **뒤**에
    /// 두는데(헌법주석 구역 22 문단 201·구역 25 문단 45: 간격 0), 그런 문서는 간격이
    /// 요구량에 못 미쳐 자연히 이 경로를 타지 않는다.
    ///
    /// 한 문단에 조건을 만족하는 표가 여럿이면 띠를 **나눠** 쓴다 — 앞 표가 쓴 자리는
    /// `bandUsed`에 남고 다음 표는 그 아래 남은 띠만 본다 (안 들어가면 흐름 배치).
    private func appendBandedTableIfNeeded(
        _ frame: HwpTableFrame,
        table: CoreHwp.HwpTable,
        controlIndex: Int?,
        numbering: HwpNumberingScope.Container?
    ) -> Bool {
        // 컨테이너 안(글상자·셀) 문단의 표는 앵커 문맥이 없다 (depth > 0이면
        // controlIndex가 nil) — 바깥 문단의 캐시 간격은 그 표의 자리가 아니다.
        guard controlIndex != nil,
              let band = floatingTableBand(for: table.commonCtrlProperty, frame: frame)
        else { return false }
        collectTableCellFootnotes(
            cellsByRow: HwpTableLayout.cellRowIndex(for: table),
            rows: nil,
            numbering: numbering?.tableCells(of: table)
        )
        // 흐름 커서를 띠로 되돌려 표를 놓고, 커서는 원래 자리와 표 아래 자리 중
        // 아래쪽으로 되돌린다 — 문단 글줄은 이미 캐시 자리에 놓였으므로 커서가
        // 표 때문에 뒤로 가면 안 된다. 블록 배열 순서는 그대로다 (문서 순서 =
        // 선택·복사 순서).
        let resumed = contentHeightUsed
        contentHeightUsed = band.contentTop
        appendTableSegmentBlock(
            rows: frame.rows,
            original: frame,
            instanceId: table.commonCtrlProperty.instanceId,
            anchor: table.commonCtrlProperty
        )
        paragraphEntryFlow?.bandUsed = contentHeightUsed + band.bottomMargin
        contentHeightUsed = max(resumed, contentHeightUsed + band.bottomMargin)
        markBandUsage()
        return true
    }

    /// 표가 들어갈 띠를 캐시 간격에서 찾는다 — 조건에 안 맞으면 nil (기존 흐름 배치).
    private func floatingTableBand(
        for property: CoreHwp.HwpCommonCtrlProperty,
        frame: HwpTableFrame
    ) -> FloatingTableBand? {
        // 대상 표의 술어는 `precedesParagraphText` 하나다 (#190과 공유).
        guard Self.precedesParagraphText(property),
              let entry = paragraphEntryFlow,
              entry.placedFromCache,
              !entry.bandClosed,
              entry.pageIndex == cachedPages.count,
              entry.columnFrame == currentColumnFrame
        else { return nil }
        let margins = TableFlowMargins(outerMargins: property.marginArray)
        // 적합성은 **실제로 방출할 블록 높이**로 잰다 — `appendTableSegmentBlock`과 같은
        // `segmentFrame`을 쓴다. `rowFrame.maxY` 최댓값은 셀 간격(표 76 `cellSpacing`)이
        // 있는 표에서 첫 행 앞 간격 한 칸을 더 담는데 방출은 그것을 0으로 정규화하므로,
        // 그대로 쓰면 들어가는 표를 거부해 글줄 뒤로 보내고 뒷 내용을 덮는다.
        guard let emitted = HwpTableSplitter.segmentFrame(
            rows: frame.rows, original: frame, repeatedHeaderRows: []
        ) else { return nil }
        let height = emitted.outerFrame.height
        // 띠는 **앞 문단의 아래 간격** 뒤에서 시작한다 — 그 여백은 앞 문단이 의도한 것이고
        // 캐시 줄 위치에 이미 들어 있다. 이 문단의 위 간격은 빼지 않는다 (한글은 자리 차지
        // 표를 품은 문단의 위 간격을 쓰지 않는다 — #190 실측; 빼면 그런 문단의 띠가 좁다고
        // 오판돼 표가 글줄 뒤로 밀린다). 같은 문단의 앞 표가 쓴 자리가 있으면 그 아래부터다.
        let bandTop = entry.bandUsed.map { currentColumnFrame.minY + $0 }
            ?? (entry.top + entry.precedingSpacingBottom)
        let gap = paragraphAnchorTop - bandTop
        guard gap + Self.floatingBandTolerance >= height + margins.total else {
            return nil
        }
        return FloatingTableBand(
            contentTop: bandTop - currentColumnFrame.minY + margins.top,
            bottomMargin: margins.bottom
        )
    }

    /// 표를 남은 공간에 맞춰 row 단위로 잘라 페이지에 흘린다.
    /// 분할 플랜 (세그먼트 row·절단 기하)은 HwpTableSplitter가 순수 함수로
    /// 산출하고, 이 루프는 페이지 확정 (advanceColumn)·블록 방출만 담당한다.
    ///
    /// - 쪽 경계 나눔이 없으면 (표 76 bits 0-1 == 0) 표를 통째로 두고, 남은
    ///   공간에 안 맞으면 새 페이지로 넘긴다.
    /// - row 하나가 빈 페이지보다 크면 남은 높이에서 잘라 아래쪽을 이월한다.
    /// - headerRowCount > 0이면 (표 76 bit 2) 이어지는 세그먼트마다 제목 행을 복제한다.
    /// - `margins`는 조각마다 위 바깥 여백 뒤에서 시작하고 아래 바깥 여백을 남기는 몫이다
    ///   (#190, `TableFlowMargins`) — 적합 판정도 두 여백을 뺀 높이로 한다.
    /// - `anchor`가 있으면 조각마다 가로 자리를 앵커 규칙으로 그 단에서 다시 잰다 (#254,
    ///   `flowTableOriginX`). 없으면 단 왼쪽이다.
    ///
    /// 반환값은 첫 조각이 놓인 1-기반 쪽 (조각을 하나도 안 냈으면 nil) — 진단이 표의
    /// 쪽으로 보고하는 값이다 (#190). 조각을 내기 전에 단·쪽을 넘길 수 있으므로 호출
    /// 시점의 쪽과 다를 수 있다.
    @discardableResult
    func appendTableSegments(
        _ frame: HwpTableFrame,
        table: CoreHwp.HwpTable? = nil,
        instanceId: UInt32,
        pageBreakMode: CoreHwp.HwpTableProperty.HwpTablePageBreakMode = .split,
        headerRowCount: Int = 0,
        numbering: HwpNumberingScope.Container? = nil,
        margins: TableFlowMargins = .none,
        anchor: CoreHwp.HwpCommonCtrlProperty? = nil
    ) -> Int? {
        guard !frame.rows.isEmpty else { return nil }
        // 여백 폴백은 **빈 단의 용량**으로 판정한다 — 이 쪽의 각주 예약(`effectiveContentHeight`)
        // 으로 재면 앞 문단의 각주 때문에 다음 쪽에 정상적으로 들어갈 여백까지 잃는다 (PR 리뷰).
        var margins = fittingTableMargins(
            margins, rows: frame.rows[...], capacity: currentColumnFrame.height
        )

        // 셀 각주 수집용 시작 행 인덱스를 표당 한 번만 만든다 (세그먼트마다
        // 전수 스캔 방지, #15; fallback 셀도 실제 행에 귀속, #23).
        let cellsByRow = table.map { HwpTableLayout.cellRowIndex(for: $0) } ?? [:]
        // 셀 각주 문단의 번호 열쇠 — 셀 서수 접두 합도 표당 한 번 (#158).
        let cellNumbering = table.flatMap { table in numbering?.tableCells(of: table) }
        if pageBreakMode == .none {
            return appendWholeTable(
                frame, instanceId: instanceId, margins: margins,
                cellsByRow: table == nil ? nil : cellsByRow, cellNumbering: cellNumbering,
                anchor: anchor
            )
        }

        let (repeatedRows, repeatedHeight) = repeatedHeaderRows(
            of: frame, headerRowCount: headerRowCount, margins: margins
        )

        // 커서로 소비한다 — removeFirst의 배열 앞 반복 시프트(O(n²))를 피한다 (#5).
        // 잘린 행의 아래 조각은 커서 위치에 제자리 치환한다.
        var rows = frame.rows
        var cursor = 0
        var isFirstSegment = true
        // 표 하나가 만드는 세그먼트 수를 상한한다 (병적 행 페이지 증폭 방어, #5)
        var segmentCount = 0
        // 이미 셀 각주를 수집한 최상위 행 — 분할된 행이 다음 세그먼트에서
        // 다시 수집돼 각주가 중복되는 것을 막는다.
        var highestCollectedRow = Int.min
        // 실제로 방출된 최대 행 — 세그먼트가 행을 **슬라이스**하면 `cursor`는
        // 그 행을 넘지 않으므로 커서만으로는 "그려진 행"을 셀 수 없다.
        var highestEmittedRow = -1
        // 첫 조각이 놓인 쪽 (반환값)
        var firstSegmentPage: Int?

        // 취소된 로드가 병적 표를 분할 중이면 최대 4,096 세그먼트를 만들기 전에
        // 빠져 옛·새 로드가 동시에 CPU/메모리를 소비하지 않게 조기 탈출한다 (#6).
        while cursor < rows.count, segmentCount < maximumTableSegments,
              !Task.isCancelled
        {
            // 이어지는 세그먼트는 제목 행 반복 높이를 미리 차감한다. 위·아래 바깥
            // 여백도 조각마다 든다 (#190) — 위 여백은 조각 앞에서 커서로 소비한다.
            var fit = ContinuationFit(
                margins: margins,
                repeatsHeader: !isFirstSegment && !repeatedRows.isEmpty,
                repeatedHeight: repeatedHeight
            )
            var remaining = effectiveContentHeight - contentHeightUsed - fit.headerAllowance
            let freshPage = effectiveContentHeight - fit.headerAllowance
            // 물리 첫 행이 안 들어가거나(기존), 시작 행 rowspan 셀 스팬이 남은
            // 공간을 넘는데 새 페이지엔 들어가면 먼저 페이지를 넘겨 스팬 그룹을
            // 통째로 유지한다 — 병합 셀 하단이 세그먼트 밖에 그려지거나 이월에서
            // 사라지는 것을 막는다 (#3). 새 페이지도 넘는 스팬은 물리 행 기준
            // 슬라이스로 폴백한다 (zero-height continuation 방지, round13 #1).
            let spanHeight = HwpTableSplitter.firstRowSpanningHeight(rows[cursor...])
            let deferForSpan = remaining < spanHeight && spanHeight <= freshPage
            if contentHeightUsed > 0,
               remaining < HwpTableSplitter.minimumRowHeight(rows[cursor...]) || deferForSpan
            {
                advanceColumn()
                // 넘긴 단·쪽의 용량으로 여백·제목 행 반복을 다시 잰다 — 새 쪽은 각주 예약이 다르다
                // (앞 쪽 값을 쓰면 앞 문단 각주만큼 덜 채우거나, 여백과 만나 들어갈 행을 자른다).
                refitContinuation(&fit, rows: rows[cursor...])
                remaining = effectiveContentHeight - contentHeightUsed - fit.headerAllowance
            }

            // 후보 행의 셀 각주 예약 높이를 미리 반영해 세그먼트를 맞춘다 (#6).
            if table != nil {
                remaining = remainingAfterCellNotes(
                    remaining, rows: rows[cursor...], fit: &fit,
                    cellsByRow: cellsByRow, highestCollectedRow: highestCollectedRow,
                    numbering: cellNumbering
                )
            }
            // 한 번 버린 여백은 남은 조각에도 없다.
            margins = fit.margins

            let fill = HwpTableSplitter.fillSegment(rows: rows[cursor...], remaining: remaining)
            let segmentRows = fill.segment
            guard !segmentRows.isEmpty else { break }
            cursor += fill.consumed
            if let replacement = fill.replacement {
                rows[cursor] = replacement
            }

            // 셀 각주는 행이 실리는 페이지 귀속 (한글 실측 — 헌법주석 p485).
            // 분할된 행은 조각이 같은 rowAddress를 유지하므로, 이미 수집한 행보다
            // 큰 행만 수집해 조각 간 중복 각주를 막는다.
            let rowIndexes = segmentRows.flatMap(\.cells).map(\.row)
            if let maxRow = rowIndexes.max() {
                highestEmittedRow = max(highestEmittedRow, maxRow)
            }
            if table != nil {
                if let maxRow = rowIndexes.max() {
                    let startRow = max(rowIndexes.min() ?? maxRow, highestCollectedRow + 1)
                    if startRow <= maxRow {
                        collectTableCellFootnotes(
                            cellsByRow: cellsByRow, rows: startRow ... maxRow,
                            numbering: cellNumbering
                        )
                        highestCollectedRow = maxRow
                    }
                }
            }
            contentHeightUsed += margins.top
            if isFirstSegment {
                firstSegmentPage = cachedPages.count + 1
            }
            appendTableSegmentBlock(
                rows: segmentRows,
                original: frame,
                instanceId: instanceId,
                repeatedHeaderRows: fit.repeatsHeader ? repeatedRows : [],
                anchor: anchor
            )
            consumeTableBottomMargin(margins)
            isFirstSegment = false
            segmentCount += 1
        }
        // 세그먼트 상한(또는 취소)에 걸려 **방출되지 않은 행**이 남았다면 기록해
        // 둔다 — 탐색 목록이 그 행의 앵커를 내면 그려진 적 없는 자리를 가리킨다.
        // 잘린 표만 담으므로 항목은 사실상 없고(정상 문서는 0개), 조회는
        // `truncatedRowLimit(of:)`가 표 값으로 확정한다 (id는 유일하지 않다).
        if cursor < rows.count, let table {
            truncatedTableRowLimits[instanceId, default: []].append((table, highestEmittedRow + 1))
        }
        return firstSegmentPage
    }

    /// 쪽 경계 나눔이 없는 표(표 76 bits 0-1 == 0)를 통째로 놓는다 — 남은 공간에 여백까지
    /// 안 들어가면 새 쪽으로 넘긴다. 반환값은 놓인 1-기반 쪽. `cellsByRow`가 있으면 셀
    /// 각주를 이 쪽에 담는다 (표 모델이 없는 호출은 nil).
    private func appendWholeTable(
        _ frame: HwpTableFrame,
        instanceId: UInt32,
        margins: TableFlowMargins,
        cellsByRow: [Int: [(index: Int, cell: CoreHwp.HwpTableCell)]]?,
        cellNumbering: HwpNumberingScope.TableCells?,
        anchor: CoreHwp.HwpCommonCtrlProperty?
    ) -> Int {
        // 높이는 **실제로 방출할 블록**(`segmentFrame`)으로 잰다 — `rowFrame.maxY` 최댓값은 셀
        // 간격(표 76 `cellSpacing`)이 있는 표에서 첫 행 앞 간격 한 칸을 더 담는데 방출은 그것을
        // 0으로 정규화하므로, 그대로 쓰면 들어가는 여백을 버리거나 이르게 넘긴다 (PR 리뷰 —
        // 띠 판정 `floatingTableBand`와 같은 처방).
        let tableHeight = HwpTableSplitter.segmentFrame(
            rows: frame.rows, original: frame, repeatedHeaderRows: []
        )?.outerFrame.height ?? frame.flowBlockHeight
        // 이 표 자신의 셀 각주가 예약할 높이를 미리 반영한다 (#6, 분할 경로의
        // `remainingAfterCellNotes`와 같은 시산) — 수집은 놓기 직전이라 그 뒤에 재면 표 + 여백이
        // 예약 전엔 들어가고 예약 뒤엔 안 들어가는 표가 각주 자리로 넘친다 (PR 리뷰).

        func anticipatedNotes() -> CGFloat {
            cellsByRow.map {
                anticipatedNotesForNextSegment(
                    cellsByRow: $0, remainingRows: frame.rows[...],
                    remaining: .greatestFiniteMagnitude, highestCollectedRow: Int.min,
                    numbering: cellNumbering
                )
            } ?? 0
        }
        if contentHeightUsed > 0,
           contentHeightUsed + tableHeight + margins.total + anticipatedNotes()
           > effectiveContentHeight
        {
            advanceColumn()
        }
        // 목적지 용량으로 여백을 다시 잰다 — 원자 단위가 표 전체라 첫 행 기준 폴백
        // (`fittingTableMargins`)을 지나도 표 + 여백이 안 들어갈 수 있다 (이월 각주 예약, 이 표의
        // 셀 각주 예약, 또는 표만 빈 단에 들어가는 경우). 그대로 두면 위 여백만큼 아래 여백·각주
        // 자리로 넘친다 (PR 리뷰). 여백만 버린다.
        let margins = tableHeight + margins.total + anticipatedNotes() <= effectiveContentHeight
            ? margins : .none
        if let cellsByRow {
            collectTableCellFootnotes(cellsByRow: cellsByRow, rows: nil, numbering: cellNumbering)
        }
        contentHeightUsed += margins.top
        let page = cachedPages.count + 1
        appendTableSegmentBlock(
            rows: frame.rows, original: frame, instanceId: instanceId, anchor: anchor
        )
        consumeTableBottomMargin(margins)
        return page
    }

    /// 조각 루프가 단·쪽을 넘길 때 다시 재는 것들 — 이 표의 바깥 여백(한 번 버리면 남은 조각에도
    /// 없다)과 **이 조각**의 제목 행 반복.
    struct ContinuationFit {
        var margins: TableFlowMargins
        var repeatsHeader: Bool
        let repeatedHeight: CGFloat

        /// 이 조각 앞에서 미리 차감할 몫 — 제목 행 반복 높이 + 위·아래 여백.
        var headerAllowance: CGFloat {
            (repeatsHeader ? repeatedHeight : 0) + margins.total
        }
    }

    /// 단·쪽을 넘긴 조각의 여백과 제목 행 반복을 목적지 용량(`reserved`를 뺀 — 그 조각의 셀
    /// 각주 예약)으로 다시 잰다. 이월한 쪽의 예약이 여백까지 못 담으면 남은 조각은 여백 없이
    /// 흘리고, 그래도 제목 행 + 첫 행이 안 들어가면 **이 조각만** 제목 행 반복을 끈다 (PR 리뷰 —
    /// 진입 쪽의 예약으로 표 전체의 반복을 끄면 뒤 쪽에 자리가 있어도 제목이 사라진다; 0 높이
    /// 조각 폭주(#13)는 이 판정이 막는다). 조각 루프의 넘김과 셀 각주 예약의 넘김
    /// (`remainingAfterCellNotes`)이 **같은 함수**를 거쳐야 한쪽만 낡은 여백을 들고 행을 자르지
    /// 않는다.
    private func refitContinuation(
        _ fit: inout ContinuationFit, rows: ArraySlice<HwpTableRowFrame>, reserved: CGFloat = 0
    ) {
        let capacity = effectiveContentHeight - reserved
        let header = fit.repeatsHeader ? fit.repeatedHeight : 0
        fit.margins = fittingTableMargins(fit.margins, rows: rows, capacity: capacity - header)
        if fit.repeatsHeader,
           header + fit.margins.total + HwpTableSplitter.minimumRowHeight(rows) > capacity
        {
            fit.repeatsHeader = false
        }
    }

    /// 조각에 실을 바깥 여백 — 여백이 `capacity`(빈 단 용량, 또는 이월한 쪽의 예약을 뺀
    /// 용량)마저 소진하면 (첫 행 + 위·아래 여백이 안 들어간다) 여백을 버린다. 제목 행 반복이
    /// 본문 자리를 안 남기면 반복을 끄는 것(#13)과 같은 폴백이다. 그대로 두면 가용 높이가
    /// 음수가 돼 splitter가 0 높이 조각을 상한까지 낸다 (PR 리뷰: 본문 200.8pt·행 30pt·여백
    /// 110 + 110pt → 4,098쪽). 이런 여백은 한글 실측 표본이 없다.
    ///
    /// `rows`는 슬라이스로 받는다 — 첫 행 높이만 읽으므로 이월할 때마다 남은 행을 배열로
    /// 복사하면 큰 표의 분할 비용이 행 수 × 조각 수가 된다 (PR 리뷰: 32,768행·4,096회 전진
    /// Debug 실측 복사 1.50s vs 슬라이스 0.00145s).
    private func fittingTableMargins(
        _ margins: TableFlowMargins, rows: ArraySlice<HwpTableRowFrame>, capacity: CGFloat
    ) -> TableFlowMargins {
        margins.total + HwpTableSplitter.minimumRowHeight(rows) <= capacity ? margins : .none
    }

    /// 표 조각 아래 바깥 여백을 흐름 커서로 소비한다 (#190) — 다음 글줄은 여백 뒤에서
    /// 시작하고, 밴드 하단도 그만큼 내려간다. 여백이 0이면 무동작이다.
    private func consumeTableBottomMargin(_ margins: TableFlowMargins) {
        guard margins.bottom > 0 else { return }
        contentHeightUsed += margins.bottom
        markBandUsage()
    }

    /// 이어지는 세그먼트마다 반복할 제목 행과 그 높이 (표 76 bit 2). 표 전체가 제목이면
    /// 반복하지 않는다. 반복 제목이 **빈 단**(바깥 여백을 뺀)보다 크거나 같으면 continuation에
    /// 본문 행 공간이 남지 않아 splitter가 0-높이 조각을 유지하며 제목만 반복해 페이지가
    /// 폭주한다 — 반복을 끈다 (#13). 실제 제목(몇 줄)은 페이지보다 훨씬 작아 불변. 용량은
    /// 이 쪽의 각주 예약을 뺀 `effectiveContentHeight`가 **아니다** — 앞 문단의 큰 각주가
    /// 남은 쪽에서 표가 시작하면 첫 조각이 바로 넘어가는데도 표 전체의 반복이 꺼져 뒤 쪽의
    /// 제목이 사라진다 (PR 리뷰). 이월한 쪽의 예약은 조각 루프가 조각마다 다시 잰다.
    private func repeatedHeaderRows(
        of frame: HwpTableFrame,
        headerRowCount: Int,
        margins: TableFlowMargins
    ) -> (rows: [HwpTableRowFrame], height: CGFloat) {
        let candidateRows = headerRowCount > 0 && headerRowCount < frame.rows.count
            ? Array(frame.rows.prefix(headerRowCount))
            : []
        guard let firstRow = candidateRows.first else { return ([], 0) }
        let candidateHeight = candidateRows.reduce(CGFloat(0)) { partial, row in
            // rowspan 셀은 비-제목 행까지 뻗으므로 cellFrame.maxY를 반영해
            // segmentFrame의 클론 머리행 높이와 일치시킨다 — continuation
            // allowance가 과소평가돼 페이지를 넘는 것을 막는다 (#3, 라운드6 #29 정합).
            let rowExtent = row.cells.reduce(row.rowFrame.maxY) { extent, cell in
                cell.rowSpan > 1 ? max(extent, cell.cellFrame.maxY) : extent
            }
            return max(partial, rowExtent)
        } - firstRow.rowFrame.minY
        guard candidateHeight + margins.total < currentColumnFrame.height else { return ([], 0) }
        return (candidateRows, candidateHeight)
    }

    /// 후보 행의 셀 각주 예약 높이를 반영한 남은 높이 (#6). 각주 예약 후 최소 행조차
    /// 안 들어가면 remaining을 되돌리지 않고 새 페이지로 이월한다 — 각주가 이미 claim한
    /// 공간에 행을 밀어넣어 각주 영역과 겹치지 않게 한다 (#11). 셀 각주가 없으면 값
    /// 그대로다. 예약은 수집과 같은 번호 열쇠로 잰다 (#158).
    ///
    /// 이월했으면(또는 이미 빈 단이면) 그 쪽의 예약을 뺀 용량으로 여백·제목 행 반복을 다시
    /// 잰다 (`refitContinuation`, PR 리뷰) — 낡은 여백을 든 채 남은 높이를 재면 여백만 버리면
    /// 통째로 들어갈 행을 잘라 조각과 쪽이 는다 (행 100 + 셀 각주 예약 78 + 여백 30: 여백을
    /// 버리면 178 ≤ 200.8인데 92.6 + 7.4로 갈렸다).
    private func remainingAfterCellNotes(
        _ remaining: CGFloat,
        rows: ArraySlice<HwpTableRowFrame>,
        fit: inout ContinuationFit,
        cellsByRow: [Int: [(index: Int, cell: CoreHwp.HwpTableCell)]],
        highestCollectedRow: Int,
        numbering: HwpNumberingScope.TableCells?
    ) -> CGFloat {
        func anticipated(_ remaining: CGFloat) -> CGFloat {
            anticipatedNotesForNextSegment(
                cellsByRow: cellsByRow, remainingRows: rows,
                remaining: remaining, highestCollectedRow: highestCollectedRow, numbering: numbering
            )
        }
        var remaining = remaining
        var notes = anticipated(remaining)
        if notes > 0, remaining - notes < HwpTableSplitter.minimumRowHeight(rows) {
            if contentHeightUsed > 0 {
                advanceColumn()
            }
            notes = anticipated(effectiveContentHeight - contentHeightUsed - fit.headerAllowance)
            refitContinuation(&fit, rows: rows, reserved: notes)
            remaining = effectiveContentHeight - contentHeightUsed - fit.headerAllowance
            notes = anticipated(remaining)
        }
        return notes > 0 ? max(1, remaining - notes) : remaining
    }

    /// 세그먼트 표 프레임 산출 (제목 줄 반복 포함)은 HwpTableSplitter에 위임하고,
    /// 여기서는 페이지 좌표 블록 방출과 흐름 상태 갱신만 한다.
    func appendTableSegmentBlock(
        rows: [HwpTableRowFrame],
        original: HwpTableFrame,
        instanceId: UInt32,
        repeatedHeaderRows: [HwpTableRowFrame] = [],
        anchor: CoreHwp.HwpCommonCtrlProperty? = nil
    ) {
        guard let segmentFrame = HwpTableSplitter.segmentFrame(
            rows: rows,
            original: original,
            repeatedHeaderRows: repeatedHeaderRows
        ) else { return }
        let segmentHeight = segmentFrame.outerFrame.height
        // 글줄 앞 표(#190)의 첫 조각이 문단의 첫 콘텐츠면 보류된 쪽 번호 리셋과 앞선 쪽 장식
        // 등록을 여기서 확정하고 개요의 시작 쪽도 여기가 된다 (글줄 뒤 표는 글줄이 이미 확정해
        // 무동작). 조각을 내기 전에 넘긴 단·쪽 뒤라 문단이 실제로 시작하는 쪽에 걸린다.
        applyPendingPageNumberReset()
        if let pending = pendingChromeRegistration {
            registerPageChromePreceding(
                pending.tableOrdinal, in: pending.controls, numbering: pending.numbering
            )
            pendingChromeRegistration = nil
        }
        if currentParagraphFirstPlacedPage == nil {
            currentParagraphFirstPlacedPage = cachedPages.count + 1
        }

        let columnFrame = currentColumnFrame
        // 자리 차지·어울림 표는 앵커 규칙의 가로 자리, 그 밖(줄 앵커를 못 얻은 글자처럼 취급 표)은
        // 단 왼쪽이다 (#254).
        let blockFrame = CGRect(
            x: anchor.map { flowTableOriginX($0, width: segmentFrame.outerFrame.width) }
                ?? columnFrame.minX,
            y: columnFrame.minY + contentHeightUsed,
            width: segmentFrame.outerFrame.width,
            height: segmentHeight
        )
        currentBlocks.append(AnyHwpBlock(
            frame: blockFrame,
            kind: .table,
            payload: .table(segmentFrame),
            source: HwpBlockSource(controlInstanceId: instanceId)
        ))
        bandHasNonTextContent = true
        contentHeightUsed += segmentHeight
        markBandUsage()
    }

    // MARK: 개체 (글상자/도형/그림)

    /// `numbering`은 이 개체 컨트롤이 품은 글상자 문단들의 번호 열쇠 (#158).
    func appendShapeObjectBlocks(
        components: [CoreHwp.HwpShapeComponent],
        commonProperty: CoreHwp.HwpCommonCtrlProperty,
        controlIndex: Int? = nil,
        numbering: HwpNumberingScope.Container? = nil
    ) {
        let size = objectSize(commonProperty: commonProperty, components: components)

        if let textboxFrame = textboxLayout.layout(
            components: components,
            commonProperty: commonProperty,
            fallbackWidth: currentPageGeometry.contentFrame.width,
            index: index,
            sizeResolver: objectSizeResolver,
            numbering: numbering
        ) {
            appendAnchoredBlock(
                kind: .textbox,
                size: textboxFrame.outerFrame.size,
                payload: .textbox(textboxFrame),
                commonProperty: commonProperty,
                attributedText: textboxFrame.paragraphs.map(\.attributedString),
                controlIndex: controlIndex
            )
        }

        for component in components {
            if let picture = component.pictureArray.first {
                appendImageBlock(
                    picture: picture,
                    component: component,
                    commonProperty: commonProperty,
                    size: size,
                    controlIndex: controlIndex
                )
            } else if let chart = chartFrame(of: component) {
                // OLE 내장 차트 — 데이터 근사 렌더 (빈 도형 상자 대신)
                appendAnchoredBlock(
                    kind: .shape,
                    size: size,
                    payload: .chart(chart),
                    commonProperty: commonProperty,
                    controlIndex: controlIndex
                )
            } else if component.textBoxListArray.isEmpty,
                      let geometry = HwpShapeGeometry.build(component: component, size: size)
            {
                appendAnchoredBlock(
                    kind: .shape,
                    size: size,
                    payload: .shape(geometry),
                    commonProperty: commonProperty,
                    controlIndex: controlIndex
                )
            }
        }
    }

    /// OLE 개체 요소가 내장 차트면 BinData CFB에서 차트 데이터를 파싱한다.
    /// 차트가 아니거나 파싱 실패면 nil (기존 도형 상자 경로로 폴백).
    private func chartFrame(
        of component: CoreHwp.HwpShapeComponent
    ) -> HwpChartFrame? {
        guard let ole = component.oleArray.first,
              let binaryDataId = ole.binaryDataId,
              let payload = imageStore.data(forBinItemId: binaryDataId),
              let xml = CoreHwp.HwpEmbeddedChart.chartXML(fromOLEPayload: payload)
        else { return nil }
        return HwpChartParser.parse(xml: xml)
    }

    /// 수식 근사 텍스트 — nil이면 개체(글상자·도형) 경로로 폴백한다.
    ///
    /// 렌더 분기와 **탐색 목록 순회가 같은 판정을 공유**하도록 이 함수 하나가
    /// 소유한다: 수식으로 그려지는 개체는 `appendShapeObjectBlocks`를 건너뛰므로
    /// 그 글상자 텍스트가 렌더되지 않고, 따라서 그 안 앵커도 목록에 없어야 한다.
    func equationAttributedString(
        _ shape: CoreHwp.HwpShapeControl
    ) -> NSAttributedString? {
        guard let edit = shape.eqEditArray.first else { return nil }
        let commonProperty = shape.commonCtrlProperty ?? CoreHwp.HwpCommonCtrlProperty()
        let size = objectSize(
            commonProperty: commonProperty,
            components: shape.shapeComponentArray
        )
        return HwpEquationLayout.attributedString(
            edit: edit,
            fallbackSize: size.height,
            fontResolver: fontResolver
        )
    }

    /// 수식 (eqed) 컨트롤을 EQEDIT 스크립트 근사 텍스트로 방출한다.
    /// 스크립트가 비어 있으면 false — 호출자가 개체 경로로 폴백한다.
    func appendEquationBlock(
        _ shape: CoreHwp.HwpShapeControl,
        controlIndex: Int?
    ) -> Bool {
        guard let attributed = equationAttributedString(shape) else { return false }
        let commonProperty = shape.commonCtrlProperty ?? CoreHwp.HwpCommonCtrlProperty()
        let size = objectSize(
            commonProperty: commonProperty,
            components: shape.shapeComponentArray
        )
        // 근사 텍스트가 저장된 개체 폭보다 길면 폭을 늘려 한 줄을 유지한다
        // (한글.app 수식은 줄바꿈 없이 한 줄 — equation 실물 캡처)
        let line = CTLineCreateWithAttributedString(attributed)
        let measuredWidth = ceil(CGFloat(CTLineGetTypographicBounds(line, nil, nil, nil))) + 2
        let blockSize = CGSize(width: max(size.width, measuredWidth), height: size.height)
        // kind는 개체 (.textbox) — 인라인 앵커 개체는 자기 문단 text 블록과
        // 겹치는 것이 정상이라 text-text 겹침 검사 대상이 아니어야 한다
        appendAnchoredBlock(
            kind: .textbox,
            size: blockSize,
            payload: nil,
            commonProperty: commonProperty,
            attributedText: [attributed],
            controlIndex: controlIndex
        )
        return true
    }

    func objectSize(
        commonProperty: CoreHwp.HwpCommonCtrlProperty,
        components: [CoreHwp.HwpShapeComponent]
    ) -> CGSize {
        let info = commonProperty.propertyInfo
        let resolver = objectSizeResolver
        var width = resolver.width(commonProperty.width, basis: info.widthRelativeTo)
        var height = resolver.height(commonProperty.height, basis: info.heightRelativeTo)
        if width <= 0 || height <= 0, let detail = components.first?.detail {
            if width <= 0 {
                width = HwpUnits.points(fromHwpUnitU: detail.currentWidth)
            }
            if height <= 0 {
                height = HwpUnits.points(fromHwpUnitU: detail.currentHeight)
            }
        }
        return CGSize(width: max(1, width), height: max(1, height))
    }

    /// 본문 텍스트 빌더 — 현재 기하의 크기 해석기를 붙여 treatAsChar 줄
    /// 공간 예약이 paint 크기와 일치하게 한다.
    func textRunBuilder() -> HwpTextRunBuilder {
        HwpTextRunBuilder(
            index: index,
            fontResolver: fontResolver,
            sizeResolver: objectSizeResolver,
            attributeCache: attributeCache
        )
    }

    /// 현재 페이지/단 기하 기준의 개체 크기 해석기 — 전용 레이아웃 경로
    /// (표/글상자/셀 그림/줄 공간 예약)가 퍼센트 저장값을 HWPUNIT로
    /// 오해하지 않도록 전달한다.
    var objectSizeResolver: HwpObjectSizeResolver {
        HwpObjectSizeResolver(
            paperSize: currentPageGeometry.pageSize,
            contentSize: currentPageGeometry.contentFrame.size,
            columnWidth: currentColumnFrame.width,
            paragraphWidth: currentParagraphWidth
        )
    }

    /// 폭 `columnWidth`인 단에 놓인 현재 문단의 크기 해석기 — 현재 단이 아닌 단에서 개체를 잴 때
    /// 쓴다 (#214 PR 리뷰). '단'·'문단' 기준 크기가 그 단의 폭으로 풀려야 그 단에서 배치가 쓰는
    /// 해석기와 같아진다 (문단 폭은 `currentParagraphWidth`와 같은 근사).
    func objectSizeResolver(columnWidth: CGFloat) -> HwpObjectSizeResolver {
        HwpObjectSizeResolver(
            paperSize: currentPageGeometry.pageSize,
            contentSize: currentPageGeometry.contentFrame.size,
            columnWidth: columnWidth,
            paragraphWidth: max(
                1, columnWidth - currentParagraphMargins.left - currentParagraphMargins.right
            )
        )
    }

    /// '문단' 기준 폭 — 단 폭 − 현재 문단 좌우 여백 (첫 줄 들여쓰기 제외 근사)
    private var currentParagraphWidth: CGFloat {
        max(
            1,
            currentColumnFrame.width
                - currentParagraphMargins.left - currentParagraphMargins.right
        )
    }

    /// 표 43: 문단 좌우 여백은 1/2 단위 (HWPUNIT×2)로 저장된다.
    private func paragraphMargins(
        of paragraph: CoreHwp.HwpParagraph
    ) -> (left: CGFloat, right: CGFloat) {
        guard let paraShape = index.paraShape(for: paragraph) else { return (0, 0) }
        return (
            HwpUnits.points(fromHwpUnit: paraShape.marginLeft) / 2,
            HwpUnits.points(fromHwpUnit: paraShape.marginRight) / 2
        )
    }

    func appendImageBlock(
        picture: CoreHwp.HwpShapeComponentPicture,
        component _: CoreHwp.HwpShapeComponent,
        commonProperty: CoreHwp.HwpCommonCtrlProperty,
        size: CGSize,
        controlIndex: Int? = nil
    ) {
        let property = picture.pictureProperty
        let binItemId = property.map { UInt32($0.binItemId) }
            ?? picture.binaryDataId.map(UInt32.init)
        guard let binItemId else {
            appendPlaceholderBlock(hint: "그림: BinData 참조 없음")
            return
        }
        guard imageStore.data(forBinItemId: binItemId) != nil else {
            collectedUnsupported.append(HwpUnsupportedElement(
                kind: .placeholder,
                page: cachedPages.count + 1,
                hint: "그림: 데이터 없음"
            ))
            appendPlaceholderBlock(hint: "[이미지]")
            return
        }

        var borderColor: HwpRGBColor?
        var borderWidth: CGFloat = 0
        if let property, property.borderThickness > 0 {
            borderColor = HwpRGBColor(property.borderColor)
            borderWidth = HwpUnits.points(fromHwpUnit: property.borderThickness)
        }
        appendAnchoredBlock(
            kind: .image,
            size: size,
            payload: .image(HwpImageBlockInfo(
                binItemId: binItemId,
                borderColor: borderColor,
                borderWidth: borderWidth,
                style: property.map { imageRenderStyle(from: $0) }
            )),
            commonProperty: commonProperty,
            controlIndex: controlIndex
        )
    }

    /// 표 107 그림 속성에서 crop/밝기/명암/효과 렌더 스타일을 만든다.
    func imageRenderStyle(from property: CoreHwp.HwpPictureProperty) -> HwpImageRenderStyle {
        HwpImageRenderStyle(
            cropLeft: property.cropLeft,
            cropTop: property.cropTop,
            cropRight: property.cropRight,
            cropBottom: property.cropBottom,
            brightness: Int(property.brightness),
            contrast: Int(property.contrast),
            effect: HwpImageEffect(rawEffect: property.effect)
        )
    }

    /// 앵커 규칙 (표 70)에 따라 개체 블록을 배치한다.
    ///
    /// - 글자처럼 취급 (treatAsChar)이고 문단 라인에서 U+FFFC 앵커를 찾으면:
    ///   그 라인 위치에 배치한다 (줄 높이는 run delegate가 이미 예약 —
    ///   흐름 높이를 추가 소비하지 않는다).
    /// - treatAsChar (앵커 없음) 또는 본문 흐름을 차지하는 wrap:
    ///   현재 흐름 위치에 배치하고 높이를 소비한다.
    /// - 나머지 (글 앞/뒤로 포함 anchored): 기준 (쪽/문단) + 오프셋 위치에 배치하고
    ///   본문 흐름을 소비하지 않는다.
    /// 개체 블록 하나의 내용 (배치 방식과 무관한 공통 값)
    struct ObjectBlockSpec {
        let kind: HwpBlockKind
        let size: CGSize
        /// nil이면 payload 없는 순수 텍스트 블록 (수식 근사 등 — drawText만)
        let payload: HwpBlockPayload?
        let attributedString: NSAttributedString?
        let instanceId: UInt32
        /// 겹치는 개체 z-순서 (Send Backward/Forward) — 페인트/히트 정렬 기준 (#9).
        let zOrder: Int32
    }

    func appendAnchoredBlock(
        kind: HwpBlockKind,
        size: CGSize,
        payload: HwpBlockPayload?,
        commonProperty: CoreHwp.HwpCommonCtrlProperty,
        attributedText: [NSAttributedString] = [],
        controlIndex: Int? = nil
    ) {
        let info = commonProperty.propertyInfo
        let spec = ObjectBlockSpec(
            kind: kind,
            size: size,
            payload: payload,
            attributedString: HwpCombinedBlockString.combine(attributedText),
            instanceId: commonProperty.instanceId,
            zOrder: commonProperty.zOrder
        )

        if info.treatAsChar, appendInlineAnchoredBlock(
            spec, margins: .init(commonProperty), controlIndex: controlIndex
        ) {
            return
        }

        if info.treatAsChar || HwpParagraphObjectCollector.consumesFlow(info) {
            // 세로 기준이 종이/쪽/문단인 개체는 흐름 커서가 아니라 기준+
            // 오프셋 위치에 놓이고, 본문 흐름은 개체 아래로 밀린다
            // (한글 실측: text-box 종이 46.2/35.6mm, chart 문단 상단 —
            // 흐름 커서 배치는 앵커 문단 줄 높이만큼 밀린다).
            if !info.treatAsChar, info.verticalRelativeTo != nil {
                appendAbsolutePositionedFlowBlock(spec, commonProperty: commonProperty)
                return
            }
            appendFlowBlock(
                kind: spec.kind,
                size: spec.size,
                payload: spec.payload,
                attributedString: spec.attributedString,
                instanceId: spec.instanceId
            )
            return
        }

        appendFloatingBlock(spec, commonProperty: commonProperty)
    }

    /// 글 앞/뒤로 등 흐름을 소비하지 않는 개체를 기준 + 오프셋 위치에 배치한다.
    private func appendFloatingBlock(
        _ spec: ObjectBlockSpec,
        commonProperty: CoreHwp.HwpCommonCtrlProperty
    ) {
        let info = commonProperty.propertyInfo
        // 기준 + 오프셋 (음수 오프셋 허용)
        let offsetX = HwpUnits.points(
            fromHwpUnit: Int32(bitPattern: commonProperty.horizontalOffset)
        )
        let offsetY = HwpUnits.points(
            fromHwpUnit: Int32(bitPattern: commonProperty.verticalOffset)
        )
        var frame = anchoredObjectFrame(spec, info: info, offsetX: offsetX, offsetY: offsetY)
        frame = restrictedToPageFrame(
            frame, spec: spec, info: info, offsetX: offsetX, offsetY: offsetY
        )
        // 글 앞/뒤로 개체는 블록 배열 순서(선택/복사)를 논리대로 두고, 페인트·
        // 히트만 평면·zOrder로 정렬한다 — behind는 텍스트 뒤, inFront는 앞 (#8/#9/#10).
        let plane: HwpBlockPaintPlane = info.textWrap == .behindText ? .behind : .front
        currentBlocks.append(AnyHwpBlock(
            frame: frame,
            kind: spec.kind,
            attributedString: spec.attributedString,
            payload: spec.payload,
            source: HwpBlockSource(controlInstanceId: spec.instanceId),
            paintPlane: plane,
            zOrder: spec.zOrder
        ))
        bandHasNonTextContent = true
    }

    /// 앵커 규칙(표 70)의 기준 프레임(base, extent) + 정렬 + 오프셋으로 개체
    /// 프레임을 만든다. floating·absolute-flow 경로가 공유한다 (#5 정렬 반영).
    private func anchoredObjectFrame(
        _ spec: ObjectBlockSpec,
        info: CoreHwp.HwpCommonCtrlPropertyInfo,
        offsetX: CGFloat,
        offsetY: CGFloat
    ) -> CGRect {
        let contentFrame = currentPageGeometry.contentFrame
        let hRef = horizontalReference(info.horizontalRelativeTo)
        let vRef: (base: CGFloat, extent: CGFloat) = switch info.verticalRelativeTo {
        case .paper: (0, currentPageGeometry.pageSize.height)
        case .page, nil: (contentFrame.minY, contentFrame.height)
        case .paragraph: (paragraphAnchorTop, 0)
        }
        return CGRect(
            x: HwpObjectAnchorGeometry.aligned(
                base: hRef.base, extent: hRef.extent,
                size: spec.size.width, alignment: info.horizontalAlignment
            ) + offsetX,
            y: HwpObjectAnchorGeometry.aligned(
                base: vRef.base, extent: vRef.extent,
                size: spec.size.height, alignment: info.verticalAlignment
            ) + offsetY,
            width: spec.size.width,
            height: spec.size.height
        )
    }

    /// 가로 기준(표 70 `horzRelTo`)의 기준 좌표(base)와 여유 폭(extent) — 종이·쪽·단·문단.
    /// 떠 있는 개체(`anchoredObjectFrame`)와 흐름 표의 가로 자리(`flowTableOriginX`)가 공유한다.
    func horizontalReference(
        _ relativeTo: CoreHwp.HwpCommonCtrlHorizontalRelativeTo?
    ) -> (base: CGFloat, extent: CGFloat) {
        let contentFrame = currentPageGeometry.contentFrame
        return switch relativeTo {
        case .paper: (0, currentPageGeometry.pageSize.width)
        case .page, nil: (contentFrame.minX, contentFrame.width)
        case .column: (currentColumnFrame.minX, currentColumnFrame.width)
        case .paragraph: (
                currentColumnFrame.minX + currentParagraphMargins.left,
                currentParagraphWidth
            )
        }
    }

    /// 흐름을 차지하는 표(자리 차지·어울림 — 글자처럼 취급 아님)의 가로 자리 (#254).
    ///
    /// 한글은 그런 표를 가로 기준(종이·쪽·단·문단)·정렬·오프셋으로 놓고 표가 기준보다 넓으면
    /// 정렬대로 넘긴다 — 왼쪽 정렬은 오른쪽으로, 가운데는 양쪽으로, 오른쪽 정렬은 왼쪽으로
    /// (종이 밖까지). 정렬은 바깥 상자(표 + 왼쪽·오른쪽 바깥 여백, 표 70 `marginArray`)로 하고
    /// 표는 그 안에서 왼쪽 여백만큼 들어간다. 한컴오피스 한글 12.30(build 6523) PDF 실측
    /// (2026-10-05, `probes/254`, 본문 85.04–510.24pt): 450pt 표가 문단·단·쪽 기준 왼쪽 85.08·
    /// 가운데 72.72·오른쪽 60.24, 종이 기준 0·72.72·145.32, 300pt 표는 85.08·147.72·210.24;
    /// 오프셋 ±20pt면 105.12·65.04, 바깥 여백 좌우 10pt면 왼쪽 95.04·가운데 72.72·오른쪽 50.28,
    /// 문단 왼쪽 여백 20pt면 문단 기준 왼쪽 105.12·가운데 82.68, 700pt 표 오른쪽 정렬 −189.72,
    /// 2단(단 폭 201.26pt) 250pt 표 단 기준 오른쪽 36.36. 어울림(`square`)도 같은 자리다.
    /// 헌법주석 인쇄 666·667쪽 표(바깥 여백 2.83pt)가 한글에서 96.48pt인 것도 이 여백이다
    /// (#161에서 남은 차이). 쪽·단을 넘긴 조각은 그 단에서 다시 잰다.
    func flowTableOriginX(_ property: CoreHwp.HwpCommonCtrlProperty, width: CGFloat) -> CGFloat {
        let info = property.propertyInfo
        let margins = HwpObjectAnchorGeometry.OuterMargins(property)
        let reference = horizontalReference(info.horizontalRelativeTo)
        let offset = HwpUnits.points(fromHwpUnit: Int32(bitPattern: property.horizontalOffset))
        return HwpObjectAnchorGeometry.aligned(
            base: reference.base, extent: reference.extent,
            size: width + margins.horizontal, alignment: info.horizontalAlignment
        ) + margins.left + offset
    }

    /// 가로 자리를 앵커 규칙(`flowTableOriginX`)으로 잡는 흐름 표인가 — 글자처럼 취급이 아니고
    /// 흐름을 차지하는 표. 글자처럼 취급 표가 줄 앵커를 못 얻어 흐름으로 폴백하면 종전대로
    /// 단 왼쪽이다.
    static func anchorsFlowTableHorizontally(_ property: CoreHwp.HwpCommonCtrlProperty) -> Bool {
        HwpParagraphObjectCollector.alignsByOuterBox(property)
    }

    /// 문단 기준 + restrictInPage 개체가 현재 페이지 본문 하단을 넘으면 다음
    /// 페이지로 넘기고 새 페이지 기준으로 프레임을 재계산한다 (표 70 restrictInPage,
    /// errata 31b — 꼬리말/페이지 밖 렌더 방지, #6). 이미 페이지 상단이면
    /// (contentHeightUsed==0) 넘겨도 소용없어 그대로 둔다.
    private func restrictedToPageFrame(
        _ frame: CGRect,
        spec: ObjectBlockSpec,
        info: CoreHwp.HwpCommonCtrlPropertyInfo,
        offsetX: CGFloat,
        offsetY: CGFloat
    ) -> CGRect {
        guard info.verticalRelativeTo == .paragraph, info.restrictInPage,
              contentHeightUsed > 0,
              frame.maxY > currentPageGeometry.contentFrame.maxY
        else { return frame }
        advanceColumn()
        // 페이지 상한 도달: advanceColumn이 커서를 못 옮기면 anchoredObjectFrame이
        // 같은 frame을 돌려주고 이 함수가 다시 불려 제자리를 돈다 — 현재 frame을
        // 그대로 쓴다 (#1). 이 함수가 자기를 재귀 호출하지는 않는다.
        if didFinishPagination {
            return frame
        }
        return anchoredObjectFrame(spec, info: info, offsetX: offsetX, offsetY: offsetY)
    }

    /// 본문 흐름을 소비하는 블록을 현재 흐름 위치에 배치한다.
    /// 남은 공간에 안 맞으면 (블록이 단에 들어가는 크기일 때) 다음 단/페이지로 넘긴다.
    /// 종이/쪽 기준 절대 위치 + 흐름 회피 (topAndBottom류) 개체:
    /// 기준+오프셋 위치에 놓고, 개체 하단이 흐름 커서보다 아래면 본문
    /// 흐름을 개체 아래로 내린다.
    private func appendAbsolutePositionedFlowBlock(
        _ spec: ObjectBlockSpec,
        commonProperty: CoreHwp.HwpCommonCtrlProperty
    ) {
        let info = commonProperty.propertyInfo
        let offsetX = HwpUnits.points(
            fromHwpUnit: Int32(bitPattern: commonProperty.horizontalOffset)
        )
        let offsetY = HwpUnits.points(
            fromHwpUnit: Int32(bitPattern: commonProperty.verticalOffset)
        )
        var frame = anchoredObjectFrame(spec, info: info, offsetX: offsetX, offsetY: offsetY)
        frame = restrictedToPageFrame(
            frame, spec: spec, info: info, offsetX: offsetX, offsetY: offsetY
        )
        currentBlocks.append(AnyHwpBlock(
            frame: frame,
            kind: spec.kind,
            attributedString: spec.attributedString,
            payload: spec.payload,
            source: HwpBlockSource(controlInstanceId: spec.instanceId)
        ))
        bandHasNonTextContent = true
        // 본문 흐름을 개체 밴드 아래로 (topAndBottom 회피)
        let flowBottom = frame.maxY - currentColumnFrame.minY
        if flowBottom > contentHeightUsed {
            contentHeightUsed = flowBottom
        }
        markBandUsage()
    }

    private func appendFlowBlock(
        kind: HwpBlockKind,
        size: CGSize,
        payload: HwpBlockPayload?,
        attributedString: NSAttributedString?,
        instanceId: UInt32
    ) {
        if contentHeightUsed > 0,
           contentHeightUsed + size.height > effectiveContentHeight,
           size.height <= currentColumnFrame.height
        {
            advanceColumn()
        }
        let columnFrame = currentColumnFrame
        let frame = CGRect(
            x: columnFrame.minX,
            y: columnFrame.minY + contentHeightUsed,
            width: min(size.width, columnFrame.width),
            height: size.height
        )
        currentBlocks.append(AnyHwpBlock(
            frame: frame,
            kind: kind,
            attributedString: attributedString,
            payload: payload,
            source: HwpBlockSource(controlInstanceId: instanceId)
        ))
        bandHasNonTextContent = true
        contentHeightUsed += size.height
        markBandUsage()
    }

    /// treatAsChar 개체를 FFFC 앵커 라인 위치에 배치한다. 앵커가 없으면 false
    /// (호출자가 flow 배치로 폴백). 줄 높이는 run delegate가 이미 예약했으므로
    /// 흐름 높이를 추가 소비하지 않는다. `margins`는 개체의 바깥 여백 — 예약(바깥 상자)
    /// 안에서 개체를 들일 몫이다.
    private func appendInlineAnchoredBlock(
        _ spec: ObjectBlockSpec,
        margins: HwpObjectAnchorGeometry.OuterMargins,
        controlIndex: Int?
    ) -> Bool {
        guard let outerBox = inlineAnchorPosition(for: controlIndex),
              let position = inlineObjectPosition(for: controlIndex, margins: margins)
        else { return false }
        // 폭 클램프의 기준은 바깥 상자 원점이다 — 개체 원점(왼쪽 여백만큼 안)으로 재면 줄
        // 시작의 단 폭 그림·차트가 왼쪽 여백만큼 눌려 그려진다 (PR 리뷰). 여백 없는 개체는
        // 종전과 같다.
        let contentFrame = currentPageGeometry.contentFrame
        let frame = CGRect(
            x: position.x,
            y: position.y,
            width: min(spec.size.width, max(1, contentFrame.maxX - outerBox.x)),
            height: spec.size.height
        )
        currentBlocks.append(AnyHwpBlock(
            frame: frame,
            kind: spec.kind,
            attributedString: spec.attributedString,
            payload: spec.payload,
            source: HwpBlockSource(controlInstanceId: spec.instanceId)
        ))
        bandHasNonTextContent = true
        return true
    }

    /// 방금 배치한 문단의 라인에서 controlIndex의 U+FFFC 앵커를 찾아
    /// 개체의 페이지 좌표 (왼쪽 위)를 계산한다.
    ///
    /// 줄 프레임 origin.y는 줄 상자 상단(문단 첫 줄 상자 상단 기준)이고 `baseline`은 그
    /// 줄의 상자 상단 → 베이스라인 앵커다. 개체 바깥 상자의 상단은
    /// `HwpObjectAnchorGeometry.inlineAnchorOrigin`(줄 상자 모델 — 바깥 상자를 그 높이의 글자로
    /// 보고 베이스라인에 맞춘다, #180·#195).
    func inlineAnchorPosition(for controlIndex: Int?) -> CGPoint? {
        guard let controlIndex, currentParagraphContext != nil else { return nil }
        return inlineAnchorMap()[controlIndex]?.origin
    }

    /// 글자처럼 취급 개체 자신의 페이지 좌표 — 줄이 예약한 바깥 상자의 원점에서 바깥
    /// 여백(왼쪽·위쪽)만큼 들인 자리 (#193). 줄이 자리를 예약하지 **않은** 앵커(한 축 크기가
    /// 0인 개체 — `inlineObjectReservation`이 nil)는 바깥 상자가 없어 들이지 않는다 — 들이면
    /// 예약 없는 개체만 베이스라인 아래·뒤 글자 위로 옮겨진다 (PR 리뷰).
    func inlineObjectPosition(
        for controlIndex: Int?,
        margins: HwpObjectAnchorGeometry.OuterMargins
    ) -> CGPoint? {
        guard let controlIndex, currentParagraphContext != nil,
              let placement = inlineAnchorMap()[controlIndex]
        else { return nil }
        return HwpObjectAnchorGeometry.inlineObjectOrigin(
            outerBoxOrigin: placement.origin,
            margins: placement.reservesSpace ? margins : .zero
        )
    }

    /// 줄 앵커 하나 — 바깥 상자 원점과, 줄이 그 자리를 예약했는지 (delegate ascent > 0 —
    /// `HwpParagraphObjectCollector.LineAnchor.reservesSpace`와 같은 판정).
    private struct InlineAnchorPlacement {
        let origin: CGPoint
        let reservesSpace: Bool
    }

    /// 방금 놓인 문단 블록(조각)의 줄에 앵커가 있는 컨트롤 서수 — 문서 순서(오름차순).
    /// 조각별 글자처럼 취급 개체 배치(#164)가 이것만 돌아 컨트롤 전수 순회를 피한다.
    func inlineAnchoredControlOrdinals() -> [Int] {
        guard currentParagraphContext != nil else { return [] }
        return inlineAnchorMap().keys.sorted()
    }

    /// controlIndex → 앵커 좌표 맵을 컨텍스트당 한 번 만들고 캐시한다 (#12).
    /// 라인·앵커를 방출 순서로 훑어 각 controlIndex의 첫 매칭만 담는다
    /// (기존 lines.first(where:) 순서와 동일).
    private func inlineAnchorMap() -> [Int: InlineAnchorPlacement] {
        if let cached = inlineAnchorCache {
            return cached
        }
        guard let context = currentParagraphContext else {
            inlineAnchorCache = [:]
            return [:]
        }
        var map: [Int: InlineAnchorPlacement] = [:]
        for line in context.lines {
            for anchor in line.inlineAnchors where map[anchor.controlIndex] == nil {
                map[anchor.controlIndex] = InlineAnchorPlacement(
                    origin: HwpObjectAnchorGeometry.inlineAnchorOrigin(
                        paragraphOrigin: context.blockFrame.origin, line: line, anchor: anchor
                    ),
                    reservesSpace: anchor.ascent > 0
                )
            }
        }
        inlineAnchorCache = map
        return map
    }

    func appendPlaceholderBlock(hint: String) {
        let height: CGFloat = 20
        if contentHeightUsed > 0, contentHeightUsed + height > effectiveContentHeight {
            advanceColumn()
        }
        let columnFrame = currentColumnFrame
        currentBlocks.append(AnyHwpBlock(
            frame: CGRect(
                x: columnFrame.minX,
                y: columnFrame.minY + contentHeightUsed,
                width: columnFrame.width,
                height: height
            ),
            kind: .placeholder,
            attributedString: NSAttributedString(string: hint)
        ))
        bandHasNonTextContent = true
        contentHeightUsed += height
        markBandUsage()
    }

    // MARK: 각주/미주

    /// 문단(과 컨테이너 안 문단)의 각주를 이 페이지 몫으로 수집한다.
    /// 표 분할 등 다른 컨트롤 방출이 페이지를 넘기기 전에 호출해
    /// 각주를 참조 위치의 페이지에 귀속시킨다.
    /// 문단의 메모 (댓글) 필드를 이 페이지의 풍선 목록에 수집한다.
    /// 앵커 y는 방금 배치한 문단 텍스트 블록의 상단 (풍선 본문 줄이 앵커
    /// 줄과 나란— 한글.app 실측). 메모 본문은 MEMO_LIST 뒤 문단 자식.
    func collectMemos(from paragraph: CoreHwp.HwpParagraph) {
        guard let ctrls = paragraph.ctrlHeaderArray else { return }
        // 메모별 필드 마커의 controlIndex(= ctrlHeaderArray 인덱스 = extended
        // 컨트롤 순서)를 보존해, 뒤에서 각 메모의 인라인 앵커 라인 위치를 찾는다 (P2).
        let memoFields: [(controlIndex: Int, field: CoreHwp.HwpFieldControl)] = ctrls
            .enumerated()
            .compactMap { index, ctrl in
                if case let .memo(field) = ctrl {
                    (controlIndex: index, field: field)
                } else {
                    nil
                }
            }
        guard !memoFields.isEmpty else { return }
        // crafted 문단이 메모 필드를 대량 삽입해 패널 backing layer·paint 명령을
        // 폭발시키지 못하게 페이지당 풍선 수를 제한한다 (P1). 초과분은 body를
        // build하기 전에 버린다.
        let remaining = HwpMemoPanelPainter.maxBalloonsPerPage - pendingMemoBalloons.count
        guard remaining > 0 else { return }
        let cappedFields = Array(memoFields.prefix(remaining))
        let fallbackAnchorY = currentBlocks.last { $0.kind == .text }?.frame.minY
            ?? currentPageGeometry.contentFrame.minY
        // 메모별 문단 그룹을 join해 필드와 1:1로 짝짓는다 — 평탄 배열을 필드
        // 인덱스로 끊으면 여러 문단 메모는 2번째+ 문단이 누락되고 다중 메모는
        // 엉뚱한 필드에 페어링된다 (#7).
        // 표시 예산(HwpMemoPanelPainter.maxBodyChars)까지만 추출한다 — 각 문단
        // build를 남은 예산으로 상한(maxCharacters)해, 단일 거대 문단도 전체를
        // build한 뒤에야 캡되지 않게 한다 (R44 #3).
        let budget = HwpMemoPanelPainter.maxBodyChars
        let groups = (paragraph.memoParagraphGroups ?? []).prefix(remaining)
        let bodies = groups.map { group -> String in
            var parts: [String] = []
            var total = 0
            for memoParagraph in group where total < budget {
                let remainingBudget = budget - total
                let text = HwpTextRunBuilder(
                    index: index, fontResolver: fontResolver, attributeCache: attributeCache
                )
                .build(paragraph: memoParagraph, maxCharacters: remainingBudget)
                .string
                .trimmingCharacters(in: .whitespacesAndNewlines)
                guard !text.isEmpty else { continue }
                let clipped = text.count > remainingBudget
                    ? String(text.prefix(remainingBudget))
                    : text
                parts.append(clipped)
                total += clipped.count
            }
            return parts.joined(separator: "\n")
        }
        for (fieldIndex, entry) in cappedFields.enumerated() {
            // 메모마다 자기 필드 마커의 인라인 앵커 라인 y를 앵커로 삼아, 한 문단
            // 안 서로 다른 줄의 메모가 각자 줄에 맞춘다. 분할된 문단은 라인 문맥이
            // 없어 문단 상단으로 폴백한다 (인라인 앵커와 동일 한계, P2).
            let anchorY = inlineAnchorPosition(for: entry.controlIndex)?.y ?? fallbackAnchorY
            pendingMemoBalloons.append(HwpMemoPanelPainter.Balloon(
                anchorY: anchorY,
                author: entry.field.memoParameter?.author ?? "",
                dateText: Self.memoDateText(entry.field.memoParameter),
                body: fieldIndex < bodies.count ? bodies[fieldIndex] : ""
            ))
        }
    }

    /// 메모 필드 파라미터의 FILETIME (100ns since 1601, low/high DWORD 순)을
    /// 한글.app 풍선 헤더 형식 "yyyy/MM/dd HH:mm"으로 만든다.
    static func memoDateText(_ parameter: CoreHwp.HwpMemoFieldParameter?) -> String {
        guard let fields = parameter?.fields, fields.count >= 4,
              let low = UInt64(fields[2]), let high = UInt64(fields[3]),
              low <= UInt64(UInt32.max), high <= UInt64(UInt32.max)
        else { return "" }
        let ticks = (high << 32) | low
        let unixSeconds = Double(ticks) / 10_000_000 - 11_644_473_600
        guard unixSeconds > 0 else { return "" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy/MM/dd HH:mm"
        return formatter.string(from: Date(timeIntervalSince1970: unixSeconds))
    }

    // MARK: 각주/미주 수집·측정·예약 (HwpFootnoteCoordinator 위임)

    /// 측정/예약이 읽는 페이지·구역 환경 — 호출 시점 값 주입
    var noteEnvironment: HwpFootnoteCoordinator.Environment {
        HwpFootnoteCoordinator.Environment(
            contentWidth: currentPageGeometry.contentFrame.width,
            footnoteShape: currentSectionDef?.footNoteShape,
            sizeResolver: objectSizeResolver,
            // 절대 캐시 모드만 각주를 분할 지점에서 나눠 잇는다 (`placePageFootnotes`의
            // `limitsAreaToHalfContent: !absoluteCacheMode`와 같은 판정).
            continuesAtCacheBreaks: absoluteCacheMode
        )
    }

    /// includeTableCells: 표 셀 안 각주 포함 여부 (HwpFootnoteCoordinator 참조)
    /// ordinals: 이 페이지 조각에 실린 top-level 컨트롤 서수 범위 (#95, nil = 전체)
    /// 문단 커서가 가리키는 문단의 각주를 걷는다 — 번호 열쇠는 `currentParagraphScope`
    /// 라 `advanceParagraph()` 앞에서만 부른다 (#158).
    func collectFootnotes(
        from paragraph: CoreHwp.HwpParagraph,
        includeTableCells: Bool = true,
        ordinals: Range<Int>? = nil,
        collectsNested: Bool = true
    ) {
        footnoteCoordinator.collectFootnotes(
            from: paragraph,
            includeTableCells: includeTableCells,
            ordinals: ordinals,
            collectsNested: collectsNested,
            environment: noteEnvironment,
            childParagraphs: Self.childParagraphs(of:),
            numbering: currentParagraphScope
        )
    }

    /// 표 셀 각주를 수집한다. rows가 nil이면 전체 (HwpFootnoteCoordinator 참조)
    /// cellsByRow는 HwpTableLayout.cellRowIndex — 세그먼트마다 전수 스캔 방지 (#15)
    func collectTableCellFootnotes(
        cellsByRow: [Int: [(index: Int, cell: CoreHwp.HwpTableCell)]],
        rows: ClosedRange<Int>?,
        numbering: HwpNumberingScope.TableCells? = nil
    ) {
        footnoteCoordinator.collectTableCellFootnotes(
            cellsByRow: cellsByRow,
            rows: rows,
            environment: noteEnvironment,
            childParagraphs: Self.childParagraphs(of:),
            numbering: numbering
        )
    }

    /// 표 세그먼트 크기 산정 전 후보 행의 셀 각주 예약 높이 (HwpFootnoteCoordinator 참조)
    func anticipatedTableCellFootnoteHeight(
        cellsByRow: [Int: [(index: Int, cell: CoreHwp.HwpTableCell)]],
        rows: ClosedRange<Int>,
        numbering: HwpNumberingScope.TableCells? = nil
    ) -> CGFloat {
        footnoteCoordinator.anticipatedTableCellFootnoteHeight(
            cellsByRow: cellsByRow,
            rows: rows,
            environment: noteEnvironment,
            childParagraphs: Self.childParagraphs(of:),
            numbering: numbering
        )
    }

    /// 다음 세그먼트에 들어갈 후보 행들의 셀 각주가 예약할 높이 — 사본으로
    /// 시산만 한다(상태 불변). 이미 수집한 행 이후분만 세고, 셀 각주가 없으면 0.
    private func anticipatedNotesForNextSegment(
        cellsByRow: [Int: [(index: Int, cell: CoreHwp.HwpTableCell)]],
        remainingRows: ArraySlice<HwpTableRowFrame>,
        remaining: CGFloat,
        highestCollectedRow: Int,
        numbering: HwpNumberingScope.TableCells?
    ) -> CGFloat {
        let trial = HwpTableSplitter.fillSegment(rows: remainingRows, remaining: remaining)
        let rows = trial.segment.flatMap(\.cells).map(\.row)
        guard let maxRow = rows.max() else { return 0 }
        let startRow = max(rows.min() ?? maxRow, highestCollectedRow + 1)
        guard startRow <= maxRow else { return 0 }
        return anticipatedTableCellFootnoteHeight(
            cellsByRow: cellsByRow, rows: startRow ... maxRow, numbering: numbering
        )
    }

    // MARK: 미주 (문서/구역 끝)

    /// 모아 둔 미주를 현재 흐름 아래에 전체 폭 1단으로 배치한다.
    /// 남은 공간이 부족하면 다음 페이지로 이어 붙인다.
    func appendPendingEndnotes() throws {
        guard !pendingEndnotes.isEmpty else { return }
        // 미주 영역은 전체 폭: 진행 중인 다단 밴드를 닫고 그 아래에서 시작한다.
        closeColumnBand()
        currentColumnDef = nil
        openColumnBand(top: bandUsedBottom)

        // 첫 미주가 남은 공간에 안 들어가면 새 페이지에서 시작한다
        // (미주는 구분선을 그리지 않으므로 — 아래 drawSeparator = false —
        // 구분선 오버헤드 없이 실제 배치 높이만 본다). 높이는 배치(`stackBlocks`)와 **같은
        // 산식**이어야 한다 (#165 리뷰): 첫 문단이 그 미주의 끝이면 마지막 줄의 줄 간격을 빼고,
        // 개체 판정은 미주 단위이며, 라벨은 미주 모양으로 — 줄 간격만큼 크게 재면 들어가는
        // 미주를 새 쪽으로 옮긴다.
        if let first = pendingEndnotes.first,
           currentColumnFrame.minY > currentPageGeometry.contentFrame.minY,
           footnoteCoordinator.measuredFootnoteHeight(
               of: first.paragraph,
               number: first.number,
               environment: noteEnvironment.withFootnoteShape(currentSectionDef?.endNoteShape),
               numbering: first.numbering,
               isNoteEnd: pendingEndnotes.count == 1 || pendingEndnotes[1].noteId != first.noteId,
               noteCarriesObjects: first.noteFacts?.carriesObjects ?? false
           ) > effectiveContentHeight
        {
            cacheCurrentPage()
        }

        // 한글.app 실물 (footnote-endnote 2쪽): 미주 위에는 구분선을 그리지
        // 않고, 텍스트가 본문 상단에서 바로 시작한다.
        var drawSeparator = false
        // 페이지 상한에 걸려 cacheCurrentPage가 캐시를 거부하면(didFinishPagination)
        // overflow가 안 줄어 같은 만석 페이지를 무한 재시도하므로 그때 멈춘다
        // (각주 드레인 루프와 동일, #1).
        while !pendingEndnotes.isEmpty, !didFinishPagination {
            // 취소 시 미주 드레인이 페이지 상한까지 동기로 돌아 취소 관찰이
            // 늦어지지 않게 매 페이지 확인 (`finishPagination`의 각주 드레인·
            // `processParagraph`와 같은 이유, P2b).
            try Task.checkCancellation()
            let columnFrame = currentColumnFrame
            let available = CGRect(
                x: columnFrame.minX,
                y: columnFrame.minY,
                width: columnFrame.width,
                height: effectiveContentHeight
            )
            let placement = footnoteCoordinator.placePendingEndnotes(
                from: columnFrame.minY + contentHeightUsed,
                in: available,
                endnoteShape: currentSectionDef?.endNoteShape,
                drawSeparator: drawSeparator,
                sizeResolver: objectSizeResolver
            )
            for block in placement.blocks {
                currentBlocks.append(AnyHwpBlock(
                    frame: block.frame,
                    kind: .footnote,
                    attributedString: HwpCombinedBlockString.combine(
                        block.paragraphs.map(\.attributedString)
                    ),
                    payload: .footnote(block),
                    source: HwpBlockSource(paragraphId: block.paragraphs.first?.paragraphId)
                ))
            }
            bandHasNonTextContent = true
            contentHeightUsed = placement.bottom - columnFrame.minY
            markBandUsage()
            pendingEndnotes = placement.overflow
            if !pendingEndnotes.isEmpty {
                // 1단 밴드이므로 다음 단 == 새 페이지
                cacheCurrentPage()
                drawSeparator = false
            }
        }
    }

    /// 이월된 각주 입력들이 새 페이지에서 예약할 높이 (HwpFootnoteCoordinator 참조).
    /// 쪽 콘텐츠 높이를 넘으면 거기서 멈춘다 (#165 리뷰) — 읽는 쪽(`effectiveContentHeight`·
    /// `applyColumnDef`의 `usableBottom`)은 그 높이에서 포화하므로 값이 더 커도 같고, 대기
    /// 각주 N개를 쪽마다 끝까지 더하면 쪽 수 × N이다.
    func reservedFootnoteHeight(for inputs: HwpFootnoteLayout.PendingNotes) -> CGFloat {
        footnoteCoordinator.reservedFootnoteHeight(
            for: inputs, environment: noteEnvironment,
            upTo: currentPageGeometry.contentFrame.height
        )
    }

    /// 이 문단이 페이지에 추가될 때 각주 영역이 요구할 높이 (커밋 전 예측용,
    /// HwpFootnoteCoordinator 참조)
    /// 번호 열쇠는 문단 커서의 것이라 `advanceParagraph()` 앞에서만 부른다 (#158).
    func anticipatedFootnoteHeight(for paragraph: CoreHwp.HwpParagraph) -> CGFloat {
        footnoteCoordinator.anticipatedFootnoteHeight(
            for: paragraph,
            environment: noteEnvironment,
            childParagraphs: Self.childParagraphs(of:),
            numbering: currentParagraphScope
        )
    }

    /// 각주 문단 높이 측정 (라인 캐시 우선, HwpFootnoteCoordinator 참조)
    func measuredFootnoteHeight(
        of paragraph: CoreHwp.HwpParagraph,
        number: Int,
        numbering: HwpNumberingScope? = nil
    ) -> CGFloat {
        footnoteCoordinator.measuredFootnoteHeight(
            of: paragraph,
            number: number,
            environment: noteEnvironment,
            numbering: numbering
        )
    }

    /// 대기 중인 각주를 페이지 하단에 배치한다. 영역(콘텐츠 절반 상한)을
    /// 넘는 각주는 pendingFootnotes에 남겨 다음 페이지로 이월한다.
    ///
    /// 절대 캐시 모드에서는 본문이 남긴 하한(`footnoteBodyBottom`, #165) 아래에 싣는다. 본문 y는 캐시로
    /// 고정돼 있으므로 각주는 그 아래 자리에 한글의 이어짐 규칙으로 싣는다 — 안
    /// 들어가는 각주는 줄 캐시의 분할 지점에서 나눠 다음 쪽 첫 각주로 잇고 (한글이
    /// 그렇게 저장했다), 분할 지점이 없으면 통째로 옮긴다. 절반 상한은 두지 않는다.
    ///
    /// 자리만 잡고 블록은 아직 붙이지 않는다 (`appendFootnoteBlocks`) — 쪽 확정이 각주 영역
    /// 상단을 변경 막대보다 먼저 알아야 하는데(#222 PR 리뷰), 블록 순서(막대·크롬·각주)는
    /// 그대로 둔다.
    func placePageFootnotes() -> HwpFootnoteLayout.PendingPlacement? {
        guard !pendingFootnotes.isEmpty else { return nil }
        let placement = footnoteCoordinator.placePendingFootnotes(
            onPage: currentPageGeometry,
            footnoteShape: currentSectionDef?.footNoteShape,
            limitsAreaToHalfContent: !absoluteCacheMode,
            sizeResolver: objectSizeResolver,
            // 각주 이어짐 판정의 본문 하한 (#165) — 크롬·변경 막대를 붙이기 전의 본문만 잰다(단
            // 구분선은 크롬 역할이라 들지 않는다).
            bodyBottom: absoluteCacheMode ? footnoteBodyBottom() : nil
        )
        pendingFootnotes = placement.overflow
        footnoteReservedHeight = 0
        return placement
    }

    /// `placePageFootnotes`가 잡은 각주 블록을 쪽에 붙인다.
    func appendFootnoteBlocks(_ placement: HwpFootnoteLayout.PendingPlacement?) {
        guard let placement else { return }
        for block in placement.blocks {
            currentBlocks.append(AnyHwpBlock(
                frame: block.frame,
                kind: .footnote,
                attributedString: HwpCombinedBlockString.combine(
                    block.paragraphs.map(\.attributedString)
                ),
                payload: .footnote(block),
                source: HwpBlockSource(paragraphId: block.paragraphs.first?.paragraphId)
            ))
        }
    }

    // MARK: 페이지 확정

    func cacheCurrentPage() {
        // 문서 전역 페이지 상한 초과 시 더 캐시하지 않고 페이지네이션을 종료한다 —
        // page(at:) 루프가 nil을 관찰하고 멈춘다 (#1).
        guard cachedPages.count < maximumPages else {
            didFinishPagination = true
            return
        }
        // 쪽 끝으로 닫히는 밴드의 단 구분선 (#191) — 밴드 사용량은 단 전진·밴드 닫기가
        // 이미 반영했다.
        emitColumnDividers()
        // 각주 자리를 먼저 잡는다 — 각주가 있는 쪽의 본문 하단은 각주 영역 상단이라 변경
        // 막대가 그 자리를 알아야 한다 (#222 PR 리뷰). 블록은 크롬 뒤에 붙인다(종전 순서).
        let footnotes = placePageFootnotes()
        // 변경 추적 문단의 이 페이지 조각마다 변경 막대를 방출한다 — 페이지 걸친
        // 문단의 앞 조각도 자기 페이지에서 막대를 받는다 (#7).
        emitTrackChangeBars(footnoteTop: footnotes?.paintedTop)
        // 머리말/꼬리말/쪽 번호 크롬 블록 (감추기 마스크는 빌더가 소비한다)
        currentBlocks += pageChrome.blocks(
            forPage: nextLogicalPageNumber,
            geometry: currentPageGeometry
        )
        nextLogicalPageNumber += 1
        appendFootnoteBlocks(footnotes)
        let pageIndex = cachedPages.count
        let page = HwpPage(
            size: currentPageGeometry.pageSize,
            margins: currentPageGeometry.margins,
            blocks: currentBlocks,
            pageNumber: pageIndex + 1
        )
        let paintList = paintListBuilder.build(for: page)
        // 메모 풍선은 종이 밖 오른쪽 패널 (한글.app 편집 뷰) — 페이지
        // paintList와 분리해 인쇄 뷰·PrvImage 정합에는 영향을 주지 않는다.
        let memoPanel = pendingMemoBalloons.isEmpty
            ? nil
            : HwpMemoPanelPainter.panel(
                balloons: pendingMemoBalloons,
                pageSize: currentPageGeometry.pageSize
            )
        pendingMemoBalloons = []
        cachedPages[pageIndex] = HwpPage(
            size: page.size,
            margins: page.margins,
            blocks: page.blocks,
            pageNumber: page.pageNumber,
            paintList: paintList,
            memoPanel: memoPanel
        )
        currentBlocks = []
        trailingSpacesBelowLineBox = [:]
        // 페이지가 넘어가면 이전 페이지 문단의 줄 앵커 좌표는 무효다.
        currentParagraphContext = nil
        // 새 페이지: 절대 캐시 loc 추적과 stale 캐시 보정을 리셋한다.
        lastAbsoluteCacheLoc = Int32.min
        lastAbsoluteCacheAdvance = 0
        absoluteCacheBandRestarted = false
        absoluteCacheStaleOffset = 0
        // 새 페이지: 현재 단 정의로 콘텐츠 상단부터 새 밴드를 연다.
        openColumnBand(top: currentPageGeometry.contentFrame.minY)
        // 이월된 각주가 새 페이지에서 차지할 영역을 다시 예약한다.
        footnoteReservedHeight = reservedFootnoteHeight(for: pendingFootnotes)
        if currentSectionDef?.footNoteShape.numberingModeRawValue == 2 {
            footnoteCounter = Self.initialNoteNumber(
                startingNumber: currentSectionDef?.footNoteShape.startingNumber
            )
        }
    }

    /// 흐름 배치가 문단 높이로 줄 캐시를 쓸 수 있는가 — 캐시가 유효하고, 글자처럼 취급 표를 실은
    /// 줄이 그 표보다 낮지 않다 (#214 PR 리뷰). 낮으면 셀 내용이 저장 뒤에 표를 키운 문서라 줄
    /// 예약(그려지는 높이)과 캐시가 갈리므로, 캐시 높이를 쓰면 블록은 캐시만큼만 전진하고 표는 실제
    /// 높이로 그려져 뒤 문단이 표를 덮는다 — CT 높이로 떨어진다 (`HwpParagraphLayout.lineCacheIsStale`).
    /// 단 CT 높이(`measuredHeight`)가 캐시보다 클 때만이다 — 절대 캐시 보정(`staleLineExtent`)과 같다.
    /// 줄이 표를 예약하지 못한 문단(단보다 넓은 표)은 CT가 더 낮아, 캐시를 버리면 블록이 줄어 겹침이
    /// 커진다.
    func lineCacheHeightIsUsable(
        _ paragraph: CoreHwp.HwpParagraph,
        measuredHeight: CGFloat
    ) -> Bool {
        guard let cached = cachedParagraphHeight(paragraph) else { return false }
        return cached >= measuredHeight
            || !HwpParagraphLayout.lineCacheIsStale(
                paragraph, inlineTableHeights: inlineTableHeights(for: paragraph)
            )
    }

    func height(for paragraph: CoreHwp.HwpParagraph, fallback: CGFloat) -> CGFloat {
        guard lineCacheHeightIsUsable(paragraph, measuredHeight: fallback),
              let cached = cachedParagraphHeight(paragraph)
        else { return fallback }
        return cached
    }

    /// 줄 캐시가 주는 문단 높이 (줄 범위 + 저작 위·아래 간격) — 캐시가 유효하지 않으면 nil.
    func cachedParagraphHeight(_ paragraph: CoreHwp.HwpParagraph) -> CGFloat? {
        let segments = paragraph.paraLineSeg.paraLineSegInternalArray
        guard isValidLineSegmentCache(segments) else { return nil }
        // 일부 저장본 (한/글 2007 계열)은 lineLocation을 문단-상대 (0 시작)가 아니라
        // 페이지 내 누적 절대 y로 기록한다. 첫 세그먼트 위치를 빼서 문단-상대 높이로
        // 정규화한다 (첫 lineLocation == 0인 저장본에서는 동일 규칙).
        //
        // 실제 줄 전진량은 캐시가 직접 준다: lineHeight + lineSpacing (per-line 필드).
        // 실측: 연속 세그먼트의 lineLocation 델타와 일치 (헌법주석 30,345/30,348,
        // noori 문단 내 전부 — 저장 세대와 무관).
        let top = Int(segments[0].lineLocation)
        var bottom = top
        for segment in segments {
            bottom = max(bottom, HwpAbsoluteCachePlacer.lineBottom(of: segment))
        }
        let lineHeights = max(0, HwpUnits.points(fromHwpUnit: Int32(clamping: bottom - top)))
        // 문단 간격 위/아래는 캐시에 포함되지 않으므로 CT 폴백 경로
        // (HwpParagraphMetrics)와 동일하게 더한다 — 표 43 여백 계열과 같은 1/2
        // 단위라 /2 한다. full로 더하면 캐시 문단만 2배 간격이 된다 (P1). paraShape
        // 없으면 간격 0.
        let paraShape = index.paraShape(for: paragraph)
        let spacing = paraShape.map {
            max(0, HwpUnits.points(fromHwpUnit: $0.paragraphSpacingTop) / 2)
                + max(0, HwpUnits.points(fromHwpUnit: $0.paragraphSpacingBottom) / 2)
        } ?? 0
        return lineHeights + spacing
    }

    /// 줄 캐시가 주는 문단의 줄 상자 범위 (pt) — 첫 줄 상단부터 가장 아래 줄 상자(`vertsize`,
    /// `lineHeight`) 하단까지. 쪽 끝 적합 판정(#222)의 캐시 출처다 — `cachedParagraphHeight`와
    /// 달리 줄 간격(`lineSpacing`)과 문단 위·아래 간격을 넣지 않는다. 캐시가 유효하지 않으면 nil.
    func cachedLineBoxExtent(_ paragraph: CoreHwp.HwpParagraph) -> CGFloat? {
        let segments = paragraph.paraLineSeg.paraLineSegInternalArray
        guard isValidLineSegmentCache(segments) else { return nil }
        let top = Int(segments[0].lineLocation)
        var bottom = top
        for segment in segments {
            bottom = max(bottom, Int(segment.lineLocation) + Int(max(0, segment.lineHeight)))
        }
        return max(0, HwpUnits.points(fromHwpUnit: Int32(clamping: bottom - top)))
    }

    func isValidLineSegmentCache(_ segments: [CoreHwp.HwpParaLineSegInternal]) -> Bool {
        guard !segments.isEmpty else { return false }
        var previous = Int32.min
        for segment in segments {
            guard segment.lineLocation > previous, segment.lineHeight >= 0 else { return false }
            previous = segment.lineLocation
        }
        return true
    }
}
