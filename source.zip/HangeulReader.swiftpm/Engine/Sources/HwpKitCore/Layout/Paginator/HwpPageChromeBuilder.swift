import CoreGraphics
import CoreHwp
import CoreText
import Foundation

/// 머리말/꼬리말/쪽 번호 밴드 — 페이지 확정 시점에 크롬 블록을 방출한다.
/// HwpPaginator에서 추출 (동작 불변). 상태는 paginator가 소유하는 값 타입.
struct HwpPageChromeBuilder {
    /// 크롬 전용 mutable 상태 — HwpPaginator가 이 빌더째로 소유한다.
    struct State {
        /// 구역의 활성 머리말/꼬리말 (적용 범위별, 표 141).
        /// 컨트롤을 만난 이후의 모든 페이지에 반복 방출되며, 같은 범위의
        /// 새 컨트롤이 나오면 교체된다.
        var activeHeaders: [CoreHwp.HwpHeaderFooterApplyScope: Band] = [:]
        var activeFooters: [CoreHwp.HwpHeaderFooterApplyScope: Band] = [:]
        /// 활성 쪽 번호 위치 (pgNumPos, 표 147/148). 컨트롤을 만난 페이지부터
        /// 모든 페이지에 쪽 번호를 방출하며, 새 컨트롤이 나오면 교체된다
        /// (머리말처럼 구역을 넘어도 유지 — 한글의 동작).
        var activePageNumberPosition: CoreHwp.HwpPageNumberPosition?
        /// 이 페이지에서 감출 대상 (pghd, 표 145 bit field). 페이지 확정 시 초기화.
        var pageHideMask: UInt32 = 0
        /// 구역 정의 (표 130)의 감추기 플래그를 표 145 비트로 환산한 마스크.
        /// 이 플래그는 구역의 **첫 쪽**만 감춘다 (HwpSectionDefProperty 문서:
        /// "첫 쪽의 머리말/꼬리말/바탕쪽 감춤") — 페이지 확정 시 소비해
        /// 2쪽부터는 크롬이 되살아난다.
        var sectionHideMask: UInt32 = 0
        /// (컨트롤, 밴드 프레임)별 머리말/꼬리말 블록 캐시
        var bandBlocksCache: [BandBlocksKey: [AnyHwpBlock]] = [:]
    }

    /// 활성 머리말/꼬리말 하나 — 리스트 컨트롤과, 그 문단들의 문단 번호·개요 번호
    /// (#158). 번호는 등록 시점에 컨트롤 서수·리스트 서수로 풀어 두고(리스트를
    /// 펼친 평면 서수 = `HwpPaginator.childParagraphSequence`) 쪽마다 같은 값을
    /// 전치한다 — 머리말은 쪽마다 반복 조판되지만 번호 표는 문서 순서 한 번의
    /// 순회라 반복해도 늘지 않는다.
    struct Band {
        let list: CoreHwp.HwpListControl
        let numbers: [HwpParagraphNumber?]

        init(list: CoreHwp.HwpListControl, numbering: HwpNumberingScope.Container?) {
            self.list = list
            let count = list.listArray.reduce(0) { $0 + $1.paragraphArray.count }
            numbers = (0 ..< count).map { numbering?.number(childIndex: $0) }
        }
    }

    /// 밴드 블록 캐시 키: 같은 컨트롤 + 같은 번호 + 같은 밴드 프레임이면 매 페이지
    /// 재조판하지 않는다. 번호가 키에 있는 것은 값이 같은 두 머리말 컨트롤이 다른
    /// 자리에서 다른 번호를 받을 수 있어서다 (#158).
    struct BandBlocksKey: Hashable {
        let isHeader: Bool
        let list: CoreHwp.HwpListControl
        let numbers: [HwpParagraphNumber?]
        let bandX: Int
        let bandY: Int
        let bandWidth: Int
    }

    private let index: HwpIndex
    private let fontResolver: HwpFontResolver
    /// 글자 모양별 속성 캐시 (소유는 `HwpPaginator`) — 머리말/꼬리말 문단도
    /// 본문과 같은 캐시를 쓴다.
    private let attributeCache: HwpTextAttributeCache?
    /// 쪽 번호 글자 모양 id (`pageNumberCharShapeId(in:)`) — 색인이 불변이라 초기화 때 한 번 푼다 (PR 리뷰).
    let pageNumberCharShapeId: UInt32?
    private var state = State()

    init(
        index: HwpIndex,
        fontResolver: HwpFontResolver,
        attributeCache: HwpTextAttributeCache? = nil
    ) {
        self.index = index
        self.fontResolver = fontResolver
        self.attributeCache = attributeCache
        pageNumberCharShapeId = Self.pageNumberCharShapeId(in: index)
    }

    // MARK: 컨트롤 등록

    /// 페이지 크롬 (머리말/꼬리말/쪽 번호 위치/쪽 감추기) 컨트롤을 활성 상태로
    /// 등록한다. 감추기 (표 145)는 컨트롤이 놓인 문단이 확정되는 페이지에만
    /// 적용된다. `numbering`은 이 컨트롤이 품은 문단들의 번호 열쇠 (#158).
    mutating func register(
        _ ctrl: CoreHwp.HwpCtrlId,
        numbering: HwpNumberingScope.Container? = nil
    ) {
        switch ctrl {
        case let .header(list):
            state.activeHeaders[list.headerFooterApplyScope] = Band(
                list: list, numbering: numbering
            )
        case let .footer(list):
            state.activeFooters[list.headerFooterApplyScope] = Band(
                list: list, numbering: numbering
            )
        case let .pageNumberPosition(position):
            state.activePageNumberPosition = position
        case let .pageHide(other):
            state.pageHideMask |= other.pageHideInfo?.rawValue ?? 0
        default:
            break
        }
    }

    /// 구역 정의 (표 130)의 감추기 플래그를 표 145 비트 (0x01 머리말 /
    /// 0x02 꼬리말 / 0x20 쪽 번호)로 환산해 구역 마스크로 둔다. 구역의 첫 쪽에서
    /// pageHide 컨트롤 마스크와 OR로 합쳐 한 번 소비되고, 다음 구역 정의에서
    /// 다시 채워진다.
    mutating func applySectionHideFlags(_ sectionDef: CoreHwp.HwpSectionDef) {
        let property = sectionDef.propertyInfo
        var mask: UInt32 = 0
        if property.hideHeader {
            mask |= 0x01
        }
        if property.hideFooter {
            mask |= 0x02
        }
        if property.hidePageNumberPosition {
            mask |= 0x20
        }
        state.sectionHideMask = mask
    }

    // MARK: 페이지 확정 방출

    /// 페이지 확정 시점: 감추기 마스크 (표 145: 0x01 머리말, 0x02 꼬리말,
    /// 0x20 쪽 번호)를 소비하고 이 페이지의 크롬 블록을 방출 순서대로 돌려준다.
    mutating func blocks(forPage pageNumber: Int, geometry: HwpPageGeometry) -> [AnyHwpBlock] {
        let hideMask = state.pageHideMask | state.sectionHideMask
        state.pageHideMask = 0
        state.sectionHideMask = 0
        var blocks = activeBandBlocks(
            pageNumber: pageNumber,
            hideMask: hideMask,
            geometry: geometry
        )
        if let numberBlock = pageNumberBlock(
            pageNumber: pageNumber,
            hideMask: hideMask,
            geometry: geometry
        ) {
            blocks.append(numberBlock)
        }
        return blocks
    }

    // MARK: 머리말/꼬리말

    /// 페이지 번호(1-based)와 적용 범위(표 141)에 맞는 활성 머리말/꼬리말을 고른다.
    /// 짝수/홀수 전용이 양쪽보다 우선한다.
    func resolvedBand(
        from bands: [CoreHwp.HwpHeaderFooterApplyScope: Band],
        pageNumber: Int
    ) -> Band? {
        let parity: CoreHwp.HwpHeaderFooterApplyScope = pageNumber.isMultiple(of: 2)
            ? .evenPagesOnly
            : .oddPagesOnly
        return bands[parity] ?? bands[.bothPages]
    }

    /// 이 페이지에 적용되는 머리말/꼬리말 밴드 블록을 방출한다 (페이지 확정 전용).
    /// hideMask (표 145): 0x01이면 머리말, 0x02면 꼬리말을 이 페이지에서 감춘다.
    private mutating func activeBandBlocks(
        pageNumber: Int,
        hideMask: UInt32,
        geometry: HwpPageGeometry
    ) -> [AnyHwpBlock] {
        var blocks: [AnyHwpBlock] = []
        if hideMask & 0x01 == 0,
           let header = resolvedBand(from: state.activeHeaders, pageNumber: pageNumber)
        {
            blocks += bandBlocks(
                header,
                band: geometry.headerFrame,
                isHeader: true,
                pageNumber: pageNumber,
                geometry: geometry
            )
        }
        if hideMask & 0x02 == 0,
           let footer = resolvedBand(from: state.activeFooters, pageNumber: pageNumber)
        {
            blocks += bandBlocks(
                footer,
                band: geometry.footerFrame,
                isHeader: false,
                pageNumber: pageNumber,
                geometry: geometry
            )
        }
        return blocks
    }

    private mutating func bandBlocks(
        _ band: Band,
        band bandRect: CGRect?,
        isHeader: Bool,
        pageNumber: Int,
        geometry: HwpPageGeometry
    ) -> [AnyHwpBlock] {
        let list = band.list
        let paragraphs = list.listArray.flatMap(\.paragraphArray)
        guard !paragraphs.isEmpty else { return [] }
        let contentFrame = geometry.contentFrame
        let bandFrame: CGRect = bandRect ?? CGRect(
            x: contentFrame.minX,
            y: isHeader ? max(0, contentFrame.minY - 20) : contentFrame.maxY,
            width: contentFrame.width,
            height: 20
        )

        // 자동 쪽 번호 (atno kind 0)가 있는 밴드는 페이지마다 내용이 달라
        // 캐시하지 않는다.
        let containsPageNumber = paragraphs.contains { paragraph in
            (paragraph.ctrlHeaderArray ?? []).contains { ctrl in
                if case let .autoNumber(other) = ctrl {
                    return other.autoNumberInfo?.kind == .page
                }
                return false
            }
        }
        let cacheKey = BandBlocksKey(
            isHeader: isHeader,
            list: list,
            numbers: band.numbers,
            bandX: Int(bandFrame.minX * 100),
            bandY: Int(bandFrame.minY * 100),
            bandWidth: Int(bandFrame.width * 100)
        )
        if !containsPageNumber, let cached = state.bandBlocksCache[cacheKey] {
            return cached
        }

        let blocks = layoutBandBlocks(
            paragraphs: paragraphs,
            numbers: band.numbers,
            bandFrame: bandFrame,
            pageNumber: pageNumber
        )
        if !containsPageNumber {
            state.bandBlocksCache[cacheKey] = blocks
        }
        return blocks
    }

    /// 밴드 프레임 안에 문단들을 위에서 아래로 조판한 텍스트 블록을 만든다.
    /// 자동 쪽 번호 (atno kind 0) 마커는 논리 쪽 번호 문자열로 치환하고, 문단
    /// 번호·개요 번호 라벨(#158)은 `numbers`(문단 서수별)로 전치한다.
    private func layoutBandBlocks(
        paragraphs: [CoreHwp.HwpParagraph],
        numbers: [HwpParagraphNumber?],
        bandFrame: CGRect,
        pageNumber: Int
    ) -> [AnyHwpBlock] {
        let builder = HwpTextRunBuilder(
            index: index, fontResolver: fontResolver, attributeCache: attributeCache
        )
        let paragraphLayout = HwpParagraphLayout()
        var cursorY = bandFrame.minY
        var blocks: [AnyHwpBlock] = []
        for (paragraphIndex, paragraph) in paragraphs.enumerated() {
            var replacements: [Int: HwpControlMarkerReplacement] = [:]
            for (ctrlIndex, ctrl) in (paragraph.ctrlHeaderArray ?? []).enumerated() {
                guard case let .autoNumber(other) = ctrl,
                      let info = other.autoNumberInfo, info.kind == .page
                else { continue }
                replacements[ctrlIndex] = HwpControlMarkerReplacement(
                    text: HwpTextRunBuilder.decoratedNoteNumber(
                        number: pageNumber,
                        shape: info.numberShapeRawValue,
                        decorationHead: info.decorationHead,
                        decorationTail: info.decorationTail
                    )
                )
            }
            let attributed = builder.build(
                paragraph: paragraph,
                controlReplacements: replacements,
                number: numbers.indices.contains(paragraphIndex) ? numbers[paragraphIndex] : nil
            )
            guard !HwpTextRunBuilder.isEmptyParagraphAnchor(attributed) else {
                // 빈 문단은 그릴 글자가 없어 블록을 만들지 않지만 **한 줄을
                // 차지한다** — 자리를 안 비우면 뒤 줄이 한 줄 위로 올라온다
                // (#137). 조판 문자열이 빈 문단 앵커(#145)라 높이는 측정 계층
                // (`HwpParagraphMeasurer`·`HwpPaginator.layout`)과 같은 `layout`으로
                // 잰다. 크롬은 선택·복사 단위가 아니라 앵커 블록을 둘 이유가 없다.
                cursorY += max(1, paragraphLayout.layout(
                    attributedString: attributed,
                    paraShape: index.paraShapeOrDefault(for: paragraph),
                    columnWidth: bandFrame.width
                ).totalHeight)
                continue
            }
            let frame = paragraphLayout.layout(
                attributedString: attributed,
                paraShape: index.paraShapeOrDefault(for: paragraph),
                columnWidth: bandFrame.width
            )
            let blockHeight = max(1, frame.totalHeight)
            blocks.append(AnyHwpBlock(
                frame: CGRect(
                    x: bandFrame.minX,
                    y: cursorY,
                    width: bandFrame.width,
                    height: blockHeight
                ),
                kind: .text,
                attributedString: NSAttributedString(attributedString: attributed),
                source: HwpBlockSource(paragraphId: paragraph.paraHeader.paraId),
                role: .pageChrome
            ))
            cursorY += blockHeight
        }
        return blocks
    }
}

// MARK: - 쪽 번호 (표 147/148)

extension HwpPageChromeBuilder {
    /// 쪽 번호가 놓이는 가장자리 — 표 148 표시 위치의 위(1·2·3·7·9)·아래(4·5·6·8·10).
    enum PageNumberEdge {
        case top
        case bottom
    }

    /// 한글이 쪽 번호를 조판하는 스타일의 **영문 이름**. 한글은 스타일을 이 이름으로 찾는다
    /// (#193, 한컴오피스 한글 12.30 macOS 실측 2026-09-18: '쪽 번호' 스타일의 글자 모양을
    /// 30pt로 바꾸면 쪽 번호가 30pt로 그려지고, 한글 이름만 바꿔도 그대로지만 영문 이름을
    /// 바꾸면 기본 모양으로 돌아간다). 스타일 id는 문서마다 다르다 — noori는 9번 문단
    /// 스타일, 한글 12.30 새 문서는 12번 글자 스타일이다.
    static let pageNumberStyleEnglishName = "Page Number"

    /// 쪽 번호 스타일이 없을 때 한글이 쓰는 모양 — 함초롬돋움 10pt 검정 (위 실측: 두 이름을
    /// 모두 바꾸면 글자 모양 0·1과 무관하게 이것으로 그린다).
    static let fallbackPageNumberFont = (faceName: "함초롬돋움", size: CGFloat(10))

    /// 쪽 번호 글자 모양 id — 영문 이름이 "Page Number"인 첫 스타일(id 오름차순)의 글자 모양이 색인에 있을 때만.
    static func pageNumberCharShapeId(in index: HwpIndex) -> UInt32? {
        index.styles.keys.sorted().lazy
            .compactMap { index.styles[$0] }
            .first { $0.styelEnglishName == pageNumberStyleEnglishName }
            .map { UInt32($0.charShapeId) }
            .flatMap { index.charShape(id: $0) != nil ? $0 : nil }
    }

    /// 논리 쪽 번호 텍스트 블록 — hideMask 0x20 (쪽 번호 감추기, 표 145)이면 건너뛴다.
    func pageNumberBlock(
        pageNumber: Int,
        hideMask: UInt32,
        geometry: HwpPageGeometry
    ) -> AnyHwpBlock? {
        guard hideMask & 0x20 == 0,
              let position = state.activePageNumberPosition,
              let placement = Self.pageNumberPlacement(
                  displayPosition: position.propertyInfo.displayPosition,
                  pageNumber: pageNumber
              )
        else { return nil }

        var text = HwpTextRunBuilder.decoratedNoteNumber(
            number: pageNumber,
            shape: position.propertyInfo.numberFormat,
            decorationHead: position.headDecoration,
            decorationTail: position.tailDecoration
        )
        // 앞/뒤 장식 문자가 없으면 줄표 필드(표 147 4번째 WCHAR)를 따른다. 공개
        // 문서는 '항상 -'라 적지만 실물은 줄표 문자 또는 0이다 — 헌법주석은 0x2D라
        // 한글.app 실측 "- xi -"처럼 감싸고, noori는 0이라 "1"만 그린다 (#138).
        if position.headDecoration == 0, position.tailDecoration == 0,
           position.unused != 0, let scalar = Unicode.Scalar(position.unused)
        {
            let sideChar = String(Character(scalar))
            text = "\(sideChar) \(text) \(sideChar)"
        }
        let attributed = pageNumberAttributedString(text: text, alignment: placement.alignment)
        return AnyHwpBlock(
            frame: Self.pageNumberFrame(of: attributed, edge: placement.edge, geometry: geometry),
            kind: .text,
            attributedString: attributed,
            role: .pageChrome
        )
    }

    /// 표 148 bit 8-11 표시 위치 → 가장자리/정렬.
    /// 0 없음이면 nil. 바깥쪽/안쪽은 짝/홀 페이지에 따라 좌/우가 바뀐다.
    static func pageNumberPlacement(
        displayPosition: Int,
        pageNumber: Int
    ) -> (edge: PageNumberEdge, alignment: CTTextAlignment)? {
        let edge: PageNumberEdge
        switch displayPosition {
        case 1, 2, 3, 7, 9: edge = .top
        case 4, 5, 6, 8, 10: edge = .bottom
        default: return nil
        }
        let isEven = pageNumber.isMultiple(of: 2)
        let alignment: CTTextAlignment = switch displayPosition {
        case 1, 4: .left
        case 2, 5: .center
        case 3, 6: .right
        case 7, 8: isEven ? .left : .right // 바깥쪽 (홀수쪽 = 오른쪽)
        case 9, 10: isEven ? .right : .left // 안쪽
        default: .center
        }
        return (edge, alignment)
    }

    /// 쪽 번호 블록 프레임 — 가로는 본문 폭(정렬은 문단 스타일), 세로는 한글의 쪽 번호 자리.
    ///
    /// 한글은 쪽 번호를 **글자 크기 높이의 상자**로 머리말·꼬리말 영역 가장자리에 붙인다
    /// (#193, 한컴오피스 한글 12.30 macOS PDF 실측 2026-09-18):
    /// - 아래 위치: 상자 바닥 = 꼬리말 영역 바닥(쪽 높이 − 아래 여백), 베이스라인 = 그 바닥 −
    ///   글꼴 descent. 함초롬돋움 30pt 792.48 = 799.34 − 6.9(0.23em), Courier New 30pt
    ///   790.44 = 799.34 − 9.0(0.30em), 10pt 797.16, noori 811.20 = 813.54 − 2.3. 꼬리말
    ///   영역 높이(42.52·10pt)·쪽 번호 문단 모양(줄 간격 160%·300%)과 무관하다. 꼬리말
    ///   여백이 0이면 상자 바닥이 아래 여백의 가운데다(아래 여백 42.52·30·60pt에서 813.72·
    ///   819.96·804.96).
    /// - 위 위치: 상자 위 = 머리말 영역 위(위 여백), 베이스라인 = 그 위 + 글자 크기 − descent
    ///   (함초롬돋움 30pt 79.80 = 56.68 + 30 − 6.9, Courier New 77.76). 글자 크기는 상대 크기
    ///   적용 **전** 기본 크기이고 descent만 조판 글꼴 것이다(20pt × 200% → 67.44 = 56.68 + 20 −
    ///   9.2, 40pt × 50% → 92.16). 머리말 여백이 0이면 상자 위가 위 여백의 가운데다(51.36 =
    ///   28.34 + 23.1) — 위로 제책이면 제본 여백 뒤의 위 여백 가운데다(제본 85.04pt → 136.44).
    ///   제본 여백은 위 인셋 안으로 클램프한 값이다(`HwpPageGeometry.topGutter`, 잘못된 문서 방어).
    ///
    /// 블록 프레임의 위는 그 베이스라인에서 렌더러의 베이스라인 앵커(`HwpDrawnTextLayout.
    /// baselineAnchor`)를 뺀 자리다 — 렌더러는 첫 줄 상자 상단을 블록 상단에 핀한다.
    static func pageNumberFrame(
        of attributed: NSAttributedString,
        edge: PageNumberEdge,
        geometry: HwpPageGeometry
    ) -> CGRect {
        let contentFrame = geometry.contentFrame
        let line = CTLineCreateWithAttributedString(attributed)
        var descent: CGFloat = 0
        _ = CTLineGetTypographicBounds(line, nil, &descent, nil)
        let baseline: CGFloat = switch edge {
        case .bottom:
            (geometry.footerFrame?.maxY ?? geometry.pageSize.height - geometry.margins.bottom / 2)
                - descent
        case .top:
            (geometry.headerFrame?.minY
                ?? geometry.topGutter + (geometry.margins.top - geometry.topGutter) / 2)
                + HwpDrawnTextLayout.lineMetrics(of: line).baseFontSize - descent
        }
        // 렌더러(`HwpDrawnTextLayout.lines`)와 같은 앵커여야 그린 베이스라인이 위 자리에
        // 놓인다 — MS 워드 호환 문서(#194)는 글꼴 줄 상자의 베이스라인이다.
        let metrics = HwpDrawnTextLayout.lineMetrics(of: line, in: attributed)
        return CGRect(
            x: contentFrame.minX,
            y: baseline - metrics.baselineAnchor,
            width: contentFrame.width,
            height: max(1, metrics.boxHeight)
        )
    }

    /// 쪽 번호 스타일의 글자 모양으로 쪽 번호 문자열을 만든다 — 본문 글자와 같은 경로를
    /// 글자마다 지나 숫자·줄표·빈칸이 각자의 스크립트 슬롯 글꼴·상대 크기·빈칸 폭 규칙을
    /// 따른다 (문단 번호 라벨 선례). 스타일이 없으면 한글 기본 모양(함초롬돋움 10pt)이다.
    private func pageNumberAttributedString(
        text: String,
        alignment: CTTextAlignment
    ) -> NSAttributedString {
        let output: NSMutableAttributedString
        if let charShapeId = pageNumberCharShapeId {
            output = HwpTextRunBuilder(
                index: index, fontResolver: fontResolver, attributeCache: attributeCache
            ).standaloneRun(text, charShapeId: charShapeId)
        } else {
            let font = fontResolver.resolve(
                faceName: Self.fallbackPageNumberFont.faceName,
                script: .english, size: Self.fallbackPageNumberFont.size
            )
            output = NSMutableAttributedString(string: text, attributes: [
                kCTFontAttributeName as NSAttributedString.Key: font,
                kCTForegroundColorAttributeName as NSAttributedString.Key:
                    CGColor(gray: 0, alpha: 1),
            ])
            // 기본 모양도 보통 빈칸이 0.5em이다 — 한글 실측: 폴백 "- 1 -"의 빈칸 전진량
            // 5.04·4.92pt(글꼴 고유 3.0pt가 아니다), 스타일 경로와 같은 폭 (PR 리뷰). 글자
            // 모양 id가 없으니 빈칸 폭 패스는 기본 글자 모양(10pt = 이 폴백의 크기)으로 잰다.
            HwpTextRunBuilder(
                index: index, fontResolver: fontResolver, attributeCache: attributeCache
            ).applySpaceWidths(to: output)
        }
        var alignmentValue = alignment
        let style = withUnsafeMutablePointer(to: &alignmentValue) { pointer in
            var setting = CTParagraphStyleSetting(
                spec: .alignment,
                valueSize: MemoryLayout<CTTextAlignment>.size,
                value: pointer
            )
            return CTParagraphStyleCreate(&setting, 1)
        }
        output.addAttribute(
            kCTParagraphStyleAttributeName as NSAttributedString.Key,
            value: style,
            range: NSRange(location: 0, length: output.length)
        )
        return NSAttributedString(attributedString: output)
    }
}
