import CoreGraphics
import CoreHwp
import CoreText
import Foundation

public struct HwpTableLayout {
    let fontResolver: HwpFontResolver
    /// 셀 문단이 본문과 같은 글자 모양 속성 캐시를 쓰게 한다 (소유는 `HwpPaginator`).
    let attributeCache: HwpTextAttributeCache?

    public init(fontResolver: HwpFontResolver = HwpFontResolver()) {
        self.init(fontResolver: fontResolver, attributeCache: nil)
    }

    /// 캐시를 주입하는 모듈 내부용 init (`HwpTextAttributeCache` 참조).
    init(fontResolver: HwpFontResolver, attributeCache: HwpTextAttributeCache?) {
        self.fontResolver = fontResolver
        self.attributeCache = attributeCache
    }

    /// 재귀 중첩 표 레이아웃 깊이 상한 (바깥 표 = 0)
    static let maximumNestingDepth = 3

    /// 저작 셀/행 높이 상한 (pt). 미신뢰 UInt32 셀 높이가 수만 페이지를
    /// 만드는 것을 막는다 (#6). 실제 셀은 이 값의 수백분의 1이라 렌더 불변.
    static let maximumCellHeight: CGFloat = 200_000

    /// occupancy 격자 상한 (row×column). 미신뢰 rowCount/columnCount(각 UInt16)가
    /// 곱해지면 수십억 칸이 되어 OOM — 실제 문서 표는 이 한도를 한참 밑돈다.
    static let maximumGridCells = 1 << 20

    /// 표 하나가 만들 수 있는 페이지 세그먼트 상한. 본문 높이가 1pt로 몰린
    /// 병적 페이지에서 큰 행이 1pt씩 잘려 수십만 페이지가 나오는 것을 막는다
    /// (#5). 실제 표는 문서 페이지 수 이하라 이 한도를 한참 밑돈다.
    static let maximumTableSegments = 4096

    /// 표 하나를 레이아웃한다. 페이지 분할은 호출자(paginator)가 row 단위로 수행한다.
    /// 셀 안 중첩 표는 depth 3까지 재귀 레이아웃한다.
    ///
    /// 표 폭은 `availableWidth`로 줄이지 않는다 — 한글은 본문·단·셀·각주·글상자보다 넓은 표를
    /// 저작 폭 그대로 그려 넘긴다 (#254, `resolvedWidths`). `availableWidth`는 저작 폭이 없는
    /// 표의 폴백 폭이다.
    public func layout(
        table: CoreHwp.HwpTable,
        availableWidth: CGFloat,
        index: HwpIndex,
        depth: Int = 0,
        sizeResolver: HwpObjectSizeResolver? = nil
    ) -> Result<HwpTableFrame, HwpUnsupportedElement> {
        layout(
            table: table, availableWidth: availableWidth, index: index, depth: depth,
            sizeResolver: sizeResolver, numbering: nil
        )
    }

    /// 셀 문단의 문단 번호·개요 번호 열쇠(#158)까지 받는 모듈 내부용 레이아웃 —
    /// `numbering`은 이 표 컨트롤을 품은 문단의 열쇠에서 내려온 것이고, 셀 문단은
    /// `cellArray` 순서의 접두 합으로 자기 경로를 얻는다(`HwpNumberingScope.TableCells`).
    /// 공개 진입점은 열쇠 없이(라벨 없이) 조판한다.
    func layout(
        table: CoreHwp.HwpTable,
        availableWidth: CGFloat,
        index: HwpIndex,
        depth: Int = 0,
        sizeResolver: HwpObjectSizeResolver? = nil,
        numbering: HwpNumberingScope.Container?
    ) -> Result<HwpTableFrame, HwpUnsupportedElement> {
        let property = table.tableProperty
        guard let grid = Self.grid(of: table) else {
            return .success(emptyFrame(availableWidth: availableWidth))
        }
        let rowCount = grid.rows
        let columnCount = grid.columns

        let metrics = TableMetrics(property: property)
        let context = LayoutContext(
            table: table, metrics: metrics, index: index, depth: depth, sizeResolver: sizeResolver,
            numbering: numbering?.tableCells(of: table)
        )
        // 칸 폭과 배치가 같은 셀 집합을 본다 — 배치가 버리거나 다른 칸으로 옮긴 셀의 저작 폭이
        // 칸 폭을 정하면 그리지 않는 셀이 표 폭·줄 예약을 정한다 (#254 PR 리뷰).
        let accepted = Self.acceptedCells(of: table, rowCount: rowCount, columnCount: columnCount)
        let widths = Self.resolvedWidths(
            of: table,
            accepted: accepted,
            columnCount: columnCount,
            availableWidth: availableWidth,
            sizeResolver: sizeResolver
        )
        let outerWidth = widths.outer
        let columnWidths = widths.columns
        let placed = placeCells(context: context, accepted: accepted, columnWidths: columnWidths)

        let rowHeights = resolvedRowHeights(
            placed: placed,
            rowCount: rowCount,
            defaultHeight: max(1, metrics.innerHeightAdjustment)
        )
        let totalHeight = rowHeights.reduce(CGFloat(0), +)
            + metrics.spacing * CGFloat(rowCount + 1)

        let frame = HwpTableFrame(
            outerFrame: CGRect(x: 0, y: 0, width: outerWidth, height: totalHeight),
            rows: rows(
                placed: placed,
                rowHeights: rowHeights,
                columnWidths: columnWidths,
                context: context
            ),
            borderColor: outerBorderColor(table: table, index: index),
            borderWidth: 1
        )
        return .success(frame)
    }
}

extension HwpTableLayout {
    struct TableMetrics {
        let spacing: CGFloat
        let innerLeft: CGFloat
        let innerRight: CGFloat
        let innerTop: CGFloat
        let innerBottom: CGFloat

        var innerWidthAdjustment: CGFloat {
            innerLeft + innerRight
        }

        var innerHeightAdjustment: CGFloat {
            innerTop + innerBottom
        }

        init(property: CoreHwp.HwpTableProperty) {
            spacing = max(0, HwpUnits.points(fromHwpUnit16: property.cellSpacing))
            innerLeft = max(0, HwpUnits.points(fromHwpUnit16: property.leftInnerMargin))
            innerRight = max(0, HwpUnits.points(fromHwpUnit16: property.rightInnerMargin))
            innerTop = max(0, HwpUnits.points(fromHwpUnit16: property.topInnerMargin))
            innerBottom = max(0, HwpUnits.points(fromHwpUnit16: property.bottomInnerMargin))
        }
    }

    /// 표 하나를 레이아웃하는 동안 공유되는 입력 (표 모델 + 여백 지표 + id 매핑 인덱스)
    struct LayoutContext {
        let table: CoreHwp.HwpTable
        let metrics: TableMetrics
        let index: HwpIndex
        /// 현재 표의 중첩 깊이 (바깥 표 = 0)
        let depth: Int
        /// 상대 크기 기준 해석기 (paginator 페이지/단 기하) — 없으면 절대값 해석
        let sizeResolver: HwpObjectSizeResolver?
        /// 셀 문단의 문단 번호·개요 번호 열쇠 (#158) — 없으면 라벨 없이 조판한다.
        let numbering: HwpNumberingScope.TableCells?
    }

    /// 셀 4방향 안쪽 여백 (pt)
    struct CellMargins {
        let left: CGFloat
        let right: CGFloat
        let top: CGFloat
        let bottom: CGFloat
    }

    struct GridPosition: Hashable {
        let row: Int
        let column: Int
    }

    /// 셀 문단에 붙은 중첩 표 하나 — 감싼 `%hlk` 열쇠 (문단 `paraId`,
    /// `ctrlHeaderArray` 서수)까지 나른다. 열쇠가 빠지면 히트가 그 링크를
    /// 이 표의 것으로 알아보지 못해 가림으로 죽는다 (R52).
    struct PlacedNestedTable {
        let instanceId: UInt32
        let controlIndex: Int
        let paragraphId: UInt32
        let frame: HwpTableFrame
    }

    struct PlacedCell {
        let row: Int
        let column: Int
        let rowSpan: Int
        let columnSpan: Int
        let contentHeight: CGFloat
        let authoredHeight: CGFloat
        /// 떠 있는 개체 (글자처럼 취급 아님)를 담는 데 필요한 셀 높이 (여백 포함).
        /// 개체가 없으면 0. 줄 캐시도 저작 높이도 이 개체를 담지 않으므로 아래
        /// 두 값과 별개의 하한으로 쓴다 (#91).
        let floatingObjectHeight: CGFloat
        /// 라인 캐시가 담는 셀 높이 (pt, 위아래 안쪽 여백 포함) — 셀 문단 전부가
        /// 캐시로 측정됐을 때만 있고, 그때 저작된 셀 높이 (표 80)를 신뢰하되 이
        /// 값을 하한으로 둔다 (#160, `HwpTableLayout.cachedLineBoxHeight`). 어느
        /// 문단이든 CT로 다시 조판했으면 nil — `contentHeight`가 맡는다.
        let cachedCellHeight: CGFloat?
        let cell: CoreHwp.HwpTableCell
        let contents: [PlacedCellContent]
    }

    func emptyFrame(availableWidth: CGFloat) -> HwpTableFrame {
        HwpTableFrame(
            outerFrame: CGRect(x: 0, y: 0, width: availableWidth, height: 0),
            rows: [],
            borderColor: HwpRGBColor(red: 0, green: 0, blue: 0),
            borderWidth: 1
        )
    }

    func placeCells(
        context: LayoutContext,
        accepted: [AcceptedCell],
        columnWidths: [CGFloat]
    ) -> [PlacedCell] {
        accepted.map { accepted in
            placedCell(
                for: accepted.cell,
                at: accepted.placement,
                cellIndex: accepted.index,
                context: context,
                columnWidths: columnWidths
            )
        }
    }

    /// 선언 격자 — 없거나 병적이면 nil이고 그때 표는 빈 프레임으로 렌더된다.
    static func grid(of table: CoreHwp.HwpTable) -> (rows: Int, columns: Int)? {
        let property = table.tableProperty
        let rows = max(Int(property.rowCount), property.rowCellCounts.count)
        let columns = Int(property.columnCount)
        // 병적 격자 방어: occupancy Set이 수십억 칸으로 불어나 OOM되는 것을 막는다.
        guard rows > 0, columns > 0, rows * columns <= maximumGridCells else { return nil }
        return (rows, columns)
    }

    /// 배치 규칙(주소·occupancy·예산)이 **실제로 받아들이는 셀만** 원본 순서대로.
    /// 프레임을 만들지 않으므로 탐색 목록 순회도 같은 술어를 쓸 수 있다 —
    /// `cellArray`를 그대로 걸으면 배치되지 못한 셀의 앵커가 목록에 올라 누르면
    /// 아무것도 없는 자리로 간다. `index`는 `cellArray` 서수다 — 셀 문단의 번호
    /// 경로(#158)가 이 서수의 접두 합이라 값이 같은 셀로는 가를 수 없다.
    static func acceptedCells(
        of table: CoreHwp.HwpTable,
        rowCount: Int,
        columnCount: Int
    ) -> [AcceptedCell] {
        var accepted: [AcceptedCell] = []
        var occupied = Set<GridPosition>()
        // fallback 자동 배치 커서 — 매 셀마다 (0,0)부터 재스캔하지 않게 (#4)
        var nextFallbackIndex = 0
        // 누적 occupancy 채우기 예산 (격자 크기) — 겹침 병적 입력 방어 (#14)
        var fillBudget = rowCount * columnCount

        for (cellIndex, cell) in table.cellArray.enumerated() {
            guard let placement = placement(
                for: cell,
                rowCount: rowCount,
                columnCount: columnCount,
                occupied: &occupied,
                nextFallbackIndex: &nextFallbackIndex,
                fillBudget: &fillBudget
            ) else { continue }
            accepted.append((cellIndex, cell, placement))
        }
        return accepted
    }

    /// 레이아웃이 실제로 그리는 셀 (탐색 목록 순회용).
    ///
    /// `rowLimit`은 세그먼트 상한(`maximumTableSegments`)에 걸려 **방출되지 않은
    /// 행**을 잘라 내는 몫이다 — 배치가 받아들였어도 페이지에 그려지지 않은 행이
    /// 있으면 그 셀의 앵커는 목록에 없어야 한다.
    func renderedCells(
        of table: CoreHwp.HwpTable,
        rowLimit: Int? = nil
    ) -> [CoreHwp.HwpTableCell] {
        guard let grid = Self.grid(of: table) else { return [] }
        return Self.acceptedCells(of: table, rowCount: grid.rows, columnCount: grid.columns)
            .filter { accepted in
                guard let rowLimit else { return true }
                return accepted.placement.row < rowLimit
            }
            .map(\.cell)
    }

    /// 셀 하나의 문단/중첩 표 콘텐츠를 레이아웃해 PlacedCell로 만든다.
    /// `cellIndex`는 `cellArray` 서수 — 셀 문단의 번호 경로 열쇠다 (#158).
    func placedCell(
        for cell: CoreHwp.HwpTableCell,
        at placement: Placement,
        cellIndex: Int,
        context: LayoutContext,
        columnWidths: [CGFloat]
    ) -> PlacedCell {
        let spannedWidth = width(
            from: placement.column,
            span: placement.columnSpan,
            columnWidths: columnWidths,
            spacing: context.metrics.spacing
        )
        let margins = cellMargins(for: cell, metrics: context.metrics)
        let innerWidth = max(1, spannedWidth - margins.left - margins.right)
        // '문단' 기준 개체는 셀 안에서 셀 안폭을 기준으로 해석한다 (#2)
        let measurer = HwpParagraphMeasurer(
            index: context.index, fontResolver: fontResolver,
            sizeResolver: context.sizeResolver?.withParagraphWidth(innerWidth),
            attributeCache: attributeCache
        )

        let contents = measuredCellContents(
            of: cell,
            cellIndex: cellIndex,
            innerWidth: innerWidth,
            measurer: measurer,
            context: context
        )
        // 내용은 마지막 줄 상자 아래에서 끝난다 — 줄 간격 여분·아래 간격은 행에 들지 않는다 (#193).
        let contentHeight = contents.reduce(CGFloat(0)) { $0 + $1.totalHeight }
            - (contents.last?.trailingGapIfLast ?? 0) + margins.top + margins.bottom
        let authoredHeight = cell.header.cellProperty.map {
            HwpUnits.points(fromHwpUnitU: $0.height)
        } ?? 0

        return PlacedCell(
            row: placement.row,
            column: placement.column,
            rowSpan: placement.rowSpan,
            columnSpan: placement.columnSpan,
            contentHeight: contentHeight,
            authoredHeight: authoredHeight,
            floatingObjectHeight: floatingObjectHeight(
                contents: contents,
                innerWidth: innerWidth,
                margins: margins,
                context: context
            ),
            cachedCellHeight: Self.cachedLineBoxHeight(of: contents).map {
                $0 + margins.top + margins.bottom
            },
            cell: cell,
            contents: contents
        )
    }

    /// 떠 있는 개체 (글자처럼 취급 아님)를 담는 데 필요한 셀 높이 (pt, 여백 포함).
    /// 개체가 없으면 0.
    ///
    /// 한글 줄 캐시는 줄 상자만 담고 저작된 셀 높이 (표 80)도 이 개체를 반영하지
    /// 않는다 — noori 붙임 표의 형상 행 실측: 저작 12.82pt·캐시 16.00pt인데
    /// 셀 안 떠 있는 그림이 455.40pt다. 그 둘만 믿으면 행이 라벨 한 줄로 접히고
    /// 그림이 아래 행들을 덮으며 표 밖으로 흘러나간다 (#91). 여백을 더한
    /// 458.22pt를 이 행에 쓰면 표 총높이가 문서 선언·캐시와 같은 627.01pt가 된다.
    ///
    /// 배치 (`laidOutContents`)와 **같은 collector·같은 문단 쌓기**로 셀-로컬
    /// 좌표에서 재수집한다 — 개체 위치는 문단 rect의 아핀 평행이동이라 셀 원점을
    /// 몰라도 상대 하단이 같다. 산식을 복제하면 측정과 배치가 갈린다.
    private func floatingObjectHeight(
        contents: [PlacedCellContent],
        innerWidth: CGFloat,
        margins: CellMargins,
        context: LayoutContext
    ) -> CGFloat {
        guard contents.contains(where: {
            HwpParagraphObjectCollector.hasFloatingObject(
                in: $0.paragraph, collectsTextboxes: true
            )
        }) else { return 0 }
        let collector = HwpParagraphObjectCollector(
            index: context.index,
            fontResolver: fontResolver,
            sizeResolver: context.sizeResolver?.withParagraphWidth(innerWidth),
            collectsTextboxes: true,
            attributeCache: attributeCache
        )
        var cursorY: CGFloat = 0
        var bottom: CGFloat = 0
        for content in contents {
            let spacingBefore = halfSpacingBefore(of: content.paragraph, index: context.index)
            let rect = CGRect(
                x: 0,
                y: cursorY + spacingBefore,
                width: innerWidth,
                height: content.frame.totalHeight - spacingBefore
            )
            let collected = collector.objects(
                in: content.paragraph, frame: content.frame, paragraphRect: rect,
                numbering: content.numbering
            )
            if let floatingBottom = collected.floatingBottom {
                bottom = max(bottom, floatingBottom)
            }
            cursorY += content.totalHeight
        }
        guard bottom > 0 else { return 0 }
        return margins.top + bottom + margins.bottom
    }

    /// 셀 문단들을 측정한다. 셀 높이는 한글 라인 캐시를 우선한다 (각주와 동일
    /// 철학) — 폰트 대체로 CT 줄 수가 부풀어 row가 한글보다 커지는 것을 막는다.
    /// 문단마다 캐시를 썼는지는 `PlacedCellContent.cachedLineExtent`가 나른다.
    /// 번호 라벨(#158)은 여기서 붙여 잰 문자열이 배치(`laidOutContents`)에서도 같은
    /// 번호로 다시 만들어지므로 재측정 문단의 줄바꿈·높이가 배치와 같고, 캐시 높이를
    /// 쓰는 문단은 라벨과 무관하게 저작 높이를 유지한다.
    private func measuredCellContents(
        of cell: CoreHwp.HwpTableCell,
        cellIndex: Int,
        innerWidth: CGFloat,
        measurer: HwpParagraphMeasurer,
        context: LayoutContext
    ) -> [PlacedCellContent] {
        var contents: [PlacedCellContent] = []
        for (paragraphIndex, paragraph) in cell.paragraphArray.enumerated() {
            let numbering = context.numbering?.paragraph(
                cellIndex: cellIndex, paragraphIndex: paragraphIndex
            )
            // 문단 위 간격 절반: CT는 프레임 첫 문단에 paragraphSpacingBefore를
            // 적용하지 않으므로 (셀은 문단별 개별 조판) 항상 직접 더한다.
            // 렌더 배치에서 같은 값만큼 문단 상단을 내린다 (noori 부제 실물)
            let measured = measurer.measure(
                paragraph,
                width: innerWidth,
                options: .init(
                    preferCachedHeight: true, addHalfSpacingBefore: true,
                    number: numbering?.number
                )
            )
            contents.append(PlacedCellContent(
                paragraph: paragraph,
                frame: measured.frame,
                numbering: numbering,
                cachedLineExtent: measured.cachedLineExtent,
                trailingGap: measured.trailingGap,
                nestedTables: nestedTableFrames(
                    in: paragraph,
                    innerWidth: innerWidth,
                    context: context,
                    numbering: numbering
                )
            ))
        }
        return contents
    }

    /// 셀 문단에 붙은 중첩 표들을 재귀 레이아웃한다 (깊이 상한 초과분은 생략).
    /// `numbering`은 그 셀 문단의 열쇠 — 중첩 표 셀 문단은 한 겹 더 내려간다 (#158).
    func nestedTableFrames(
        in paragraph: CoreHwp.HwpParagraph,
        innerWidth: CGFloat,
        context: LayoutContext,
        numbering: HwpNumberingScope? = nil
    ) -> [PlacedNestedTable] {
        guard context.depth < Self.maximumNestingDepth,
              let ctrls = paragraph.ctrlHeaderArray
        else { return [] }
        return ctrls.enumerated().compactMap { controlIndex, ctrl in
            guard case let .table(nested) = ctrl else { return nil }
            guard case let .success(frame) = layout(
                table: nested, availableWidth: innerWidth, index: context.index,
                depth: context.depth + 1,
                sizeResolver: context.sizeResolver?.withParagraphWidth(innerWidth),
                numbering: numbering?.container(controlIndex: controlIndex)
            ) else { return nil }
            return PlacedNestedTable(
                instanceId: nested.commonCtrlProperty.instanceId,
                controlIndex: controlIndex,
                paragraphId: paragraph.paraHeader.paraId,
                frame: frame
            )
        }
    }

    struct Placement {
        let row: Int
        let column: Int
        let rowSpan: Int
        let columnSpan: Int
    }

    /// 배치가 받아들인 셀 하나 (`acceptedCells`) — `index`는 `cellArray` 서수.
    typealias AcceptedCell = (index: Int, cell: CoreHwp.HwpTableCell, placement: Placement)

    static func placement(
        for cell: CoreHwp.HwpTableCell,
        rowCount: Int,
        columnCount: Int,
        occupied: inout Set<GridPosition>,
        nextFallbackIndex: inout Int,
        fillBudget: inout Int
    ) -> Placement? {
        var resolved: Placement?
        if let property = cell.header.cellProperty,
           Int(property.rowAddress) < rowCount,
           Int(property.columnAddress) < columnCount
        {
            resolved = Placement(
                row: Int(property.rowAddress),
                column: Int(property.columnAddress),
                rowSpan: min(Int(property.rowSpan), rowCount - Int(property.rowAddress)),
                columnSpan: min(Int(property.columnSpan), columnCount - Int(property.columnAddress))
            )
        } else {
            // 이전 배치 다음 칸부터 이어서 첫 빈 칸을 찾는다 (매번 0부터 재스캔
            // 방지 — 점유는 단조 증가라 앞칸은 다시 비지 않는다, #4).
            let total = rowCount * columnCount
            var index = nextFallbackIndex
            while index < total {
                let position = GridPosition(row: index / columnCount, column: index % columnCount)
                if !occupied.contains(position) {
                    resolved = Placement(row: position.row, column: position.column, rowSpan: 1, columnSpan: 1)
                    break
                }
                index += 1
            }
            nextFallbackIndex = index + 1
        }
        guard let placement = resolved else { return nil }
        // 셀은 절대 거부하지 않는다 — 겹치는 셀도 원본처럼 모두 배치한다(렌더 불변).
        // 대신 누적 채우기 횟수를 격자 크기로 상한해, 같은 대영역을 겹쳐 채우는
        // 병적 입력이 occupancy 삽입을 수십억 번 반복하는 것을 막는다 (#14).
        fill: for row in placement.row ..< placement.row + placement.rowSpan {
            for column in placement.column ..< placement.column + placement.columnSpan {
                if fillBudget <= 0 {
                    break fill
                }
                occupied.insert(GridPosition(row: row, column: column))
                fillBudget -= 1
            }
        }
        return placement
    }

    /// 셀을 placement()과 동일한 규칙(명시 좌표 / fallback 커서 / 겹침 거부)으로
    /// 해석해 시작 행 → 셀 목록으로 묶는다. cellArray를 세그먼트마다 전수
    /// 스캔하지 않게 하고(#15), 좌표 없는 fallback 셀도 배치가 준 실제 행에
    /// 귀속시킨다(#23 — 예전엔 전부 행 0으로 취급). 각 셀에 원래 cellArray
    /// 인덱스를 실어, 소비 측이 인덱스로 재정렬해 문서 순서(=각주 번호 순서)를
    /// 정확히 복원한다 (행 우선 저장 가정에 의존하지 않음).
    static func cellRowIndex(
        for table: CoreHwp.HwpTable
    ) -> [Int: [(index: Int, cell: CoreHwp.HwpTableCell)]] {
        let property = table.tableProperty
        let rowCount = max(Int(property.rowCount), property.rowCellCounts.count)
        let columnCount = Int(property.columnCount)
        guard rowCount > 0, columnCount > 0 else { return [:] }
        var occupied = Set<Int>()
        var nextFallbackIndex = 0
        var fillBudget = rowCount * columnCount
        var index: [Int: [(index: Int, cell: CoreHwp.HwpTableCell)]] = [:]
        for (cellIndex, cell) in table.cellArray.enumerated() {
            var row = 0
            var column = 0
            var rowSpan = 1
            var columnSpan = 1
            var placed = false
            if let cellProperty = cell.header.cellProperty,
               Int(cellProperty.rowAddress) < rowCount,
               Int(cellProperty.columnAddress) < columnCount
            {
                row = Int(cellProperty.rowAddress)
                column = Int(cellProperty.columnAddress)
                rowSpan = min(Int(cellProperty.rowSpan), rowCount - row)
                columnSpan = min(Int(cellProperty.columnSpan), columnCount - column)
                placed = true
            } else {
                var slot = nextFallbackIndex
                while slot < rowCount * columnCount {
                    if !occupied.contains(slot) {
                        row = slot / columnCount
                        column = slot % columnCount
                        placed = true
                        break
                    }
                    slot += 1
                }
                nextFallbackIndex = slot + 1
            }
            guard placed else { continue }
            // placement()과 동일: 셀을 거부하지 않고(겹쳐도 배치) 누적 채우기만
            // 격자 크기로 상한한다 (#14) — 렌더 배치와 각주 행 귀속을 일치시킨다.
            fillLoop: for spanRow in row ..< row + rowSpan {
                for spanColumn in column ..< column + columnSpan {
                    if fillBudget <= 0 {
                        break fillLoop
                    }
                    occupied.insert(spanRow * columnCount + spanColumn)
                    fillBudget -= 1
                }
            }
            index[row, default: []].append((cellIndex, cell))
        }
        return index
    }

    /// 셀 고유 여백을 쓰는 셀은 셀 속성의 여백, 아니면 표 안쪽 여백.
    func cellMargins(
        for cell: CoreHwp.HwpTableCell,
        metrics: TableMetrics
    ) -> CellMargins {
        if cell.header.cellPropertyInfo.appliesInnerMargin,
           let property = cell.header.cellProperty,
           property.marginArray.count == 4
        {
            return CellMargins(
                left: max(0, HwpUnits.points(fromHwpUnit16: property.marginArray[0])),
                right: max(0, HwpUnits.points(fromHwpUnit16: property.marginArray[1])),
                top: max(0, HwpUnits.points(fromHwpUnit16: property.marginArray[2])),
                bottom: max(0, HwpUnits.points(fromHwpUnit16: property.marginArray[3]))
            )
        }
        return CellMargins(
            left: metrics.innerLeft,
            right: metrics.innerRight,
            top: metrics.innerTop,
            bottom: metrics.innerBottom
        )
    }
}
