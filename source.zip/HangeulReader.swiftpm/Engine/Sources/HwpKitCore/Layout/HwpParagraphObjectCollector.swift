import CoreGraphics
import CoreHwp
import Foundation

/// 컨테이너 (표 셀/글상자) 문단에 붙은 개체 컨트롤 (그림/도형/글상자)을
/// 컨테이너-로컬 rect로 수집한다. 줄 안 U+FFFC 앵커가 있으면 (treatAsChar)
/// 그 줄 위치에, 없으면 문단 rect 왼쪽부터 커서로 쌓는다 (한글: 컨테이너 안
/// 개체는 컨테이너 콘텐츠 — 페이지 흐름으로 방출하면 컨테이너 밖에 그려진다).
/// ole (내장 차트)·수식 컨트롤은 대상이 아니다 — 페이지 흐름 경로가 그린다.
struct HwpParagraphObjectCollector {
    let index: HwpIndex
    let fontResolver: HwpFontResolver
    let sizeResolver: HwpObjectSizeResolver?
    /// 글상자 수집 여부 — 글상자 안 글상자 재귀를 막는다 (표 셀만 참)
    let collectsTextboxes: Bool
    /// 글자 모양별 속성 캐시 (소유는 `HwpPaginator`) — 컨테이너 안 글상자가
    /// 자체 `HwpTextboxLayout`을 만들 때 캐시를 잃지 않게 한다.
    var attributeCache: HwpTextAttributeCache?
    /// 표 수집 여부 — **각주/미주 블록만 참**이다 (#94). 표 셀은
    /// `HwpTableLayout.PlacedCellContent.nestedTables`가 이미 셀 안에 재귀
    /// 배치하므로 여기서 또 담으면 이중 렌더가 되고, 글상자는 안쪽 표를
    /// 흐름 경로에 남긴다. 각주는 담을 필드도 흐름 방출도 없어 개체가
    /// 사라졌던 쪽이라 (헌법주석 883쪽 각주 29의 4×8 표) 여기서 담는다.
    var collectsTables: Bool = false

    typealias HandledControl = (
        commonProperty: CoreHwp.HwpCommonCtrlProperty?,
        components: [CoreHwp.HwpShapeComponent]
    )

    /// 컨테이너 레이아웃이 처리하는 컨트롤의 (공통 속성, 개체 요소) 추출.
    /// HwpPaginator의 페이지 흐름 억제 술어와 수집 대상이 여기서 일치한다.
    /// 수식 (equation)은 흐름 경로의 스크립트 근사 텍스트를 유지하려 제외.
    static func handledControl(
        _ ctrl: CoreHwp.HwpCtrlId
    ) -> HandledControl? {
        switch ctrl {
        case let .genShapeObject(genShape):
            (genShape.commonCtrlProperty, genShape.shapeComponentArray)
        case let .shape(shape),
             let .line(shape),
             let .rectangle(shape),
             let .ellipse(shape),
             let .arc(shape),
             let .polygon(shape),
             let .curve(shape),
             let .picture(shape),
             let .container(shape):
            (shape.commonCtrlProperty, shape.shapeComponentArray)
        default:
            nil
        }
    }

    /// 컨트롤 단위 수집 판정 — HwpPaginator의 페이지 흐름 억제
    /// (rendersInsideContainer)와 반드시 일치해야 한다 (불일치 = 소실 또는
    /// 이중 렌더). ole (내장 차트) 또는 미수집 글상자를 품은 컨트롤은
    /// 통째로 흐름 경로에 남긴다.
    /// 이 컴포넌트의 **글상자가 그려지는가**. `collect(component:)`는 그림이 있으면
    /// 그림만 그리고 반환하므로, 그림과 글상자를 함께 가진 컴포넌트의 글상자
    /// 텍스트는 렌더되지 않는다 — 탐색 목록 순회가 같은 우선순위를 써야 없는
    /// 자리를 가리키지 않는다.
    static func drawsTextbox(
        _ component: CoreHwp.HwpShapeComponent,
        collectsTextboxes: Bool
    ) -> Bool {
        component.pictureArray.isEmpty
            && collectsTextboxes
            && !component.textBoxListArray.isEmpty
    }

    /// 요소가 하나도 없는 컨트롤은 수집 대상이 아니다 (#165 리뷰): `objects()`는 요소마다
    /// 그리므로 빈 컨트롤은 아무것도 내지 않는데, `allSatisfy`가 공허하게 참이면 그런 각주가
    /// "개체를 담은 각주"로 판정돼 쪽 끝 분할이 막히고 CT 높이로 남는다. 흐름 경로도 요소가
    /// 없으면 내는 것이 없어 두 경로의 답이 같다.
    static func collectible(
        _ components: [CoreHwp.HwpShapeComponent],
        collectsTextboxes: Bool
    ) -> Bool {
        guard !components.isEmpty, components.allSatisfy(\.oleArray.isEmpty) else { return false }
        if !collectsTextboxes,
           components.contains(where: { !$0.textBoxListArray.isEmpty })
        {
            return false
        }
        return true
    }

    /// 수집 진행 상태 — 줄 흐름 커서와 원본 순서 ordinal (zOrder 동순위
    /// tiebreak, 컨테이너 전체에서 단조 증가해야 한다, R31 #3)
    struct CollectState {
        var cursorX: CGFloat
        var sourceOrder: Int
    }

    /// `numbering`은 이 문단의 번호 열쇠 (#158) — 수집하는 글상자·표 안 문단이 한 겹
    /// 아래 경로로 자기 번호를 찾는다. 없으면 그 안 문단은 라벨 없이 조판된다.
    ///
    /// `tableContainmentBottom`: 문단 높이를 줄 캐시로 잡은 컨테이너(각주·미주)가 표를 담아야 하는
    /// 바닥 — 캐시 마지막 줄 **상자**의 아래다 (#214 리뷰). 없으면 문단 rect의 아래다.
    func objects(
        in paragraph: CoreHwp.HwpParagraph,
        frame: HwpParagraphFrame,
        paragraphRect: CGRect,
        firstSourceOrder: Int = 0,
        numbering: HwpNumberingScope? = nil,
        tableContainmentBottom: CGFloat? = nil
    ) -> Objects {
        var collected = Objects()
        var state = CollectState(cursorX: paragraphRect.minX, sourceOrder: firstSourceOrder)
        for (controlIndex, ctrl) in (paragraph.ctrlHeaderArray ?? []).enumerated() {
            let placement = Placement(
                anchor: lineAnchor(
                    for: controlIndex, frame: frame, paragraphRect: paragraphRect
                ),
                paragraphRect: paragraphRect,
                controlIndex: controlIndex,
                paragraphId: paragraph.paraHeader.paraId,
                numbering: numbering?.container(controlIndex: controlIndex)
            )
            if collectsTables, case let .table(nested) = ctrl {
                let marker = collected.marker
                if let table = table(nested, placement: placement, state: &state) {
                    collected.nestedTables.append(table)
                }
                // 줄이 표의 그려지는 높이를 예약해도(#214) 문단 높이가 **줄 캐시**에서 왔으면 그 캐시가
                // 표보다 작을 수 있다 (저작 뒤 셀 내용이 커진 문서) — 캐시 줄 상자를 넘친 만큼도 하한이다.
                noteContainerFloor(
                    nested.commonCtrlProperty,
                    placement: placement, since: marker, into: &collected,
                    textBottom: tableContainmentBottom ?? placement.paragraphRect.maxY
                )
                continue
            }
            guard let (commonProperty, components) = Self.handledControl(ctrl),
                  Self.collectible(components, collectsTextboxes: collectsTextboxes)
            else { continue }
            let marker = collected.marker
            // 글상자 문단의 번호 경로 서수는 앞선 요소들의 글상자 문단 수를 더한 값
            // (`HwpNumberingScope.textboxChildOffset`과 같은 접두 합) — 요소마다 앞선
            // 요소 전체를 다시 더하면 요소 N개짜리 개체 하나가 O(N²)이라(리뷰 실측: 요소
            // 8,000개 7.5초) 반복문에서 누적한다. 번호나 글상자가 없는 요소도 이 합을
            // 지나므로 상수 비용이어야 한다.
            var componentOffset = 0
            for component in components {
                collect(
                    component: component,
                    commonProperty: commonProperty,
                    placement: placement,
                    componentOffset: componentOffset,
                    state: &state,
                    into: &collected
                )
                componentOffset += component.textBoxListArray.reduce(0) {
                    $0 + $1.paragraphArray.count
                }
            }
            noteContainerFloor(
                commonProperty, placement: placement, since: marker, into: &collected
            )
        }
        return collected
    }

    /// 컨테이너 높이 하한을 기록한다 — 줄이 **안 담은** 개체(`raisesContainerFloor`)는
    /// 통째로, 담았다고 본 개체는 **예약 상자를 넘친 만큼만** (R65).
    ///
    /// 예약은 저작 치수다 (`inlineObjectReservation` → 표 69 공통 속성). 표·글상자의 실제
    /// 높이는 **내용**이 정하므로 예약보다 크게 조판될 수 있고, 그때 줄은 그 초과분을
    /// 안 담는다 — `reservesSpace`(예약 > 0)만 보면 "줄이 담았다"로 접어 개체가 다음
    /// 각주·행 위로 흘러나간다. #91이 저작 셀 높이에서 겪은 것과 같은 함정이다. 각주·미주
    /// 안 표는 줄이 그려지는 높이를 예약하므로(#214, `HwpTableLayout.inlineTableHeights`)
    /// 예약 상자로는 걸리지 않지만, 문단 높이가 표보다 짧은 줄 캐시에서 왔으면 문단 rect를
    /// 넘친 만큼 걸린다(`textBottom`). 글상자와 높이를 넘기지 않는 경로의 안전망이기도 하다.
    ///
    /// `textBottom`이 있으면 예약 상자와 그 바닥 가운데 **위쪽**을 넘친 만큼이 기준이다 — 예약
    /// 상자가 줄 캐시의 줄 상자보다 아래로 나가도 컨테이너는 캐시 높이까지만 담기 때문이다 (각주
    /// 안 표). 각주 끝 블록은 마지막 줄의 줄 간격을 빼고 쌓으므로 그 바닥은 줄 간격을 뺀 상자 아래다.
    private func noteContainerFloor(
        _ commonProperty: CoreHwp.HwpCommonCtrlProperty?,
        placement: Placement,
        since marker: ObjectMarker,
        into collected: inout Objects,
        textBottom: CGFloat? = nil
    ) {
        if Self.raisesContainerFloor(commonProperty, anchor: placement.anchor) {
            collected.noteFloating(since: marker)
            return
        }
        guard let anchor = placement.anchor, anchor.reservesSpace else { return }
        let reservedBottom = anchor.origin.y + anchor.reserved.height
        collected.noteFloating(
            since: marker, exceeding: textBottom.map { min($0, reservedBottom) } ?? reservedBottom
        )
    }

    /// 문단에 붙은 표를 컨테이너-로컬 rect로 재귀 레이아웃한다 (#94).
    ///
    /// 폭은 저작대로 두고 위치만 앵커에 맞춘다 — 한글.app 실측 (헌법주석 883쪽 각주 29):
    /// 408pt 표가 문단 들여쓰기(≈17.9pt) 위치에서 시작해 오른쪽 본문 경계를
    /// 12.6pt 넘어가고, 한글은 그것을 자르거나 줄이지 않는다. 문단 폭보다 넓은 표도 줄이지
    /// 않는다 (#254 — 각주 안 450pt 표가 본문 425.2pt를 넘겨 그려진다). 문단 rect 폭은 저작
    /// 폭이 없는 표의 폴백일 뿐이다. 흐름을 차지하는 표(자리 차지·어울림)는 바깥 상자(표 + 좌우
    /// 바깥 여백)로 정렬하고 왼쪽 여백만큼 들인다 — 페이지 경로(`HwpPaginator.flowTableOriginX`)와
    /// 같은 규칙·같은 술어(`alignsByOuterBox`)다.
    private func table(
        _ nested: CoreHwp.HwpTable,
        placement: Placement,
        state: inout CollectState
    ) -> HwpNestedTableFrame? {
        let commonProperty = nested.commonCtrlProperty
        let info = commonProperty.propertyInfo
        guard case let .success(frame) = HwpTableLayout(
            fontResolver: fontResolver, attributeCache: attributeCache
        ).layout(
            table: nested,
            availableWidth: placement.paragraphRect.width,
            index: index,
            sizeResolver: sizeResolver,
            numbering: placement.numbering
        ) else { return nil }
        let size = frame.outerFrame.size
        // 바깥 상자 정렬은 흐름을 차지하는 표의 규칙이다 — 페이지 경로와 같은 술어.
        let margins = Self.alignsByOuterBox(commonProperty)
            ? HwpObjectAnchorGeometry.OuterMargins(commonProperty) : .zero
        var tableOrigin = origin(
            commonProperty: commonProperty,
            size: CGSize(width: size.width + margins.horizontal, height: size.height),
            placement: placement, cursorX: state.cursorX
        )
        tableOrigin.x += margins.left
        let rect = CGRect(origin: tableOrigin, size: size)
        if commonProperty.propertyInfo.treatAsChar, placement.anchor == nil {
            state.cursorX += size.width
        }
        defer { state.sourceOrder += 1 }
        return HwpNestedTableFrame(
            rect: rect,
            table: frame,
            controlInstanceId: commonProperty.instanceId,
            paintsBehindText: info.textWrap == .behindText,
            zOrder: commonProperty.zOrder,
            sourceOrder: state.sourceOrder,
            controlIndex: placement.controlIndex,
            paragraphId: placement.paragraphId
        )
    }

    /// 줄이 컨트롤 마커에 내준 자리 — 위치와 **예약 치수**.
    ///
    /// 예약이 0인 앵커가 실재한다: run builder는 U+FFFC + `controlIndex`를 늘 심고
    /// tofu 글리프를 감추려 폭 0 run delegate를 달므로, 예약 크기를 못 구한 개체
    /// (`inlineObjectReservation`가 nil — 공통 속성이 없는 레거시 도형) 도 앵커를 얻는다.
    /// 위치만 보면 "줄이 담았다"로 오해한다 (R53).
    struct LineAnchor {
        let origin: CGPoint
        /// 줄이 실제로 잡아 준 상자 — run delegate의 (width, ascent)
        let reserved: CGSize

        /// 줄이 이 개체의 자리를 잡았는가. 높이가 곧 delegate ascent다.
        var reservesSpace: Bool {
            reserved.height > 0
        }
    }

    /// 개체 배치 문맥 — 줄 앵커 (없으면 커서 흐름 배치)와 문단 rect
    private struct Placement {
        let anchor: LineAnchor?
        let paragraphRect: CGRect
        /// 이 개체를 낸 `ctrlHeaderArray` 서수 — 감싼 `%hlk` 스팬을 개체와 잇는
        /// 열쇠라 수집 페이로드까지 실어 보낸다 (R50). 서수는 문단마다 0부터
        /// 다시 시작하므로 문단 id와 **쌍**으로만 유일하다 (R51 #1).
        let controlIndex: Int
        let paragraphId: UInt32
        /// 이 컨트롤이 품은 문단들의 번호 열쇠 (#158) — 글상자·표 레이아웃에 넘긴다.
        let numbering: HwpNumberingScope.Container?

        func origin(cursorX: CGFloat) -> CGPoint {
            anchor?.origin ?? CGPoint(x: cursorX, y: paragraphRect.minY)
        }
    }

    /// 컴포넌트 하나를 종류별 (그림 → 글상자 → 도형)로 수집한다.
    /// `componentOffset`은 이 요소 앞 요소들의 글상자 문단 수 — 글상자 문단의
    /// 번호 경로 서수가 개체 전체를 펼친 서수라서다 (#158).
    private func collect(
        component: CoreHwp.HwpShapeComponent,
        commonProperty: CoreHwp.HwpCommonCtrlProperty?,
        placement: Placement,
        componentOffset: Int,
        state: inout CollectState,
        into collected: inout Objects
    ) {
        // 커서 전진은 줄 흐름 배치 (글자처럼 취급 + 앵커 없음)에만 —
        // 떠 있는 개체는 저작 위치라 흐름을 소비하지 않는다 (R30 #1)
        let advancesCursor = (commonProperty?.propertyInfo.treatAsChar ?? true)
            && placement.anchor == nil
        if !component.pictureArray.isEmpty {
            guard let size = resolvedSize(
                commonProperty: commonProperty, component: component
            ) else { return }
            for picture in component.pictureArray {
                guard let image = image(
                    picture: picture,
                    size: size,
                    commonProperty: commonProperty,
                    origin: origin(
                        commonProperty: commonProperty, size: size,
                        placement: placement, cursorX: state.cursorX
                    ),
                    sourceOrder: state.sourceOrder,
                    controlIndex: placement.controlIndex,
                    paragraphId: placement.paragraphId
                ) else { continue }
                collected.images.append(image)
                state.sourceOrder += 1
                if advancesCursor {
                    state.cursorX += image.rect.width
                }
            }
            return
        }
        if !component.textBoxListArray.isEmpty {
            guard collectsTextboxes, let textbox = textbox(
                component: component,
                commonProperty: commonProperty,
                placement: placement,
                componentOffset: componentOffset,
                state: state
            ) else { return }
            collected.textboxes.append(textbox)
            state.sourceOrder += 1
            if advancesCursor {
                state.cursorX += textbox.rect.width
            }
            return
        }
        guard let shape = shape(
            component: component,
            commonProperty: commonProperty,
            placement: placement,
            state: state
        ) else { return }
        collected.shapes.append(shape)
        state.sourceOrder += 1
        if advancesCursor {
            state.cursorX += shape.rect.width
        }
    }

    /// 개체 origin — 글자처럼 취급은 줄 앵커 (없으면 커서 흐름), 떠 있는
    /// 개체는 저작 오프셋+정렬 (흐름 경로 anchoredObjectFrame의 문단 기준
    /// 근사 — 컨테이너 안에는 종이/쪽/단 기하가 없어 문단 rect 기준) (R30 #1).
    private func origin(
        commonProperty: CoreHwp.HwpCommonCtrlProperty?,
        size: CGSize,
        placement: Placement,
        cursorX: CGFloat
    ) -> CGPoint {
        guard let commonProperty, !commonProperty.propertyInfo.treatAsChar else {
            // 줄 앵커는 바깥 상자의 원점 — 개체는 바깥 여백만큼 안이다 (#193). 자리를 예약하지
            // 않은 앵커(한 축 0)는 바깥 상자가 없어 들이지 않는다 (페이지 경로와 같은 판정).
            guard placement.anchor?.reservesSpace == true else {
                return placement.origin(cursorX: cursorX)
            }
            return HwpObjectAnchorGeometry.inlineObjectOrigin(
                outerBoxOrigin: placement.origin(cursorX: cursorX), margins: .init(commonProperty)
            )
        }
        let rect = placement.paragraphRect
        let offsetX = HwpUnits.points(
            fromHwpUnit: Int32(bitPattern: commonProperty.horizontalOffset)
        )
        let offsetY = HwpUnits.points(
            fromHwpUnit: Int32(bitPattern: commonProperty.verticalOffset)
        )
        // 세로 기준 '문단'은 페이지 경로 (anchoredObjectFrame vRef extent 0)와
        // 동일하게 정렬 무효, 종이/쪽은 컨테이너 밖 기하가 없어 문단 rect로
        // 근사한다 (R32 #3).
        let verticalExtent: CGFloat = switch commonProperty.propertyInfo.verticalRelativeTo {
        case .paper, .page, nil: rect.height
        case .paragraph: 0
        }
        return CGPoint(
            x: HwpObjectAnchorGeometry.aligned(
                base: rect.minX, extent: rect.width, size: size.width,
                alignment: commonProperty.propertyInfo.horizontalAlignment
            ) + offsetX,
            y: HwpObjectAnchorGeometry.aligned(
                base: rect.minY, extent: verticalExtent, size: size.height,
                alignment: commonProperty.propertyInfo.verticalAlignment
            ) + offsetY
        )
    }

    /// controlIndex 마커의 줄 앵커 (문단 rect 기준 좌표 + 줄이 예약한 치수) —
    /// 좌표 산식은 HwpPaginator.inlineAnchorMap과 같다 (`HwpObjectAnchorGeometry`).
    ///
    /// 예약 치수를 **버리지 않는다**: 크기 0인 앵커와 실제로 자리를 잡은 앵커는
    /// 컨테이너 높이 하한에서 갈린다 (`escapesLineBox`, R53).
    private func lineAnchor(
        for controlIndex: Int,
        frame: HwpParagraphFrame,
        paragraphRect: CGRect
    ) -> LineAnchor? {
        for line in frame.lines {
            for anchor in line.inlineAnchors where anchor.controlIndex == controlIndex {
                return LineAnchor(
                    origin: HwpObjectAnchorGeometry.inlineAnchorOrigin(
                        paragraphOrigin: paragraphRect.origin, line: line, anchor: anchor
                    ),
                    reserved: CGSize(width: anchor.width, height: anchor.ascent)
                )
            }
        }
        return nil
    }
}

// MARK: - 컴포넌트 → 개체 변환

/// 개체 요소 (그림/글상자/도형)와 표를 컨테이너-로컬 rect의 페이로드로 바꾸는
/// 팩토리. 크기 해석 (`resolvedSize`)과 배치 (`origin`)는 위 본체가 소유하고,
/// 여기서는 종류별 페이로드 조립만 한다.
private extension HwpParagraphObjectCollector {
    /// 개체의 해석 크기 — 저장 크기가 0 이하이면 개체 요소 detail의
    /// 현재 크기로 폴백하고, 그래도 0 이하이면 nil (그리지 않음).
    func resolvedSize(
        commonProperty: CoreHwp.HwpCommonCtrlProperty?,
        component: CoreHwp.HwpShapeComponent
    ) -> CGSize? {
        let stored = commonProperty.map {
            HwpObjectSizeResolver.size(of: $0, resolver: sizeResolver)
        } ?? .zero
        var width = stored.width
        var height = stored.height
        if width <= 0 || height <= 0, let detail = component.detail {
            if width <= 0 {
                width = HwpUnits.points(fromHwpUnitU: detail.currentWidth)
            }
            if height <= 0 {
                height = HwpUnits.points(fromHwpUnitU: detail.currentHeight)
            }
        }
        guard width > 0, height > 0 else { return nil }
        return CGSize(width: width, height: height)
    }

    func image(
        picture: CoreHwp.HwpShapeComponentPicture,
        size: CGSize,
        commonProperty: CoreHwp.HwpCommonCtrlProperty?,
        origin: CGPoint,
        sourceOrder: Int,
        controlIndex: Int,
        paragraphId: UInt32
    ) -> HwpCellImage? {
        let property = picture.pictureProperty
        guard let binItemId = property.map({ UInt32($0.binItemId) })
            ?? picture.binaryDataId.map(UInt32.init)
        else { return nil }
        var borderColor: HwpRGBColor?
        var borderWidth: CGFloat = 0
        if let property, property.borderThickness > 0 {
            borderColor = HwpRGBColor(property.borderColor)
            borderWidth = HwpUnits.points(fromHwpUnit: property.borderThickness)
        }
        // 렌더는 비트맵 전체를 rect에 스케일하므로 폭을 문단 경계로 자르면
        // 잘림이 아니라 왜곡이 된다 — 저작 크기를 그대로 쓴다 (R31 #2).
        return HwpCellImage(
            rect: CGRect(origin: origin, size: size),
            binItemId: binItemId,
            style: property.map { HwpImageRenderStyle(pictureProperty: $0) },
            borderColor: borderColor,
            borderWidth: borderWidth,
            paintsBehindText: commonProperty?.propertyInfo.textWrap == .behindText,
            zOrder: commonProperty?.zOrder ?? 0,
            sourceOrder: sourceOrder,
            controlInstanceId: commonProperty?.instanceId ?? 0,
            controlIndex: controlIndex,
            paragraphId: paragraphId
        )
    }

    private func textbox(
        component: CoreHwp.HwpShapeComponent,
        commonProperty: CoreHwp.HwpCommonCtrlProperty?,
        placement: Placement,
        componentOffset: Int,
        state: CollectState
    ) -> HwpCellTextbox? {
        // 흐름 경로 (appendShapeObjectBlocks 호출부)와 동일한 기본 property
        // 폴백. 억제 (collectible)는 property를 보지 않는다 — nil 수집 거부는
        // 흐름·컨테이너 양쪽 모두 렌더하지 않는 소실이 된다 (R30 #4).
        let property = commonProperty ?? CoreHwp.HwpCommonCtrlProperty()
        guard let frame = HwpTextboxLayout(
            fontResolver: fontResolver, attributeCache: attributeCache
        ).layout(
            components: [component],
            commonProperty: property,
            fallbackWidth: placement.paragraphRect.width,
            index: index,
            sizeResolver: sizeResolver,
            // 요소 하나만 넘기므로 그 요소 앞 글상자 문단 수를 서수에 더해야
            // 개체 전체를 펼친 `childParagraphSequence`의 서수와 맞는다 (#158).
            numbering: placement.numbering,
            childOffset: componentOffset
        ) else { return nil }
        let size = frame.outerFrame.size
        return HwpCellTextbox(
            rect: CGRect(
                origin: origin(
                    commonProperty: commonProperty, size: size,
                    placement: placement, cursorX: state.cursorX
                ),
                size: size
            ),
            textbox: frame,
            paintsBehindText: property.propertyInfo.textWrap == .behindText,
            zOrder: property.zOrder,
            sourceOrder: state.sourceOrder,
            controlInstanceId: property.instanceId,
            controlIndex: placement.controlIndex,
            paragraphId: placement.paragraphId
        )
    }

    private func shape(
        component: CoreHwp.HwpShapeComponent,
        commonProperty: CoreHwp.HwpCommonCtrlProperty?,
        placement: Placement,
        state: CollectState
    ) -> HwpCellShape? {
        guard let size = resolvedSize(commonProperty: commonProperty, component: component),
              let geometry = HwpShapeGeometry.build(component: component, size: size)
        else { return nil }
        return HwpCellShape(
            rect: CGRect(
                origin: origin(
                    commonProperty: commonProperty, size: size,
                    placement: placement, cursorX: state.cursorX
                ),
                size: size
            ),
            geometry: geometry,
            paintsBehindText: commonProperty?.propertyInfo.textWrap == .behindText,
            zOrder: commonProperty?.zOrder ?? 0,
            sourceOrder: state.sourceOrder,
            controlInstanceId: commonProperty?.instanceId ?? 0,
            controlIndex: placement.controlIndex,
            paragraphId: placement.paragraphId
        )
    }
}
