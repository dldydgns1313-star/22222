import CoreGraphics
import CoreText
import Foundation

/// `.drawText` 명령 하나의 렌더-정합 줄 하나.
///
/// `line`은 양쪽 정렬 재조판 (`HwpWordJustification`)이 반영된 최종 CTLine이라
/// 글리프 x 오프셋 질의 (`CTLineGetOffsetForStringIndex` 등)가 화면과 일치한다.
public struct HwpDrawnLine {
    /// 실제로 그려지는 CTLine (재조판본이면 단위 문자열의 부분 복사본)
    public let line: CTLine
    /// 단위 attributedString 기준 문자 범위 (재조판과 무관하게 원본 범위)
    public let stringRange: NSRange
    /// 페이지 로컬 top-down 좌표의 베이스라인 시작점 (배분 정렬 xOffset 포함)
    public let baselineOrigin: CGPoint
    public let ascent: CGFloat
    public let descent: CGFloat
    /// 이 줄이 **문단의 마지막 줄**인지 — 단위 문자열의 끝에 닿고 그 문자열이 다음 단·
    /// 쪽으로 이어지는 조각(`hwp.continuedParagraphFragment`)이 아닐 때(양쪽 정렬의
    /// 마지막 줄 판정과 같은 규약), 또는 문자열 안에서 한 줄 끝 표식(`hwp.lineBreak`)이
    /// 아닌 문단 구분자로 끝날 때(문단들을 `\n`으로 이은 결합 문자열 —
    /// `HwpDrawnTextLayout.endsParagraph(_:in:)`). 렌더러와 세로 배치는 MS 워드 호환 문단
    /// 끝 상자(`hwp.msWordParagraphEndBox`, #187·#194)를 이 줄의 줄 상자에만 합친다 — 상자는
    /// 문단 전체에 실리므로 줄 판정은 키가 아니라 이 값이다. 이어짐 표식은 쪽 흐름·절대
    /// 캐시 run·다단 균형·표 행·각주의 모든 분할 경로가 단다 (PR 리뷰).
    public let endsParagraph: Bool
    /// 줄 상자 상단 (top-down 페이지 좌표) — `HwpDrawnTextLayout.lines`가 이 줄을 놓은 자리다
    /// (baseline = 상자 상단 + 앵커). 아래 둘과 함께 링크 클릭 띠(#233, `ClickBand`)가 쓴다 —
    /// 줄을 놓은 바로 그 기하라 문단 안 줄의 띠 하단이 다음 줄 상자 상단과 비트 단위로 같다.
    let boxTop: CGFloat
    /// 줄 상자 높이 (한글 줄 캐시의 `vertsize`, `LineMetrics.boxHeight`)
    let boxHeight: CGFloat
    /// 줄 자신의 전진량 — 줄 상자 × 줄 간격 규칙 (`HwpLineAdvance.lineAdvance`), 문단 사이 간격 제외
    let lineAdvance: CGFloat

    /// 줄의 선택 하이라이트 영역 (top-down 페이지 좌표)
    ///
    /// **글자 위치(`hwp.glyphBaselineOffset`)로 옮겨진 글리프를 따라가지 않는다** — 한글도
    /// 그렇다 (2026-09-14 실측: `CharShape` 픽스처의 '글자위치 30' 줄만 선택하면 하이라이트
    /// 상단이 이웃 줄들과 **같은 격자**(81px 간격)에 있고 글리프만 그 안에서 7px 내려간다).
    /// 잉크가 닿는 범위가 필요한 쪽은 `paintedRect`다.
    public var selectionRect: CGRect {
        let width =
            CGFloat(CTLineGetTypographicBounds(line, nil, nil, nil))
                - CGFloat(CTLineGetTrailingWhitespaceWidth(line))
        return CGRect(
            x: baselineOrigin.x,
            y: baselineOrigin.y - ascent,
            width: width,
            height: ascent + descent
        )
    }
}

/// `.drawText(attributedString:origin:lineWidth:)`의 줄 배치를 렌더러와 동일한
/// 규칙 (slight-overflow 단일 줄, 양쪽 정렬 재조판, 베이스라인 앵커)으로 계산한다.
/// 렌더러 (`HwpPageLayer`)와 텍스트 선택이 이 함수를 공유해 지오메트리가
/// 정의상 일치한다. 좌표는 top-down 페이지 로컬 — 렌더러가 자신의 y-up
/// 공간으로 변환해 그린다.
public enum HwpDrawnTextLayout {
    public static func lines(
        attributedString: NSAttributedString,
        origin: CGPoint,
        lineWidth: CGFloat,
        maxLineFrames: Int = HwpParagraphLayout.maximumLineFrames
    ) -> [HwpDrawnLine] {
        if let single = slightOverflowSingleLine(
            attributedString: attributedString, origin: origin, lineWidth: lineWidth
        ) {
            return [single]
        }

        let framesetter = CTFramesetterCreateWithAttributedString(attributedString)
        let typesetter = CTTypesetterCreateWithAttributedString(attributedString)
        let fullLength = attributedString.length
        let lineBudget = max(0, maxLineFrames)
        // 측정(HwpParagraphLayout.layout)과 HwpLineBreaker.nextFrameChunk를 공유해
        // 청크 경계를 실제 CTLine 시작에 맞춘다 — 미완 줄은 버려 다음 청크에서 온전히
        // 재조판, 넓은 단일 줄은 안 쪼갠다. 단일 청크(모든 정상 블록)는 문단 전체가
        // 한 프레임이라 렌더 불변 (R48·R50).
        var result: [HwpDrawnLine] = []
        var startLocation = 0
        // 다음 청크 첫 줄의 **줄 상자 상단** top-down y — 첫 청크는 블록 상단이고, 이월은
        // 앞 청크 마지막 줄 상자 상단 + 그 줄 전진량이다. baseline이 아니라 상자 상단을
        // 넘긴다: 버린 미완 줄은 다음 청크에서 온전히 재조판되며 앵커(상자 높이)가 달라질 수
        // 있어, baseline을 넘기면 그 앵커가 소거되지 않아 뒤 줄 전체가 밀린다 (#178).
        var boxTop = origin.y
        while startLocation < fullLength, result.count < lineBudget {
            guard let chunk = HwpLineBreaker.nextFrameChunk(
                framesetter: framesetter, typesetter: typesetter,
                attributedString: attributedString,
                startLocation: startLocation, fullLength: fullLength,
                remainingLineBudget: lineBudget - result.count, lineWidth: lineWidth
            ) else { break }
            // 줄 상자 상단과 baseline — 첫 줄 상자 상단은 블록 상단(이월이면 재개 상자
            // 상단)에 핀하고, 나머지는 줄별 전진량으로 타일한다 (`lineGeometries`).
            let geometries = Self.lineGeometries(of: chunk, in: attributedString, base: boxTop)
            for index in 0 ..< chunk.keepCount {
                result.append(drawnLine(
                    frameLine: chunk.lines[index],
                    attributedString: attributedString,
                    placement: Placement(
                        geometry: geometries[index],
                        originX: origin.x,
                        ctOriginX: chunk.origins[index].x
                    ),
                    lineWidth: lineWidth
                ))
            }
            if let last = geometries.last {
                boxTop = last.boxTop + last.advance
            }
            guard chunk.nextStart > startLocation else { break }
            startLocation = chunk.nextStart
        }
        return result
    }

    /// 한 줄이 놓일 자리 — `geometry`는 `lines`가 `lineGeometries`로 구한 top-down 세로
    /// 기하다. **baseline은 앵커가 정한다** (#178) — CT·글꼴의 ascent는 세로 배치에
    /// 쓰이지 않는다.
    private struct Placement {
        let geometry: LineGeometry
        /// 블록 원점 x
        let originX: CGFloat
        /// CT가 준 이 줄의 프레임 내 x (문단 들여쓰기·정렬)
        let ctOriginX: CGFloat
    }

    private static func drawnLine(
        frameLine: CTLine,
        attributedString: NSAttributedString,
        placement: Placement,
        lineWidth: CGFloat
    ) -> HwpDrawnLine {
        let replacement = HwpWordJustification.justifiedLine(
            frameLine: frameLine,
            attributedString: attributedString,
            availableWidth: lineWidth - placement.ctOriginX,
            lineOriginX: placement.ctOriginX
        )
        let range = CTLineGetStringRange(frameLine)
        let finalLine = replacement?.line ?? frameLine
        var ascent: CGFloat = 0
        var descent: CGFloat = 0
        _ = CTLineGetTypographicBounds(finalLine, &ascent, &descent, nil)
        return HwpDrawnLine(
            line: finalLine,
            stringRange: NSRange(location: range.location, length: range.length),
            baselineOrigin: CGPoint(
                x: placement.originX + placement.ctOriginX + (replacement?.xOffset ?? 0),
                y: placement.geometry.baseline
            ),
            ascent: ascent,
            descent: descent,
            endsParagraph: endsParagraph(range, in: attributedString),
            boxTop: placement.geometry.boxTop,
            boxHeight: placement.geometry.boxHeight,
            lineAdvance: placement.geometry.lineAdvance
        )
    }

    /// `range`로 끝나는 줄이 문단의 마지막 줄인지 (`HwpDrawnLine.endsParagraph`).
    ///
    /// 두 갈래다. ① 문자열 끝에 닿는 줄 — 그 문자열이 다음 단·쪽으로 이어지는 조각
    /// (`hwp.continuedParagraphFragment`)이 아닐 때. ② 문자열 **안**의 문단 끝 — 줄의 마지막
    /// 글자가 한 줄 끝 표식(`hwp.lineBreak`, 같은 문단의 줄 나눔)이 아닌 문단 구분자(LF·CR·
    /// U+2029)일 때. 컨테이너 블록이 문단들을 `\n`으로 이은 결합 문자열과 공개 `drawText`
    /// 호출자의 여러 문단 문자열은 앞 문단들이 ②로 끝난다 — 문단 사이 간격
    /// (`HwpLineAdvance.paragraphGap`)과 같은 판정이고, 문자열 끝만 보면 앞 문단의 MS 워드
    /// 호환 끝 상자(`hwp.msWordParagraphEndBox`)가 빠져 그 줄의 베이스라인·밑줄이 어긋난다
    /// (PR 리뷰: Apple SD 10pt 본문 + Menlo 30pt 끝 상자 문단이 결합되면 33.09 → 10.8pt).
    static func endsParagraph(_ range: CFRange, in attributedString: NSAttributedString) -> Bool {
        let length = attributedString.length
        let end = range.location + range.length
        guard length > 0, end > 0 else { return false }
        if end >= length {
            return attributedString.attribute(
                HwpAttributedStringKey.continuedParagraphFragment, at: length - 1, effectiveRange: nil
            ) == nil
        }
        let text = attributedString.string as NSString
        guard end <= text.length, HwpLineAdvance.isParagraphSeparator(text.character(at: end - 1))
        else { return false }
        return attributedString.attribute(
            HwpAttributedStringKey.lineBreak, at: end - 1, effectiveRange: nil
        ) == nil
    }

    /// attributedString 안 `hyperlink` 속성 범위마다 줄별 링크 rect와 URL을
    /// 돌려준다 (페이지 로컬 top-down). 블록 전체가 아니라 링크 텍스트에만
    /// 히트/오버레이를 스코프하는 데 쓴다 (#2). rect는 스팬의 run이 화면에서 잇닿은
    /// 구간마다 하나다 — 양방향 줄에서는 한 스팬이 여럿을 낸다 (#201,
    /// `appendHyperlinkRects`). 재조판된 CTLine은 자체 범위가 0-기준 sub-copy라,
    /// attributedString index를 CTLine index로 옮겨 run 범위와 댄다.
    ///
    /// 세로 범위는 글꼴 지표가 아니라 **한글의 줄 클릭 띠**다 (#233) — 줄 상자 상단부터 그
    /// 줄의 줄 간격 몫까지(다음 줄 상자 상단까지)라 줄 상자 바닥에 붙는 밑줄(#226)과 글자·밑줄
    /// 사이 빈칸을 누르면 링크가 열린다. 이 함수는 문자열 뒤에 무엇이 오는지 모르므로 마지막
    /// 줄의 띠를 줄 간격 몫과 줄 상자 가운데 넓은 쪽까지 둔다 — 표 셀·글상자·각주의 마지막 줄은
    /// 한글처럼 줄 상자에서 끝나므로, 그런 블록의 권위 있는 링크 기하는 paint list의
    /// `.hyperlink` 명령(`HwpPaintListBuilder.build(for:)`)과 `HwpHitTester`다. 규칙과 한글
    /// 실측은 `ClickBand`.
    public static func hyperlinkRegions(
        attributedString: NSAttributedString,
        origin: CGPoint,
        lineWidth: CGFloat
    ) -> [(rect: CGRect, url: String)] {
        hyperlinkRegions(
            attributedString: attributedString, origin: origin, lineWidth: lineWidth,
            listEnd: .unknown
        )
    }

    /// `hyperlinkRegions(attributedString:origin:lineWidth:)`에 문자열 **뒤에 무엇이 오는지**
    /// (`ListEnd`)를 더한 형태 — 문자열의 마지막 줄 클릭 띠의 하단이 그것으로 정해진다
    /// (`ClickBand`: 한글은 표 셀·글상자·각주의 마지막 줄 아래를 눌러도 링크를 열지 않는다).
    /// 컨테이너 문단 배열을 걷는 방출(`HwpPaintListBuilder`)과 히트(`HwpHitTester`)가 같은
    /// 판정으로 넘긴다 — 마지막 문단은 `.end`, 나머지는 `.followed`, 본문 블록은 `.unknown`.
    static func hyperlinkRegions(
        attributedString: NSAttributedString,
        origin: CGPoint,
        lineWidth: CGFloat,
        listEnd: ListEnd
    ) -> [(rect: CGRect, url: String)] {
        let length = attributedString.length
        guard length > 0 else { return [] }
        var regions: [(rect: CGRect, url: String)] = []
        // 하이퍼링크 속성이 있는 블록만 CT 재조판한다 (블록마다 framesetting 방지)
        var cachedLines: [HwpDrawnLine]?
        // 줄별 스팬 기하도 줄 캐시 옆에 같이 둔다: 밴드(`glyphOffsetBands`)는 줄의 CTRun을
        // 전수로 돌며 CTRunGetAttributes를 브리징하는데, 스팬마다 다시 부르면 (스팬 × 줄)
        // 만큼 값을 치른다 — 옮겨진 run이 하나도 없어도 그렇다 (실측 median: 40스팬 ~13줄
        // 1.16 → 0.74ms, 120스팬 ~40줄 4.02 → 2.91ms). run별 진행 폭 범위(#201)는 스팬이
        // 닿는 줄만 그 자리에서 채운다.
        var geometries: [SpanLineGeometry] = []
        attributedString.enumerateAttribute(
            HwpAttributedStringKey.hyperlink, in: NSRange(location: 0, length: length)
        ) { value, range, _ in
            guard let url = value as? String else { return }
            if cachedLines == nil {
                let drawnLines = lines(
                    attributedString: attributedString, origin: origin, lineWidth: lineWidth
                )
                cachedLines = drawnLines
                let lastIndex = drawnLines.count - 1
                geometries = glyphOffsetBands(ofLines: drawnLines, in: attributedString)
                    .enumerated()
                    .map { index, bands in
                        SpanLineGeometry(
                            bands: bands, runExtents: nil,
                            listEnd: index == lastIndex ? listEnd : .followed
                        )
                    }
            }
            guard let drawnLines = cachedLines else { return }
            for (lineIndex, drawn) in drawnLines.enumerated() {
                appendHyperlinkRects(
                    of: drawn, spanRange: range, geometry: &geometries[lineIndex],
                    url: url, into: &regions
                )
            }
        }
        return regions
    }

    /// 그려진 텍스트의 줄 상자들 — "이 지점에 글자가 칠해졌는가" 판정용 (R54).
    ///
    /// 선택 하이라이트(`HwpDrawnLine.selectionRect`)에 **글자 위치로 옮겨진 run마다 그
    /// run의 잉크 가로 범위만** 더한 `paintedRects`를 쓴다 — 줄 전체 폭에 최대 오프셋을
    /// 걸면 안 옮겨진 run 아래의 빈 띠까지 claim해 그 자리의 탭이 뒤 층의 보이는 링크를
    /// 막는다. 문단 rect를 쓰지 않는 이유는 종전과 같다 — 줄 사이 여백과 짧은 줄의 빈
    /// 오른쪽까지 품어, 그것으로 claim하면 아무것도 안 그린 자리에서 아래 블록의 보이는
    /// 링크를 막는다. 반대로 줄 상자만 쓰면 **그려진** 글자가 claim 밖으로 나가 그 위의
    /// 탭이 뒤 층으로 내려간다(한글은 선택 상자를 안 옮기지만 칠은 옮긴다 —
    /// `selectionRect`의 실측 주석).
    public static func textLineRegions(
        attributedString: NSAttributedString,
        origin: CGPoint,
        lineWidth: CGFloat
    ) -> [CGRect] {
        guard attributedString.length > 0 else { return [] }
        let drawnLines = lines(
            attributedString: attributedString, origin: origin, lineWidth: lineWidth
        )
        let bandsByLine = glyphOffsetBands(ofLines: drawnLines, in: attributedString)
        return zip(drawnLines, bandsByLine).flatMap { $0.paintedRects(bands: $1) }
    }

    /// slight-overflow 한 줄의 CTLine과 타이포그래피 메트릭.
    public struct SlightOverflowLine {
        public let line: CTLine
        public let ascent: CGFloat
        public let descent: CGFloat
        public let leading: CGFloat
    }

    /// 개행 없는 문단이 허용 배율 (`HwpRenderTuning.Text.slightOverflowWidthRatio`)
    /// 이내로 폭을 넘는 한 줄인지 — 렌더 (slightOverflowSingleLine)와 측정
    /// (`HwpParagraphLayout.layout`)이 이 술어를 공유해 "측정은 2줄 ↔ 렌더는
    /// 1줄" 어긋남 (문단 높이·페이지 절단 vs 실제 잉크)을 구조적으로 막는다.
    ///
    /// **문단 전체**의 규칙이다 — 문단을 잰 줄에서 잘라낸 조각
    /// (`HwpAttributedStringKey.measuredLineFragment`)에는 적용하지 않는다 (#166). 조각
    /// 블록의 높이는 문단 전체 측정의 줄바꿈에서 왔는데, 문단 전체로는 접히지 않던 두
    /// 줄이 조각만으로는 허용 배율 안에 들 수 있어 여기서 접으면 측정은 2줄 ↔ 렌더는
    /// 1줄이 되고 조각 아래가 빈다. 측정(`layout`)도 같은 술어를 쓰므로 조각을 다시
    /// 재는 경로(비등폭 단 이월의 `HwpPaginator.fragmentAnchorLines`)와 렌더가 같이 간다.
    ///
    /// **글줄의 규칙이기도 하다** (#254) — 개체(글자처럼 취급 표·그림)의 예약 폭만으로 그 줄의
    /// **가용 폭**(컨테이너 폭에서 첫 줄 들여쓰기·오른쪽 여백을 뺀 폭)을 넘는 줄은 글꼴 차이로 살짝
    /// 넓어진 글줄이 아니라 한글에서도 넘치는 줄이다. 한글은 그런 개체를 정렬과 무관하게 줄 시작에
    /// 두고 뒤 글자·뒤 개체를 다음 줄로 보내므로(한컴오피스 한글 12.30 실측 —
    /// `HwpLineBreaker.overflowStartAligned`), 이 한 줄 허용으로 접거나 정렬 오프셋(가운데 반씩·
    /// 오른쪽 음수)을 주지 않고 공유 줄바꿈 코어에 맡긴다. 컨테이너 폭이 아니라 가용 폭과 비교해야
    /// 문단 폭 385pt의 400pt 표가 뒤 글자 유무에 따라 줄 시작(105.04)과 원점 0(85.04)으로 갈리지
    /// 않는다 — 개체 폭은 한글과 같은 값이라 그 합이 넘치는 줄은 글꼴 허용의 대상이 아니다.
    ///
    /// 같은 이유로 **개체가 있는 줄은 글자 몫만 허용 배율로 잰다** (#254 PR 리뷰) — 글꼴 차로
    /// 넓어지는 것은 글자뿐이므로, 글자 몫(자연 폭 − 개체 폭)이 개체가 남긴 폭(가용 폭 − 개체 폭)을
    /// 허용 배율 이내로 넘을 때만 한 줄로 접는다. 줄 전체로 재면 가용 폭을 다 채운 표 뒤 짧은 글자가
    /// 남은 폭 0에도 한 줄로 접혀 표 오른쪽 밖에 그려지고 측정은 한 줄 모자란다. 한컴오피스 한글
    /// 12.30(build 6523) 실측(`probes/254/review` so254-suffix, 본문 425.2pt): 단 기준·문단 기준
    /// 100% 표와 절대 425.2pt 표 뒤 '뒤', 420pt 표 뒤 '뒤뒤'는 모두 다음 줄에서 시작하고(왼쪽 정렬은
    /// 85.08pt, 가운데 정렬 425.2pt 표 뒤 '뒤'는 다음 줄 가운데 292.8pt — 종전 우리: 상대 기준 두 표는
    /// 510.24pt, 420pt 표는 505.04pt로 같은 줄), 415pt 표 뒤 '뒤'만 같은 줄 500.04pt에 남았다. 개체가
    /// 없는 줄은 종전대로 줄 전체를 잰다.
    public static func slightOverflowLineMetrics(
        attributedString: NSAttributedString,
        lineWidth: CGFloat
    ) -> SlightOverflowLine? {
        // 큰 개행 없는 문단이 청크 캡보다 먼저 전체를 shaping(CTLineCreate)하지
        // 않게 길이로 먼저 거른다 — 한 줄 slight-overflow는 한 줄 폭에 들어가므로
        // maximumLineFrames 문자를 넘으면 단일 줄일 수 없다. 길이 체크를
        // contains("\n")(전체 스캔) 앞에 둬 거대 문자열 materialize도 피한다 (R50 #1).
        guard attributedString.length > 0,
              attributedString.length <= HwpParagraphLayout.maximumLineFrames,
              !isMeasuredLineFragment(attributedString),
              !attributedString.string.contains("\n")
        else { return nil }
        let line = CTLineCreateWithAttributedString(attributedString)
        var ascent: CGFloat = 0
        var descent: CGFloat = 0
        var leading: CGFloat = 0
        // 판정은 줄 끝 공백까지 넣은 typographic 폭 그대로다 (#260) — 내용 폭으로 바꾸면 줄 나눔이
        // 바뀌는 문단이 생기는데(헌법주석 렌더 387·918·971쪽: 한글이 한 줄인 387쪽은 맞고 두 줄인 918·
        // 971쪽은 틀린다) 그 결정에 필요한 것은 폭이 아니라 한글의 줄 수다. 내용 폭은 정렬
        // (`slightOverflowAlignmentOffset`)에만 쓴다 — 접힌 줄은 어느 쪽이든 한 줄이다.
        let naturalWidth = CGFloat(
            CTLineGetTypographicBounds(line, &ascent, &descent, &leading)
        )
        let ratio = HwpRenderTuning.Text.slightOverflowWidthRatio
        guard naturalWidth > lineWidth, naturalWidth <= lineWidth * ratio else { return nil }
        let objects = objectWidth(in: line)
        if objects > 0 {
            let available = availableFirstLineWidth(
                containerWidth: lineWidth, attributedString: attributedString
            )
            guard objects <= available,
                  naturalWidth - objects <= (available - objects) * ratio
            else { return nil }
        }
        return SlightOverflowLine(line: line, ascent: ascent, descent: descent, leading: leading)
    }

    /// 줄의 개체 마커 run(run delegate) 예약 폭 합 (`slightOverflowLineMetrics`).
    private static func objectWidth(in line: CTLine) -> CGFloat {
        guard let runs = CTLineGetGlyphRuns(line) as? [CTRun] else { return 0 }
        return runs.reduce(CGFloat(0)) { total, run in
            let attributes = CTRunGetAttributes(run) as NSDictionary
            guard attributes[kCTRunDelegateAttributeName as String] != nil else { return total }
            let range = CFRange(location: 0, length: 0)
            return total + CGFloat(CTRunGetTypographicBounds(run, range, nil, nil, nil))
        }
    }

    /// 한 줄 문단 첫 줄의 가용 폭 — 컨테이너 폭에서 첫 줄 들여쓰기(`firstLineHeadIndent`)와 오른쪽
    /// 여백(CT `tailIndent` 규약: ≤ 0이면 오른쪽 끝에서, > 0이면 왼쪽 끝에서 잰 절대 위치)을 뺀다.
    private static func availableFirstLineWidth(
        containerWidth: CGFloat,
        attributedString: NSAttributedString
    ) -> CGFloat {
        let style = HwpLineBreaker.paragraphStyle(in: attributedString, at: 0)
        let head = HwpLineBreaker.paragraphCGFloat(.firstLineHeadIndent, in: style) ?? 0
        let tail = HwpLineBreaker.paragraphCGFloat(.tailIndent, in: style) ?? 0
        let trailingEdge = tail > 0 ? tail : containerWidth + tail
        return trailingEdge - head
    }

    /// 문단 전체를 잰 줄에서 잘라낸 조각인지 (#166). 표식은 조각 문자열 전체에
    /// 붙으므로(`HwpParagraphLayout.measuredLineFragment`) 첫 글자만 본다 — 조각을
    /// 다시 자르거나(표 다중 쪽 분할) 마커를 번호로 바꾸는(`renumberingNoteMarkers`,
    /// 바뀐 글자의 속성을 물려받는다) 뒤 가공도 첫 글자의 표식을 보존한다.
    static func isMeasuredLineFragment(_ attributedString: NSAttributedString) -> Bool {
        guard attributedString.length > 0 else { return false }
        return attributedString.attribute(
            HwpAttributedStringKey.measuredLineFragment, at: 0, effectiveRange: nil
        ) != nil
    }

    /// 폭을 허용 배율 이내로 넘는 개행 없는 한 줄 문단이면 줄바꿈 없이
    /// 한 줄로 배치한다. 가운데 정렬이면 초과분을 좌우로 반씩 넘긴다.
    private static func slightOverflowSingleLine(
        attributedString: NSAttributedString,
        origin: CGPoint,
        lineWidth: CGFloat
    ) -> HwpDrawnLine? {
        guard
            let overflow = slightOverflowLineMetrics(
                attributedString: attributedString, lineWidth: lineWidth
            )
        else { return nil }
        let line = overflow.line
        let ascent = overflow.ascent
        let descent = overflow.descent
        let offsetX = slightOverflowAlignmentOffset(
            attributedString: attributedString, lineWidth: lineWidth, line: line
        )
        let metrics = lineMetrics(of: line, in: attributedString)
        return HwpDrawnLine(
            line: line,
            stringRange: NSRange(location: 0, length: attributedString.length),
            baselineOrigin: CGPoint(
                x: origin.x + offsetX,
                y: origin.y + metrics.baselineAnchor
            ),
            ascent: ascent,
            descent: descent,
            endsParagraph: endsParagraph(
                CFRange(location: 0, length: attributedString.length), in: attributedString
            ),
            boxTop: origin.y,
            boxHeight: metrics.boxHeight,
            lineAdvance: HwpLineAdvance.lineAdvance(metrics: metrics, at: 0, in: attributedString)
        )
    }

    /// slight-overflow 한 줄의 가로 오프셋 — 가운데 정렬은 초과분을 좌우로 반씩,
    /// 오른쪽 정렬은 오른쪽 끝을 맞추기 위해 음수 오프셋(x=0 시작이면 잉크가 왼쪽으로
    /// 밀린다, #3). 렌더(`slightOverflowSingleLine`)와 접힌 조각의 한 줄 앵커
    /// (`HwpParagraphLayout.fragmentLineFramesAsDrawn`)가 같은 산식을 써야 개체 앵커
    /// x가 그려진 글자와 맞는다.
    static func slightOverflowAlignmentOffset(
        attributedString: NSAttributedString,
        lineWidth: CGFloat,
        line: CTLine
    ) -> CGFloat {
        guard let style = attributedString.attribute(
            kCTParagraphStyleAttributeName as NSAttributedString.Key,
            at: 0, effectiveRange: nil
        ), CFGetTypeID(style as CFTypeRef) == CTParagraphStyleGetTypeID() else { return 0 }
        // 내용 폭 — 줄 끝 공백(과 매달린 양수 자간)은 정렬에 넣지 않는다. CoreText가 보통 줄을 정렬하는
        // 폭과 같다 (#260: 넣으면 그 몫의 절반·전부만큼 왼쪽으로 밀렸다). 마지막 글자의 자간 중
        // CoreText가 넣고 잰 몫(`lineEndExcess`)도 빼되, 보통 줄의 `lineEndSpacingAligned`처럼 그 몫을 뺀
        // 폭이 줄에 들 때만이다 — 줄 끝 빈칸 하나로 이 경로에 들어온 줄이 자간만큼 튀지 않게 하고(#260
        // 리뷰), 글꼴 차로 정말 넘치는 줄은 보통 경로와 같이 그대로 둔다 (noori 1쪽 가운데 정렬 줄).
        let range = NSRange(location: 0, length: attributedString.length)
        let content = HwpLineBreaker.contentWidth(of: line)
        let excess = HwpLetterSpacing.lineEndExcess(in: attributedString, range: range)
        let naturalWidth = content - excess <= lineWidth + HwpLineBreaker.lineEndTolerance
            ? content - excess : content
        var alignment = CTTextAlignment.natural
        let paragraphStyle = style as! CTParagraphStyle // swiftlint:disable:this force_cast
        CTParagraphStyleGetValueForSpecifier(
            paragraphStyle, .alignment,
            MemoryLayout<CTTextAlignment>.size, &alignment
        )
        switch alignment {
        case .center: return (lineWidth - naturalWidth) / 2
        case .right: return lineWidth - naturalWidth
        default: return 0
        }
    }
}
