import CoreGraphics
import CoreText
import Foundation

// 글자 위치(표 33)로 옮겨진 글리프와 **기하 질의** (#197 리뷰).
//
// 조판 문자열은 `kCTBaselineOffset`을 싣지 않으므로(한글처럼 줄 상자를 안 키우려고)
// CT가 대신 rect를 부풀려 주지 않는다 — 옮겨진 잉크를 덮어야 하는 쪽이 직접 걷는다.

public extension HwpDrawnLine {
    /// 잉크가 실제로 닿는 범위 — 줄 상자(`selectionRect`) **+ 옮겨진 run마다 그 run의
    /// 잉크 가로 범위만** 가진 밴드 (top-down 페이지 좌표).
    ///
    /// "이 지점에 글자가 칠해졌는가"(claim)와 "링크를 눌렀는가"(히트)는 **옮겨진
    /// 글리프**를 따라야 한다 — 안 그러면 보이는 글자를 눌러도 링크가 안 열린다
    /// (실측: Helvetica 10pt 링크에 글자 위치 30이면 잉크 하단 3.000pt가 줄 상자 밖이라
    /// 하단 클릭이 `.text`로 떨어지고, 위치 100에서는 겹침이 0%가 된다).
    ///
    /// **하나의 rect로 합치지 않는다** (#197 리뷰 2차): 줄 전체 폭에 최대 오프셋을 걸면
    /// 안 옮겨진 run 아래의 **빈 공간까지 칠한 것으로 claim**해, 그 자리의 탭이 뒤 층의
    /// 보이는 링크를 막는다 ('ABBBBBBBBBB'에서 A만 10pt 내리면 B 아래 빈 띠가 그렇다).
    /// claim은 정밀 커버리지여야 한다는 규약(R54) 그대로다.
    var paintedRects: [CGRect] {
        paintedRects(bands: HwpDrawnTextLayout.glyphOffsetBands(of: line))
    }
}

extension HwpDrawnLine {
    /// 밴드를 이미 걷어 둔 호출자용 (`HwpDrawnTextLayout.glyphOffsetBands(ofLines:in:)`).
    func paintedRects(bands: [HwpDrawnTextLayout.GlyphOffsetBand]) -> [CGRect] {
        let box = selectionRect
        var rects = [box]
        for band in bands {
            let x = baselineOrigin.x + band.minX
            let width = band.maxX - band.minX
            guard width > 0 else { continue }
            rects.append(CGRect(
                x: x, y: box.minY - band.offset, width: width, height: box.height
            ))
        }
        return rects
    }
}

extension HwpDrawnTextLayout {
    /// 옮겨진 run 하나의 잉크 가로 범위(줄 원점 기준)와 그 오프셋.
    struct GlyphOffsetBand {
        let minX: CGFloat
        let maxX: CGFloat
        /// 렌더러 규약 그대로 **양수 = 위**.
        let offset: CGFloat
        /// 이 밴드를 낸 run들의 문자열 범위 — **CTLine 인덱스**다 (재조판된 부분 복사본
        /// 기준). 링크 스팬이 자기 run의 밴드만 가려낼 때 쓴다 (#197 리뷰 4차). 시각적으로
        /// 잇닿은 같은 오프셋·같은 링크의 run이 한 밴드로 묶이므로 (#200 리뷰) 여럿일 수 있다.
        let ranges: [CFRange]

        /// 이 밴드가 `span`의 것인가 — 묶음의 **첫 run의 첫 글자**가 스팬 안에 있으면 그 스팬
        /// 것이다 (CTLine 인덱스끼리 비교). 묶음은 같은 링크 속성의 run만 잇고(`glyphOffsetBands`)
        /// CT는 run에 첫 글자의 속성을 달므로, 첫 run의 첫 글자가 곧 이 밴드가 그려지는 링크다.
        ///
        /// 처음(#197 리뷰 4차)에는 run 전부가 스팬에 통째로 드는 **포함**으로 물어 남의 잉크를
        /// 안 가져가게 했지만, CT는 글리프 없는 문자(U+200B·RLM·결합 부호)와 자소 묶음을 속성이
        /// 달라도 **앞 run에 합치므로** run이 스팬 경계를 넘을 수 있고(#201 리뷰 실측), 그때
        /// 포함은 자기 밴드를 버린다 — 링크 스팬의 줄 상자 구간(`RunExtent.belongs(to:)`)과
        /// 같은 규칙으로 맞춘다. 양방향 줄에서 남의 run을 안 가져가는 것은 이 규칙으로도
        /// 그대로다: 남의 run은 첫 글자가 남의 스팬에 있다.
        func belongs(to span: CFRange) -> Bool {
            guard let first = ranges.first else { return false }
            return first.location >= span.location
                && first.location < span.location + span.length
        }
    }

    /// 줄별 밴드 — 링크 스팬·줄마다 다시 걷지 않게 호출자가 한 번만 받아 나눠 쓴다.
    ///
    /// 글자 위치 run이 **하나도 없는** 문단(대다수)은 CTRun 전수 순회 자체를 건너뛴다:
    /// `CTRunGetAttributes`는 run마다 CFDictionary를 브리징해 오프셋이 없어도 값을
    /// 치른다. 속성 run 한 번 훑기가 훨씬 싸다.
    static func glyphOffsetBands(
        ofLines drawnLines: [HwpDrawnLine], in attributedString: NSAttributedString
    ) -> [[GlyphOffsetBand]] {
        guard carriesGlyphOffset(attributedString) else {
            return Array(repeating: [], count: drawnLines.count)
        }
        return drawnLines.map { glyphOffsetBands(of: $0.line) }
    }

    /// 조판 문자열의 글자 위치가 글리프를 **위·아래로 각각** 얼마나 멀리 옮기는가 (pt, 0 이상).
    /// 옮겨진 밴드가 줄 상자 밖으로 나가는 양이다 — 위 첨자만 있는 문단은 위로만 나간다.
    /// `carriesGlyphOffset`과 같은 술어(`offset != 0`)를 쓰되 조판 없이 속성 run만 훑는다.
    struct GlyphOffsetReach {
        var above: CGFloat = 0
        var below: CGFloat = 0
        var magnitude: CGFloat {
            max(above, below)
        }
    }

    static func glyphOffsetReach(in attributedString: NSAttributedString) -> GlyphOffsetReach {
        var reach = GlyphOffsetReach()
        attributedString.enumerateAttribute(
            HwpAttributedStringKey.glyphBaselineOffset,
            in: NSRange(location: 0, length: attributedString.length),
            options: .longestEffectiveRangeNotRequired
        ) { value, _, _ in
            guard let offset = (value as? NSNumber)?.doubleValue, offset != 0 else { return }
            // 렌더러 규약 그대로 양수 = 위.
            if offset > 0 {
                reach.above = max(reach.above, CGFloat(offset))
            } else {
                reach.below = max(reach.below, CGFloat(-offset))
            }
        }
        return reach
    }

    /// 가장 큰 글자 위치 |오프셋| — 자격 영역(`HwpHitTester.textBounds`)이 옮겨진 밴드를
    /// 품도록 줄 높이에 더하는 몫이다 (#200 리뷰).
    static func maxGlyphOffsetMagnitude(in attributedString: NSAttributedString) -> CGFloat {
        glyphOffsetReach(in: attributedString).magnitude
    }

    /// 조판 문자열에 0이 아닌 글자 위치 run이 하나라도 있는가.
    private static func carriesGlyphOffset(_ attributedString: NSAttributedString) -> Bool {
        var found = false
        attributedString.enumerateAttribute(
            HwpAttributedStringKey.glyphBaselineOffset,
            in: NSRange(location: 0, length: attributedString.length),
            options: .longestEffectiveRangeNotRequired
        ) { value, _, stop in
            guard let offset = (value as? NSNumber)?.doubleValue, offset != 0 else { return }
            found = true
            stop.pointee = true
        }
        return found
    }

    /// 옮겨진 run마다 (줄 원점 기준 가로 범위, 오프셋) — 정밀 커버리지용.
    ///
    /// 가로 범위는 **잉크 경계**(`CTRunGetImageBounds`, 줄 원점 기준)에서 낸다 — claim은
    /// 칠한 자리만 가져가야 하고(R54) 밴드는 그 run이 실제로 찍은 잉크의 세로 이동분이기
    /// 때문이다 (#200 리뷰). 진행 폭 기반은 두 가지로 틀렸다 (2026-09-14 실측, Helvetica 10pt):
    /// - **잉크 없는 진행 폭을 덮는다** — 꼬리 공백은 줄 상자(`selectionRect`)가 빼는데 밴드는
    ///   품어 `LINK   `의 밴드가 22.2가 아니라 30.6까지 갔고, 공백뿐인 run(줄 상자 폭 0)이
    ///   8.3 폭의 밴드를 냈으며, 탭(글자 모양 속성으로 방출된다)의 21.3 진행 폭도 들어갔다.
    ///   그 빈 띠가 링크로 눌리고, 전경 글자가 뒤 층의 보이는 링크를 거짓으로 가린다.
    /// - **장평(글꼴 매트릭스)이 반영되지 않는다** — `CTRunGetPositions`는 매트릭스 **적용
    ///   전** 좌표(0…22.2)를 주고 `CTRunGetTypographicBounds`는 적용 후 폭(12.5)을 주므로,
    ///   장평 50% run의 밴드가 줄 머리에서는 실제 잉크(0.4…11.1)의 두 배였고 줄 중간에서는
    ///   엉뚱한 열 위에 섰다(실제 x = a × position). 이미지 경계는 적용 후다.
    ///
    /// 문자열 인덱스로 되짚지 않는 이유는 그대로다 — 재조판된 부분 복사본에서 범위가
    /// 어긋나고 RTL은 논리 순서와 x 순서가 반대다. 잉크 경계는 시각 좌표라 둘 다 무관하다.
    ///
    /// **낱말 사이는 줄 상자와 같은 기준으로 덮는다**: 시각 순서(`CTLineGetGlyphRuns`가 주는
    /// 순서)로 잇닿은 **같은 오프셋·같은 링크**의 run을 한 밴드로 묶고, 그 사이에 낀 잉크 없는
    /// run(공백·탭)은 진행 폭(`CTLineGetOffsetForStringIndex`, 매트릭스 적용 후)으로 다리를
    /// 놓는다. run 하나 안의 공백만 품으면 폰트 폴백·글자 모양·스크립트 슬롯이 run을 가르는
    /// 자리(`홈페이지 바로가기`는 [홈페이지][ ][바로가기] 세 run이고 `CharShape` 픽스처의
    /// '글자위치 30' 줄도 HCRBatang 세 run)마다 옮겨진 링크의 낱말 사이가 히트 불가가 되고
    /// claim에 구멍이 나 뒤 층 링크가 열린다 (#200 리뷰 검증: 7.24pt 구멍). 묶음의 앞뒤 잉크
    /// 없는 run은 버린다 — 꼬리·머리 공백과 공백뿐인 묶음은 밴드가 없다. **렌더러가 안 그리는
    /// run은 묶음을 끊는다**: 개체 run(run delegate)은 옮겨지지 않고(개체 명령이 따로 그린다),
    /// 한 줄 끝 표식 run(`hwp.lineBreak`)은 `drawRun`이 글리프를 건너뛴다 (#146) — 조판은
    /// 표식 run에 오프셋을 안 실어 주지만(`lineBreakAttributes`) 공개 키를 함께 실은 입력에서
    /// HY 계열 폰트의 U+000A 잉크가 보이지 않는 밴드가 되면 안 된다 (#200 리뷰 2차).
    /// 합성 볼드의 stroke 확장·그림자 사본·양각 사본은 이미지 경계에 안 든다 (≤0.4pt·
    /// 그림자 오프셋·±0.7pt) — 줄 상자도 그것을 안 덮는 기존 격차라 밴드도 같은 기준이다.
    static func glyphOffsetBands(of line: CTLine) -> [GlyphOffsetBand] {
        guard let runs = CTLineGetGlyphRuns(line) as? [CTRun] else { return [] }
        var bands: [GlyphOffsetBand] = []
        var group: GlyphOffsetBandGroup?
        func close() {
            if let band = group?.band() {
                bands.append(band)
            }
            group = nil
        }
        for run in runs {
            let attributes = CTRunGetAttributes(run) as? [NSAttributedString.Key: Any]
            guard let offset =
                (attributes?[HwpAttributedStringKey.glyphBaselineOffset] as? NSNumber)?.doubleValue,
                offset != 0,
                attributes?[kCTRunDelegateAttributeName as NSAttributedString.Key] == nil,
                attributes?[HwpAttributedStringKey.lineBreak] == nil
            else {
                close()
                continue
            }
            let url = attributes?[HwpAttributedStringKey.hyperlink] as? String
            if group?.offset != CGFloat(offset) || group?.url != url {
                close()
                group = GlyphOffsetBandGroup(offset: CGFloat(offset), url: url)
            }
            // nil 컨텍스트면 줄 원점(CGPointZero) 기준 — `drawEmphasisIfNeeded`와 같은 호출.
            let ink = CTRunGetImageBounds(run, nil, CFRange(location: 0, length: 0))
            let range = CTRunGetStringRange(run)
            group?.members.append(GlyphOffsetBandGroup.Member(
                range: range,
                ink: ink.isNull || ink.width <= 0 ? nil : ink,
                advance: {
                    let start = CTLineGetOffsetForStringIndex(line, range.location, nil)
                    let end = CTLineGetOffsetForStringIndex(
                        line, range.location + range.length, nil
                    )
                    return min(start, end) ... max(start, end)
                }
            ))
        }
        close()
        return bands
    }
}

/// 시각적으로 잇닿은 같은 오프셋·같은 링크의 run 묶음 — 밴드 하나가 된다.
private struct GlyphOffsetBandGroup {
    struct Member {
        let range: CFRange
        /// 잉크 경계 (줄 원점 기준). 잉크가 없으면 nil (공백·탭).
        let ink: CGRect?
        /// 진행 폭 범위 — 잉크 없는 run이 묶음 **안쪽**에 낄 때만 평가한다.
        let advance: () -> ClosedRange<CGFloat>
    }

    let offset: CGFloat
    let url: String?
    var members: [Member] = []

    /// 앞뒤의 잉크 없는 run을 버리고, 남은 구간의 잉크(없으면 진행 폭)를 합친다.
    func band() -> HwpDrawnTextLayout.GlyphOffsetBand? {
        guard let first = members.firstIndex(where: { $0.ink != nil }),
              let last = members.lastIndex(where: { $0.ink != nil })
        else { return nil }
        var minX = CGFloat.infinity
        var maxX = -CGFloat.infinity
        for member in members[first ... last] {
            if let ink = member.ink {
                minX = min(minX, ink.minX)
                maxX = max(maxX, ink.maxX)
            } else {
                let advance = member.advance()
                minX = min(minX, advance.lowerBound)
                maxX = max(maxX, advance.upperBound)
            }
        }
        guard maxX > minX else { return nil }
        return HwpDrawnTextLayout.GlyphOffsetBand(
            minX: minX, maxX: maxX, offset: offset,
            ranges: members[first ... last].map(\.range)
        )
    }
}
