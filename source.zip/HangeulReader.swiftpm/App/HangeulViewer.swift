import SwiftUI
import UIKit
import UniformTypeIdentifiers
import HwpKit
import HwpKitCore
import CoreHwp
import ImageIO

@main
struct HangeulViewerApp: App {
    var body: some Scene { WindowGroup { LibraryScreen() } }
}

struct OpenDocument: Identifiable {
    let id = UUID()
    let name: String
    let bytes: Data
    let layout: HwpDocument
}

enum ViewerIssue: LocalizedError {
    case fileType, fileSize, unreadable, noPages
    var errorDescription: String? {
        switch self {
        case .fileType: return "HWP 또는 HWPX 문서를 선택해 주세요."
        case .fileSize: return "32MB 이하의 문서를 선택해 주세요."
        case .unreadable: return "파일을 읽을 수 없어요. 파일 앱에서 내려받기가 끝났는지 확인해 주세요."
        case .noPages: return "이 문서에서 표시할 쪽을 찾지 못했어요."
        }
    }
}

enum SourceFile {
    static let limit = 32 * 1024 * 1024

    static func read(_ url: URL) throws -> Data {
        guard url.isFileURL, ["hwp", "hwpx"].contains(url.pathExtension.lowercased()) else { throw ViewerIssue.fileType }
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        var result: Result<Data, Error> = .failure(ViewerIssue.unreadable)
        var coordinationError: NSError?
        NSFileCoordinator(filePresenter: nil).coordinate(readingItemAt: url, options: [], error: &coordinationError) { location in
            result = Result {
                let handle = try FileHandle(forReadingFrom: location)
                defer { try? handle.close() }
                let data = try handle.read(upToCount: limit + 1) ?? Data()
                guard data.count <= limit else { throw ViewerIssue.fileSize }
                guard !data.isEmpty else { throw ViewerIssue.unreadable }
                return data
            }
        }
        if let error = coordinationError { throw error }
        return try result.get()
    }

    static func sample(_ ext: String) -> URL? {
        #if SWIFT_PACKAGE
        let bundle = Bundle.module
        #else
        let bundle = Bundle.main
        #endif
        return bundle.url(forResource: "표 배치 예제", withExtension: ext, subdirectory: "Samples")
    }
}

@MainActor
final class LibraryModel: ObservableObject {
    @Published var opened: OpenDocument?
    @Published var loading = false
    @Published var error: String?
    private var task: Task<Void, Never>?

    func open(_ url: URL) {
        task?.cancel()
        error = nil
        loading = true
        task = Task {
            do {
                let bytes = try await Task.detached(priority: .userInitiated) { try SourceFile.read(url) }.value
                try Task.checkCancellation()
                let layout = try await HwpDocumentLoader().load(from: bytes)
                try Task.checkCancellation()
                guard !layout.pages.isEmpty else { throw ViewerIssue.noPages }
                opened = OpenDocument(name: url.lastPathComponent, bytes: bytes, layout: layout)
            } catch {
                guard !Task.isCancelled else { return }
                self.error = error.localizedDescription
            }
            if !Task.isCancelled { loading = false }
        }
    }

    func close() {
        task?.cancel()
        loading = false
        opened = nil
        error = nil
    }
}

@MainActor
struct LibraryScreen: View {
    @StateObject private var model = LibraryModel()
    @State private var choosing = false
    private let ink = Color(red: 0.06, green: 0.32, blue: 0.29)

    var body: some View {
        NavigationStack {
            Group {
                if let file = model.opened {
                    ReaderScreen(file: file).id(file.id)
                } else {
                    List {
                        Section {
                            Button { choosing = true } label: {
                                Label("파일에서 문서 열기", systemImage: "folder")
                                    .font(.headline).padding(.vertical, 10)
                            }
                        } footer: { Text("HWP 5.x · HWPX   최대 32MB") }
                        Section("예제 문서") {
                            ForEach(["hwp", "hwpx"], id: \.self) { ext in
                                Button {
                                    if let url = SourceFile.sample(ext) { model.open(url) }
                                    else { model.error = "예제 파일을 찾을 수 없어요." }
                                } label: {
                                    HStack {
                                        Label("표 배치 예제", systemImage: "doc.richtext")
                                        Spacer()
                                        Text(ext.uppercased()).font(.caption).foregroundStyle(.secondary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle(model.opened?.name ?? "한글뷰어")
            .navigationBarTitleDisplayMode(model.opened == nil ? .large : .inline)
            .toolbar {
                if model.opened != nil {
                    ToolbarItem(placement: .topBarLeading) {
                        Button { model.close() } label: { Image(systemName: "chevron.backward") }.accessibilityLabel("문서 목록")
                    }
                    ToolbarItem(placement: .topBarTrailing) {
                        Button { choosing = true } label: { Image(systemName: "folder") }.accessibilityLabel("다른 문서 열기")
                    }
                }
            }
            .overlay {
                if model.loading {
                    ProgressView("문서를 여는 중").padding(22)
                        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14))
                }
            }
        }
        .tint(ink)
        .fileImporter(isPresented: $choosing, allowedContentTypes: [.data]) { result in
            switch result {
            case .success(let url): model.open(url)
            case .failure(let error):
                if (error as NSError).code != NSUserCancelledError { model.error = error.localizedDescription }
            }
        }
        .onOpenURL { model.open($0) }
        .alert("문서를 열 수 없어요", isPresented: Binding(get: { model.error != nil }, set: { if !$0 { model.error = nil } })) {
            Button("확인", role: .cancel) {}
        } message: { Text(model.error ?? "") }
    }
}

@MainActor
struct ReaderScreen: View {
    let file: OpenDocument
    @State private var page = 1
    @State private var zoom: CGFloat = 1
    @State private var fit: HwpZoomFit? = .width
    @State private var search = HwpSearchController()
    @State private var finding = false
    @State private var showingPreview = false

    var body: some View {
        VStack(spacing: 0) {
            if finding {
                HwpSearchBar(controller: search, prompt: "문서에서 찾기", fieldWidth: nil)
                    .padding(.horizontal).padding(.vertical, 6)
            }
            if !file.layout.unsupportedElements.isEmpty {
                Label("일부 개체의 표시가 제한됩니다.", systemImage: "info.circle")
                    .font(.footnote).foregroundStyle(.secondary).padding(6)
            }
            HwpDocumentView(document: file.layout, zoomScale: $zoom, fitZoom: $fit,
                            currentPage: $page, searchController: search)
            Divider()
            HStack {
                Button { page = max(1, page - 1) } label: { Image(systemName: "chevron.left").frame(width: 36, height: 44) }
                    .accessibilityLabel("이전 쪽").disabled(page <= 1)
                Text("\(page) / \(file.layout.pages.count)쪽").monospacedDigit().font(.subheadline)
                Button { page = min(file.layout.pages.count, page + 1) } label: { Image(systemName: "chevron.right").frame(width: 36, height: 44) }
                    .accessibilityLabel("다음 쪽").disabled(page >= file.layout.pages.count)
                Spacer()
                Button {
                    finding.toggle()
                    if !finding { search.search(text: "") }
                } label: { Image(systemName: "magnifyingglass").frame(width: 36, height: 44) }.accessibilityLabel("본문 검색")
                Menu {
                    Button("너비에 맞추기") { fit = .width }
                    Button("한 쪽 전체 보기") { fit = .page }
                    Divider()
                    Button("파일에 저장된 미리보기") { showingPreview = true }
                } label: { Image(systemName: "ellipsis.circle").frame(width: 36, height: 44) }.accessibilityLabel("보기 옵션")
            }
            .padding(.horizontal, 12)
            .background(.bar)
        }
        .sheet(isPresented: $showingPreview) { EmbeddedPreview(bytes: file.bytes) }
    }
}

struct EmbeddedPreview: View {
    let bytes: Data
    @Environment(\.dismiss) private var dismiss
    @State private var picture: UIImage?
    @State private var complete = false
    @State private var previewError = false

    var body: some View {
        NavigationStack {
            Group {
                if let picture {
                    GeometryReader { area in
                        ScrollView {
                            Image(uiImage: picture).resizable().scaledToFit()
                                .frame(width: area.size.width)
                                .accessibilityLabel("문서에 저장된 미리보기 이미지")
                        }
                    }
                } else if previewError {
                    ContentUnavailableView("미리보기를 읽을 수 없어요", systemImage: "photo")
                } else if complete {
                    ContentUnavailableView("저장된 미리보기가 없어요", systemImage: "doc",
                        description: Text("문서 작성 프로그램이 미리보기 이미지를 포함한 파일에서 사용할 수 있어요."))
                } else { ProgressView("미리보기를 읽는 중") }
            }
            .navigationTitle("저장된 미리보기").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("닫기") { dismiss() } } }
        }
        .task {
            // Raw preview bytes are intentionally retained only for this on-demand comparison.
            let data = await Task.detached(priority: .userInitiated) { [bytes] in
                try? HwpFile(fromData: bytes, options: .init(preserveRawPayload: true, recoverPartialContent: true)).previewImage.image
            }.value
            guard !Task.isCancelled else { return }
            if let data, let source = CGImageSourceCreateWithData(data as CFData, nil) {
                let options: [CFString: Any] = [
                    kCGImageSourceCreateThumbnailFromImageAlways: true,
                    kCGImageSourceCreateThumbnailWithTransform: true,
                    kCGImageSourceThumbnailMaxPixelSize: 3000
                ]
                if let cg = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) { picture = UIImage(cgImage: cg) }
            }
            previewError = data == nil || (data?.isEmpty == false && picture == nil)
            complete = true
        }
    }
}
